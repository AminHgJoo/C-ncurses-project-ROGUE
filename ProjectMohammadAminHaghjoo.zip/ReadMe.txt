Guide : 
1- Compile code with this command : ./compile.sh 
2- Compiled game application will be game.out
3- Controls : e in menus for accepting stuff. e in game for food menu. p for spells menu. i for weapons menu. movement is with the numpad
              up
            7 8 9
       left 4 5 6 right
            1 2 3
             down
note : 5 doesn't move anything.