gcc Rogue-v2.0.0.c -o game.out -lncursesw -lSDL2 -lSDL2_mixer
