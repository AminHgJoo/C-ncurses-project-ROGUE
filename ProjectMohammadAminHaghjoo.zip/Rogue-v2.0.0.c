#include <ncurses.h>    //\\ SUT Student ID:403110585 | <<Mohammad Amin Haghjoo>> []~(￣▽￣)~* \\// 
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <locale.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>

#define RED_COLORED_CELL COLOR_PAIR(3)
#define GREEN_COLORED_CELL COLOR_PAIR(4)
#define GOLD_COLORED_CELL COLOR_PAIR(1)
#define BLUE_COLORED_CELL COLOR_PAIR(5)
#define WHITE_COLORED_CELL COLOR_PAIR(6)
#define GOLD_HIGHLIGHT COLOR_PAIR(2)
#define RED_HIGHLIGHT COLOR_PAIR(8)
#define GREEN_HIGHLIGHT COLOR_PAIR(9)
#define BLUE_HIGHLIGHT COLOR_PAIR(10)
#define WHITE_HIGHLIGHT COLOR_PAIR(11)
#define ORANGE_COLORED_CELL COLOR_PAIR(7)
#define BLUE_SCREEN COLOR_PAIR(12)
#define COLOR_ORANGE COLOR_CYAN     // Cyan has been changed into Orange.
#define MAGENTA_COLORED_CELL COLOR_PAIR(13)
#define GREEN_W_BLUE_BG COLOR_PAIR(14)
#define RED_W_BLUE_BG COLOR_PAIR(15)



typedef struct point {

    char SYMBOL;//-1 is Δ, -2 is ζ (wand) , -3 is τ (sword) , -4 is ι (dagger)

    char REAL_CONTENTS; 

    char IS_DISCOVERED;

    char PASSWORD_DOOR_TYPE;// '1' '2' 't' 'r' 'l' 1, 2, time, reverse, locked out!

    char COLOR; //y: yellow/golden | r :red | b: blue | w: white | gold : treasure room
                //red : nightmare | blue: spell room | white : regular | 'o'(orange) for password door warning system

    char IS_START; //1 means start, -1 means end

} POINT;

typedef struct settings {

    char HERO_COLOR;

    char MUSIC;

    char DIFFICULTY;

    char PLAY_MUSIC;

} SETTINGS;

typedef struct door {

    int x;

    int y;

    int SECTOR;

    char DIRECTION;

} DOOR;

typedef struct coords {

    int x;

    int y;

}   COORDS;

typedef struct inventory_and_stats {//this struct must be saved

    int x;

    int y;

    int FLOOR; // actually one lower than real number. defined this way for easy use in array indices

    int KEYS;

    int BROKEN_KEYS;

    int HUNGER; int HP; int SCORE; int GOLD; //all 0 at start except HP/HUNGER
    
    int FOOD_REGULAR, FOOD_ELITE,FOOD_MAGIC,FOOD_SPOILED;

    int H_SPELL,S_SPELL,D_SPELL; //all 0 at start

    int MACE,DAGGER,WAND,ARROW,SWORD; //all 0 at start, except mace which is 1

    int TIME_PLAYED;

    int EQUIPPED_WEAPON;//s : sword | m : mace | w : wand | a : arrows | d : dagger | value of 0, Nothing

} INVENTORY_AND_STATS;

typedef struct scores {

    char username[20];     
    
    int total_score;        
    
    int total_gold;       
    
    int number_of_games;     
    
    int time_played;

}   SCORES_AND_DATA;

typedef struct {

    int H; int S; int D;

}   BUFFS; //health,dmg,speed spells

typedef struct {

    int DMG;

    int MAX_MOVE_TILES; // -1 for always follow. 0 for stationary enemy

    int MOVES_LEFT;

    int x,y; //coords.

    int HP; int MAX_HP;

    int SYMBOL;

}   ENEMY;

//----------------------------------------------Player Inventory/misc Handling-------------------------------------------------//

ENEMY GLOBAL_ALL_ENEMIES[4][6];

ENEMY GLOBAL_BOSSES_IN_LAST_ROOM[4];

BUFFS GLOBAL_EFFECTS_STORAGE;

SETTINGS GLOBAL_SETTINGS;

INVENTORY_AND_STATS GLOBAL_INVENTORY_AND_COORDINATES;//must be saved at exit

int GLOBAL_LOAD_SAVE=FALSE;

int GLOBAL_LAST_FIRED_DIR=0;

int ROW,COLUMN;

int GLOBAL_IS_GUEST=0;

char GLOBAL_LOGGED_IN_USER[100];

int GLOBAL_EXIT_CODE=0;        // 0 is no exiting, 1 is unsaved exit, 2 is end_of_game exit, 3 is saved and quit, 4 is lose exit

int GLOBAL_SHOW_ALL=FALSE;

int GLOBAL_MAX_HP; //no need to save. determined based on settings.

unsigned long long int GLOBAL_LAST_HUNGER_TIME_QUERRY,GLOBAL_LAST_ENCHANT_QUERRY=0;

unsigned long long int GLOBAL_LAST_HP_REGEN_TIME_QUERRY=0; int GLOBAL_LAST_HP;

unsigned long long int GLOBAL_LAST_SPOILAGE_TIME_QUERRY=0;

char GLOBAL_LAST_THEME_IN=0;

char GLOBAL_ALL_THEMES_COLOR[4][6]; //'w' is default. 'r' |red is nightmare. 'y' | yellow/gold is treasure. 'b'|blue is enchant room.

//----------------------------------------------Message Handling--------------------------------------------------------------------//

char GLOBAL_MOST_RECENT_MESSAGE[100];

char GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE;

//-----------------------------------------------Passkey Doors Handling-------------------------------------------------------------//

unsigned long long int GLOBAL_MOST_RECENT_PASSWORD_REQUEST_TIME=0;

int GLOBAL_DOOR_PASSWORD=-1; 

int GLOBAL_IS_PASSWORD_DYNAMIC=FALSE;

int GLOBAL_PASSWORD_DOOR_BACKGROUND_CHECK=FALSE;

//---------------------------------------------------Game Menus & startup/end---------------------------------------------------------//

void HANDLE_GUEST_USER();
char GAME_STARTUP_MENU();
void USER_REGISTERATION();
void HANDLE_NEXT_MENUS(char);
int USER_LOGIN();
void CLEAR_TEXT_FOR_LOGIN_ERRORS();
void RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();
void GENERATE_RANDOM_PASSWORD(char[]);
int VALIDATE_EMAIL(char[]);
int PRE_GAME_MENU();
void PRINT_PREGAME_MENU();
void OPEN_LEADERBOARDS();
void OPEN_SETTINGS();
void PRINT_SETTINGS_MENU();
void OPEN_MUSIC_MENU();
void OPEN_DIFFICULTY_MENU();
void OPEN_HERO_COLOR_MENU();
void PRINT_COLOR_GUI();
void LOAD_USER_SETTINGS();
void HANDLE_SETTINGS();
void PRINT_DIFFICULTY_MENU();
void PRINT_MUSIC_MENU();
void OPEN_PAUSE_MENU();
void PRINT_PAUSE_MENU();
void START_GAME(int *);
void SHUTDOWN_GAME(Mix_Music *);
void SAVE_GAME(POINT [4][38][144],int );
void OPEN_FOOD_MENU();
void OPEN_WEAPONS_MENU();
void OPEN_SPELLS_MENU();
void OPEN_VICTORY_MENU();
void SAVE_ONTO_SCOREBOARD(int );
void OPEN_GAME_LAUNCHER(int *);
void HANDLE_EFFECTS_USAGE();
void PRINT_WEAPONS_MENU();
//----------------------------------------------------In Game Functions(World Gen)----------------------------------------------------//
void PRINT_MESSAGE(char []);
void CLEAR_MESSAGE_BAR();
void TURN_OFF_COLOR_FOR_MAP_PRINT(char);
void TURN_ON_COLOR_FOR_MAP_PRINT(char);
int GIVE_SECTOR_NUMBER(int , int );
void LOAD_MAP_AND_INVENTORY(POINT [4][38][144]);
void GENERATE_MAP(POINT [4][38][144]);
int GENERATE_FLOOR_SKELETON(POINT [38][144], int ,int );
void CONNECT_ROOMS_AND_RETURN_DOORS(POINT [38][144], DOOR [14]);
void GENERATE_PILLARS(POINT [38][144]);
int GENERATE_ENTRY_EXIT( POINT [38][144], int );
COORDS GIVE_STAIRS_ADDRESS_ENTRY(POINT [38][144]);
COORDS GIVE_STAIRS_ADDRESS_EXIT(POINT [38][144]);
int FIND_SPECIFIED_DOOR(char ,  int , DOOR [14]);
void GENERATE_ANCIENT_KEY(POINT [38][144]);   
void SPAWN_FOOD(int , int , int ,POINT [38][144]);
void SPAWN_BLACK_GOLD(int , int , int ,POINT [38][144]);
void SPAWN_GOLD(int , int , int , POINT [38][144]);
void SPAWN_TRAPS(int, int , int , POINT [38][144]);
void SPAWN_WEAPONS(int, int ,int ,POINT [38][144]);
void SPAWN_SPELLS(int , int ,int  ,POINT [38][144]);
void GENERATE_ENEMIES(POINT [38][144], int);
//-------------------------------------------In Game Functions(Movement & Exploration/Combat)------------------------------------------------//
void HANDLE_USER_INPUT_AND_MOVE_HERO(char *,POINT [4][38][144]);
int PROCESS_PLAYER_INPUT(int, POINT [4][38][144], char *);
void PRINT_MAP_ON_SCREEN(POINT [4][38][144]);
void UPDATE_EXPLORATION_AND_HANDLE_INTERACTIVE_OBJECTS(POINT [4][38][144]);
void REVEAL_ENTIRE_SECTOR(POINT [4][38][144],int );
void REVEAL_HALLWAYS(POINT [4][38][144], char,int ,int ,int );
void FIND_MAX_HP();
void PERFORM_DEATH_CHECK();
void OPEN_DEATH_MENU();
void HANDLE_TRAP_ACTIVATION();
void PERFORM_ENCHANT_THEME_EFFECT_CHECK(POINT [4][38][144]);
void HANDLE_THEME_CHANGE_MUSIC_CHANGE(POINT [4][38][144], Mix_Music * ,Mix_Music *);
void HANDLE_HP_REGEN();
void MOVE_ENEMIES(POINT [38][144]);
void HANDLE_ENEMIES_COMBAT(POINT [38][144]);
void HANDLE_PLAYER_COMBAT(POINT [38][144], int);
int FIND_THAT_SNAKE(int x, int y);
//--------------------------------------------------Handling Passkey Doors-------------------------------------------------------------//
void PASSWORD_BACKGROUND_CHECK();
void HANDLE_DOOR_PASSKEY_GENERATION(POINT [4][38][144]);
void OPEN_PASSKEY_GUI(POINT [4][38][144]);
int HANDLE_ANCIENT_KEY_USAGE();
//-------------------------------------------------Item Pickups Handling------------------------------------------------------------------//
void HANDLE_ITEM_PICKUPS(POINT [4][38][144], char *);
void REDUCE_HUNGER();
void HANDLE_FOOD_SPOILAGE();
//-------------------------------------------------------------Main-----------------------------------------------------------------------//

int main() {

    setlocale(LC_ALL, "");

    initscr();

    start :

    int OK_SCREEN_SIZE=TRUE;

    START_GAME(&OK_SCREEN_SIZE);

    if(OK_SCREEN_SIZE==FALSE) {
        endwin();
        return 0;
    }

    char NEXT_MENU=GAME_STARTUP_MENU();

    HANDLE_NEXT_MENUS(NEXT_MENU);

    HANDLE_SETTINGS();

    PRE_GAME_MENU();

    POINT MAP[4][38][144];

    if(GLOBAL_LOAD_SAVE==TRUE) {

        LOAD_MAP_AND_INVENTORY(MAP);

    }
    else {

        GENERATE_MAP(MAP);   

    }

    FIND_MAX_HP();

    SDL_Init(SDL_INIT_AUDIO);   Mix_OpenAudio(22050, MIX_DEFAULT_FORMAT, 2, 4096);  Mix_Music *music=NULL,*theme_music= NULL;

    if(GLOBAL_SETTINGS.PLAY_MUSIC=='t') {

        switch(GLOBAL_SETTINGS.MUSIC) {

            case 'w' : 
                music=Mix_LoadMUS("the_weeknd_sacrifice.mp3");

            break;

            case 's' :
                music=Mix_LoadMUS("Sleep Away.mp3");
            break;

            case 'r' :
                music=Mix_LoadMUS("Rick-Astley-Never-Gonna-Give-You-Up.mp3");
            break;

        }

        Mix_PlayMusic(music, 1000);
    }
    
    unsigned long long int START_TIME=time(NULL); GLOBAL_LAST_HP_REGEN_TIME_QUERRY=START_TIME; GLOBAL_LAST_SPOILAGE_TIME_QUERRY=START_TIME;

    GLOBAL_LAST_HUNGER_TIME_QUERRY=START_TIME;

    GLOBAL_LAST_THEME_IN=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

    halfdelay(20); 

    char TRANSITION_STORAGE='.';    UPDATE_EXPLORATION_AND_HANDLE_INTERACTIVE_OBJECTS(MAP);    PRINT_MAP_ON_SCREEN(MAP);

    GLOBAL_LAST_HP=GLOBAL_INVENTORY_AND_COORDINATES.HP;

    //Game Loop Here ---------------------------------------------------------------------------------------------

    while(GLOBAL_EXIT_CODE==0) {

        HANDLE_USER_INPUT_AND_MOVE_HERO(&TRANSITION_STORAGE,MAP);

        REDUCE_HUNGER();

        CLEAR_MESSAGE_BAR();

        UPDATE_EXPLORATION_AND_HANDLE_INTERACTIVE_OBJECTS(MAP);

        PRINT_MAP_ON_SCREEN(MAP);

        if(GLOBAL_PASSWORD_DOOR_BACKGROUND_CHECK==TRUE) {

            PASSWORD_BACKGROUND_CHECK();

        }

        HANDLE_THEME_CHANGE_MUSIC_CHANGE(MAP,music,theme_music);

        PERFORM_ENCHANT_THEME_EFFECT_CHECK(MAP);

        HANDLE_ENEMIES_COMBAT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR]);

        PERFORM_DEATH_CHECK();

        HANDLE_HP_REGEN();

        HANDLE_EFFECTS_USAGE();

        HANDLE_FOOD_SPOILAGE();

        MOVE_ENEMIES(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR]);

        GLOBAL_LAST_THEME_IN=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

    }   

    unsigned long long int FINISH_TIME=time(NULL);

    if(GLOBAL_EXIT_CODE==3) {

        SAVE_GAME(MAP,FINISH_TIME-START_TIME+GLOBAL_INVENTORY_AND_COORDINATES.TIME_PLAYED);

    }

    if(GLOBAL_EXIT_CODE==2) {

        if(GLOBAL_IS_GUEST==FALSE)  {

            SAVE_ONTO_SCOREBOARD(FINISH_TIME-START_TIME+GLOBAL_INVENTORY_AND_COORDINATES.TIME_PLAYED);

            char STRING[100]="saves_";

            strcat(STRING,GLOBAL_LOGGED_IN_USER);

            strcat(STRING,".txt");

            FILE *SAVE_LOCATION=fopen(STRING,"w+");

            fclose(SAVE_LOCATION);

        }

    } 
    
    SHUTDOWN_GAME(music);

    if(GLOBAL_EXIT_CODE==4 || GLOBAL_EXIT_CODE==2) {
        
        GLOBAL_EXIT_CODE=0;

        GLOBAL_LAST_FIRED_DIR=0;

        GLOBAL_SHOW_ALL=FALSE;

        GLOBAL_IS_GUEST=0;

        GLOBAL_LAST_THEME_IN=0;

        GLOBAL_MOST_RECENT_PASSWORD_REQUEST_TIME=0;

        GLOBAL_DOOR_PASSWORD=-1; 

        GLOBAL_IS_PASSWORD_DYNAMIC=FALSE;

        GLOBAL_PASSWORD_DOOR_BACKGROUND_CHECK=FALSE;

        GLOBAL_LOAD_SAVE=FALSE;

        goto start;

    }

    endwin();

    return 0;
}

//----------------------------------------------------Function Definitions---------------------------------------------------------------//

char GAME_STARTUP_MENU() {

    attron(COLOR_PAIR(1));

    mvprintw(ROW-1,0,"v2.0.0 Developed By Mohammad Amin Haghjoo");

    mvprintw(ROW-1,COLUMN/2-22,"Press e or E and arrow keys to Navigate Menus");

    

    char rogue[][120]={
        " .----------------.  .----------------.  .----------------.  .----------------.  .----------------. ",
        "| .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |",
        "| |  _______     | || |     ____     | || |    ______    | || | _____  _____ | || |  _________   | |",
        "| | |_   __ \\    | || |   .'    `.   | || |  .' ___  |   | || ||_   _||_   _|| || | |_   ___  |  | |",
        "| |   | |__) |   | || |  /  .--.  \\  | || | / .'   \\_|   | || |  | |    | |  | || |   | |_  \\_|  | |",
        "| |   |  __ /    | || |  | |    | |  | || | | |    ____  | || |  | '    ' |  | || |   |  _|  _   | |",
        "| |  _| |  \\ \\_  | || |  \\  `--'  /  | || | \\ `.___]  _| | || |   \\ `--' /   | || |  _| |___/ |  | |",
        "| | |____| |___| | || |   `.____.'   | || |  `._____.'   | || |    `.__.'    | || | |_________|  | |",
        "| |              | || |              | || |              | || |              | || |              | |",
        "| '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |",
        " '----------------'  '----------------'  '----------------'  '----------------'  '----------------' "
    };

    char skull[][65]={
        "                  .-\"      \"-.",
        "                 /            \\",
        "                |              |",
        "                |,  .-.  .-.  ,|",
        "                | )(__/  \\__)( |",
        "                |/     /\\     \\|",
        "      (@_       (_     ^^     _)",
        " _     ) \\_______\\__|IIIIII|__/__________________________",
        "(_)@8@8{}<________|-\\IIIIII/-|___________________________>",
        "       )_/        \\          /",
        "      (@           `--------`"
    };

    char sword[][35]={
        "   |\\                     /)",
        " /\\_\\\\__               (_//",
        "|   `>\\-`     _._       //`)",
        " \\ /` \\\\  _.-`:::`-._  //",
        "  `    \\|`    :::    `|/",
        "        |     :::     |",
        "        |.....:::.....|",
        "        |:::::::::::::|",
        "        |     :::     |",
        "        \\     :::     /",
        "         \\    :::    /",
        "          `-. ::: .-'",
        "           //`:::`\\\\",
        "          //   '   \\\\",
        "         |/         \\\\"
    };

    attroff(COLOR_PAIR(1));

    attron(COLOR_PAIR(13));

    for(int i=0 ; i<11 ; i++) {
        mvprintw(1+i,COLUMN/2-strlen(rogue[0])/2,"%s",rogue[i]);
    }

    attroff(COLOR_PAIR(13));

    attron(RED_COLORED_CELL);

    for(int i=0 ; i<11 ; i++) {
        mvprintw(ROW/2 +i,1,"%s",skull[i]);
    }

    for(int i=0 ; i<15 ; i++) {
        mvprintw(ROW/2+i,3*COLUMN/4,"%s",sword[i]);
    }


    attroff(RED_COLORED_CELL);

    attron(COLOR_PAIR(1));



    mvprintw(3*ROW/4,COLUMN/2-8,"Register New User");

    attroff(COLOR_PAIR(1));

    attron(COLOR_PAIR(2) | A_BLINK);

    mvprintw(ROW/2,COLUMN/2 -10 ,"Login or Play as Guest");

    attroff(COLOR_PAIR(2)); attroff(A_BLINK);

    move(ROW/2,COLUMN/2);

    int input;

    do {
        int x,y;

        getyx(stdscr,y,x);

        input=getch();

        if((input=='e' || input=='E' ) && y==ROW/2) {

            return 'p'; //play & login

        }
        else if((input=='e' || input=='E') && y==3*ROW/4) {
            
            return 'r'; //register new user

        }
        else if(input==KEY_DOWN && y==ROW/2) {

            attron(COLOR_PAIR(1));
            
            mvprintw(ROW/2,COLUMN/2 -10 ,"Login or Play as Guest");

            attroff(COLOR_PAIR(1));

            attron(COLOR_PAIR(2) | A_BLINK);

            mvprintw(3*ROW/4,COLUMN/2-8,"Register New User");

            attroff(COLOR_PAIR(2)); attroff(A_BLINK);

            move(3*ROW/4,COLUMN/2);

        }
        else if(input==KEY_UP && y==3*ROW/4) {

            attron(COLOR_PAIR(1));

            mvprintw(3*ROW/4,COLUMN/2-8,"Register New User");

            attroff(COLOR_PAIR(1));

            attron(COLOR_PAIR(2) | A_BLINK);

            mvprintw(ROW/2,COLUMN/2 -10 ,"Login or Play as Guest");

            attroff(COLOR_PAIR(2)); attroff(A_BLINK);

            move(ROW/2,COLUMN/2);

        }

        refresh();

    }

    while(TRUE);
}
void HANDLE_NEXT_MENUS(char NEXT_MENU) {

    if(NEXT_MENU=='r') {

        USER_REGISTERATION();

    }
    else if (NEXT_MENU=='p') {
    
        USER_LOGIN();

    }
}
void USER_REGISTERATION() {

    clear();

    char quill[][30]={
        "                      .`.",
        "                   .`~.-:",
        "                  .`- . -`",
        "                .`-  . -`",
        "              .`-   . -`",
        "            .`-    . -`",
        "          .`-     . -`",
        "         `-      . -`",
        "       .`-      . -`",
        "      ;-       . -`",
        "     .-      .  -`",
        "    ;.      . -`",
        "   ;.     . -`",
        "   ::._.-`",
        "   (.-`",
        "   .Y(.",
        "  ((()))",
        "  _)==(_",
        " | .--. |",
        " | '--' |",
        " '------'"
    };

    char register_art[][80]={
        " _______  _______  _______ _________ _______ _________ _______  _______ ",
        "(  ____ )(  ____ \\(  ____ \\\\__   __/(  ____ \\\\__   __/(  ____ \\(  ____ )",
        "| (    )|| (    \\/| (    \\/   ) (   | (    \\/   ) (   | (    \\/| (    )|",
        "| (____)|| (__    | |         | |   | (_____    | |   | (__    | (____)|",
        "|     __)|  __)   | | ____    | |   (_____  )   | |   |  __)   |     __)",
        "| (\\ (   | (      | | \\_  )   | |         ) |   | |   | (      | (\\ (   ",
        "| ) \\ \\__| (____/\\| (___) |___) (___/\\____) |   | |   | (____/\\| ) \\ \\__",
        "|/   \\__/(_______/(_______)\\_______/\\_______)   )_(   (_______/|/   \\__/"
    };

    char lock[][30]={
        "            .-\"\"-.",
        "           / .--. \\",
        "          / /    \\ \\",
        "          | |    | |",
        "          | |.-\"\"-.|",
        "         ///`.::::.`\\",
        "        ||| ::/  \\:: ;",
        "        ||; ::\\__/:: ;",
        "         \\\\\\ '::::' /",
        "          `=':-..-'`"
    };

    char mail[][40]={
        "            ____________",
        "           /     _.'\\   \\",
        "          /   _.'    \\   \\",
        "         /_.-'        \\___\\",
        "        |\\_\\ ``   .-   \\ _/|",
        "        |  _\\___________.  |", 
        "        | /              \\ |", 
        "        |/                \\|", 
        "        |__________________|"
    };

    attron(GREEN_COLORED_CELL);

    for(int i=0 ; i<21 ; i++) {
        mvprintw(ROW/4 +i,1,"%s",quill[i]);
    }

    attroff(GREEN_COLORED_CELL);

    attron(MAGENTA_COLORED_CELL);

    for(int i=0 ; i<8 ; i++) {
        mvprintw(1+i,COLUMN/2 - strlen(register_art[0])/2,"%s",register_art[i]);
    }

    attroff(MAGENTA_COLORED_CELL);

    echo();

    curs_set(1);

    FILE * USERS=fopen("passwords.txt","a+");

    attron(COLOR_PAIR(1));

    mvprintw(ROW/3,COLUMN/2 -11,"Enter Your Username :");

    attron(A_ITALIC);

    mvprintw(ROW/3 +1, COLUMN/2 -38 ,"Note : Username Mustn't Have Spaces, Be Already Taken, or Be Longer Than 15");

    attroff(A_ITALIC);

    mvprintw(2*ROW/3 +1 ,COLUMN/2 - 7 ,"###############");

    move(2*ROW/3 , COLUMN/2 -7);

    refresh();

    char USERNAME[100];

    while(TRUE) { //get valid username

        mvprintw(2*ROW/3,COLUMN/2 -8,">");

        move(2*ROW/3, COLUMN/2 -7);

        getstr(USERNAME);

        if(strlen(USERNAME)==0) {

            CLEAR_TEXT_FOR_LOGIN_ERRORS();

            mvprintw(ROW/3 +2 , COLUMN/2 -9,"Username Is Empty");

            RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

            continue;

        }

        if(strlen(USERNAME)>15) {

            CLEAR_TEXT_FOR_LOGIN_ERRORS();

            mvprintw(ROW/3+2 , COLUMN/2 -14 ,"Username Is Longer Than 15");

            RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

            continue;

        }

        if(strchr(USERNAME,' ')!=NULL) {

            CLEAR_TEXT_FOR_LOGIN_ERRORS();

            mvprintw(ROW/3+2 , COLUMN/2 -13 ,"Username Contains Spaces");

            RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

            continue;

        }

        int IS_DUPLICATE=FALSE;

        while(TRUE) {

            char USER_RECORDS[16];

            if(fscanf(USERS," %s",USER_RECORDS)!=EOF) {

                if(strcmp(USER_RECORDS,USERNAME)==0) {

                    IS_DUPLICATE=TRUE;

                    CLEAR_TEXT_FOR_LOGIN_ERRORS();

                    mvprintw(ROW/3+2, COLUMN/2 -12 , "Username Already Taken");

                    RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

                    rewind(USERS);

                    break;

                }
                
                fscanf(USERS," %s",USER_RECORDS);

            }

            else {

                break;

            }
        }

        if(IS_DUPLICATE==FALSE)
            break;
    }

    char PASSWORD[100];

    clear();

    attroff(GOLD_COLORED_CELL);

    attron(MAGENTA_COLORED_CELL);

    for(int i=0 ; i<8 ; i++) {
        mvprintw(1+i,COLUMN/2 - strlen(register_art[0])/2,"%s",register_art[i]);
    }

    attroff(MAGENTA_COLORED_CELL);

    attron(GREEN_COLORED_CELL);

    for(int i=0 ; i<10 ; i++) {
        mvprintw(ROW/2+i,1,"%s",lock[i]);
    }

    attroff(GREEN_COLORED_CELL);

    attron(GOLD_COLORED_CELL);

    mvprintw(ROW/3,COLUMN/2 -24,"Choose a Password. Enter r For a Random Password");

    attron(A_ITALIC);

    mvprintw(ROW/3 +1, COLUMN/2 -46 ,"Note : Must Be Longer Than 6 & Shorter Than 16; Have a Number, Lowercase, and Capital Letter");

    attroff(A_ITALIC);

    mvprintw(2*ROW/3 +1 ,COLUMN/2 - 7 ,"###############");

    move(2*ROW/3 , COLUMN/2 -7);

    refresh();

    //get valid password, clear error bar and text box each time

    while(TRUE) {

        mvprintw(2*ROW/3,COLUMN/2 -8,">");

        move(2*ROW/3, COLUMN/2 -7);

        getstr(PASSWORD);

        if(strcmp(PASSWORD,"r")==0 || strcmp(PASSWORD,"R")==0) {

            CLEAR_TEXT_FOR_LOGIN_ERRORS();

            attrset(GOLD_COLORED_CELL);

            mvprintw(2*ROW/3,COLUMN/2 -8,">");

            move(2*ROW/3, COLUMN/2 -7);

            attrset(GREEN_COLORED_CELL);

            mvprintw(ROW/3 +2 ,COLUMN/2 -26,"Random Password Generated. Press a Key to continue.");

            RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

            GENERATE_RANDOM_PASSWORD(PASSWORD);

            mvprintw(2*ROW/3,COLUMN/2 -strlen(PASSWORD)/2 ,"%s",PASSWORD);

            refresh();

            noecho();

            getch();

            echo();

            break;

        }

        if(strlen(PASSWORD)<7 || strlen(PASSWORD) >15) {

            CLEAR_TEXT_FOR_LOGIN_ERRORS();

            mvprintw(2*ROW/3,COLUMN/2 -8,">");

            move(2*ROW/3, COLUMN/2 -7);

            mvprintw(ROW/3+2,COLUMN/2 -12 ,"Invalid Password Length");

            RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

            continue;
        }

        int HAS_DIGIT=FALSE;

        for(char i='0' ; i<='9' ; i++) { //check for digit

            if(strchr(PASSWORD,i)!=NULL) {

                HAS_DIGIT=TRUE;

                break;

            }
        }

        if(HAS_DIGIT==FALSE) {

            CLEAR_TEXT_FOR_LOGIN_ERRORS();

            mvprintw(ROW/3 +2,COLUMN/2 -10 ,"Doesn't Have a Digit");

            RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

            continue;
        }       

        int HAS_LOWER=FALSE;

        for(char i='a' ; i<='z' ; i++) { //check for lowercase

            if(strchr(PASSWORD,i)!=NULL) {
                
                HAS_LOWER=TRUE;

                break;

            }
        }

        if(HAS_LOWER==FALSE) {

            CLEAR_TEXT_FOR_LOGIN_ERRORS();

            mvprintw(ROW/3 + 2,COLUMN/2-11 ,"Doesn't Have Lowercase");

            RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

            continue;

        }

        int HAS_CAPITAL=FALSE;

        for(char i='A' ; i<='Z' ; i++) { //check for capital

            if(strchr(PASSWORD,i)!=NULL) {

                HAS_CAPITAL=TRUE;

                break;

            }

        }

        if(HAS_CAPITAL==FALSE) {

            CLEAR_TEXT_FOR_LOGIN_ERRORS();

            mvprintw(ROW/3 +2,COLUMN/2 -10 ,"Doesn't Have Capital");

            RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

            continue;

        }

        break;
    }

    char EMAIL[100];

    clear();

    attroff(GOLD_COLORED_CELL);

    attron(MAGENTA_COLORED_CELL);

    for(int i=0 ; i<8 ; i++) {
        mvprintw(1+i,COLUMN/2 - strlen(register_art[0])/2,"%s",register_art[i]);
    }

    attroff(MAGENTA_COLORED_CELL);

    attron(GREEN_COLORED_CELL);

    for(int i=0 ; i<9 ; i++) {
        mvprintw(ROW/2+i,1,"%s",mail[i]);
    }



    attroff(GREEN_COLORED_CELL);

    attron(GOLD_COLORED_CELL);

    mvprintw(ROW/3,COLUMN/2-9,"Enter Your E-Mail");

    attron(A_ITALIC);

    mvprintw(ROW/3 +1,COLUMN/2 -27  ,"Entered E-Mail Must Be Valid and Not Be Longer than 40");

    attroff(A_ITALIC);

    mvprintw(2*ROW/3 +1, COLUMN/2 -20  ,"########################################");

    move(2*ROW/3, COLUMN/2 -20);

    refresh();
    //get valid email, clear error bar and text box each time
    
    while(TRUE) {

        mvprintw(2*ROW/3,COLUMN/2-21,">");

        move(2*ROW/3, COLUMN/2 -20);

        getstr(EMAIL);

        if(strlen(EMAIL)>40) {

            CLEAR_TEXT_FOR_LOGIN_ERRORS();

            mvprintw(ROW/3 +2 , COLUMN/2 -9 ,"Email Is Too Long");

            RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

            move(2*ROW/3, COLUMN/2 -20);

            refresh();

            continue;
        }

        if(strchr(EMAIL,' ')!=NULL || strchr(EMAIL,'@')==NULL || strchr(EMAIL,'.')==NULL) {

            CLEAR_TEXT_FOR_LOGIN_ERRORS();

            mvprintw(ROW/3 +2 ,COLUMN/2 -8  ,"Email Is Invalid");

            RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

            move(2*ROW/3, COLUMN/2 -20);

            refresh();

            continue;
        }

        if(VALIDATE_EMAIL(EMAIL)==FALSE) {

            CLEAR_TEXT_FOR_LOGIN_ERRORS();

            mvprintw(ROW/3 +2 ,COLUMN/2 -8  ,"Email Is Invalid");

            RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

            move(2*ROW/3, COLUMN/2 -20);

            refresh();

            continue;

        }
        break;
    }

    fprintf(USERS,"%s %s\n",USERNAME,PASSWORD);

    //store saved game and default settings later

    fclose(USERS);

    strcpy(GLOBAL_LOGGED_IN_USER,USERNAME);

    char FILE_NAME_FOR_USER[100]="saves_";

    strcat(FILE_NAME_FOR_USER,USERNAME);

    strcat(FILE_NAME_FOR_USER,".txt");

    FILE *SCOREBOARD=fopen("user_scores.txt","a+");

    fprintf(SCOREBOARD,"%s %d %d %d %d ",USERNAME,0,0,0,0);

    fclose(SCOREBOARD);

    FILE *SETTINGS=fopen("user_settings.txt","a+");

    fprintf(SETTINGS,"%s g r n f ",USERNAME);

    fclose(SETTINGS);

    FILE *SAVES=fopen(FILE_NAME_FOR_USER,"a+"); //create that .txt file.

    fclose(SAVES);

    noecho();

    curs_set(0);

    CLEAR_TEXT_FOR_LOGIN_ERRORS();

    RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

    mvprintw(2*ROW/3,COLUMN/2-21,">");

    move(2*ROW/3, COLUMN/2 -20);

    mvprintw(ROW/3+ 3,COLUMN/2 - 25,"Registeration Successful. Press a Key to Continue.");

    refresh();

    getch();

    attroff(COLOR_PAIR(1));

    

}
int USER_LOGIN() {

    clear();

    char login[][50]={
        " _        _______  _______ _________ _       ",
        "( \\      (  ___  )(  ____ \\__   __/( (    /|",
        "| (      | (   ) || (    \\/   ) (   |  \\  ( |",
        "| |      | |   | || |         | |   |   \\ | |",
        "| |      | |   | || | ____    | |   | (\\ \\) |",
        "| |      | |   | || | \\_  )   | |   | | \\   |",
        "| (____/\\| (___) || (___) |___) (___| )  \\  |",
        "(_______/(_______)(_______)\\_______/|/    )_)"
    };

    char quill[][30]={
        "                      .`.",
        "                   .`~.-:",
        "                  .`- . -`",
        "                .`-  . -`",
        "              .`-   . -`",
        "            .`-    . -`",
        "          .`-     . -`",
        "         `-      . -`",
        "       .`-      . -`",
        "      ;-       . -`",
        "     .-      .  -`",
        "    ;.      . -`",
        "   ;.     . -`",
        "   ::._.-`",
        "   (.-`",
        "   .Y(.",
        "  ((()))",
        "  _)==(_",
        " | .--. |",
        " | '--' |",
        " '------'"
    };

    char lock[][30]={
        "            .-\"\"-.",
        "           / .--. \\",
        "          / /    \\ \\",
        "          | |    | |",
        "          | |.-\"\"-.|",
        "         ///`.::::.`\\",
        "        ||| ::/  \\:: ;",
        "        ||; ::\\__/:: ;",
        "         \\\\\\ '::::' /",
        "          `=':-..-'`"
    };

    char password_art[][80]={
        " _______  _______  _______  _______           _______  _______  ______",  
        "(  ____ )(  ___  )(  ____ \\(  ____ \\|\\     /|(  ___  )(  ____ )(  __  \\", 
        "| (    )|| (   ) || (    \\/| (    \\/| )   ( || (   ) || (    )|| (  \\  )",
        "| (____)|| (___) || (_____ | (_____ | | _ | || |   | || (____)|| |   ) |",
        "|  _____)|  ___  |(_____  )(_____  )| |( )| || |   | ||     __)| |   | |",
        "| (      | (   ) |      ) |      ) || || || || |   | || (\\ (   | |   ) |",
        "| )      | )   ( |/\\____) |/\\____) || () () || (___) || ) \\ \\__| (__/  )",
        "|/       |/     \\|\\_______)\\_______)(_______)(_______)|/   \\__/(______/"
    };

    attron(MAGENTA_COLORED_CELL);

    for(int i=0 ; i<8 ; i++) {
        mvprintw(1+i,COLUMN/2 - strlen(login[0])/2 , "%s",login[i]);
    }

    attroff(MAGENTA_COLORED_CELL);

    attron(GREEN_COLORED_CELL);

    for(int i=0 ; i<21 ; i++) {
        mvprintw(ROW/4 +i,1,"%s",quill[i]);
    }


    attroff(GREEN_COLORED_CELL);

    attron(COLOR_PAIR(1));

    echo();

    curs_set(1);

    FILE * USER_PASSWORD_LIST=fopen("passwords.txt","r+");

    if(USER_PASSWORD_LIST==NULL) {

        USER_PASSWORD_LIST=fopen("passwords.txt","w+");

        fclose(USER_PASSWORD_LIST);

        USER_PASSWORD_LIST=fopen("passwords.txt","r+");

    }

    mvprintw(ROW/3,COLUMN/2 -37  ,"Enter Your Username. First Time ? Press r to Register or g to Play as Guest");

    mvprintw(2*ROW/3+1, COLUMN/2 - 7,"###############");

    refresh();

    char USERNAME[100];

    char PASSWORD[100];

    char CORRECT_PASSWORD[100];

    while (TRUE)  //check username
    {
        mvprintw(2*ROW/3,COLUMN/2 -8,">");

        move(2*ROW/3, COLUMN/2 -7);

        getstr(USERNAME);

        if(strcmp(USERNAME,"r")==0 || strcmp(USERNAME,"R")==0) {

            USER_REGISTERATION();

            return 1;

        }

        if(strcmp(USERNAME,"g")==0 || strcmp(USERNAME,"G")==0) {

            GLOBAL_IS_GUEST=TRUE;

            strcpy(GLOBAL_LOGGED_IN_USER,"Guest");

            CLEAR_TEXT_FOR_LOGIN_ERRORS();

            RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

            curs_set(0);

            mvprintw(2*ROW/3,COLUMN/2 -8,">");

            move(2*ROW/3, COLUMN/2 -7);

            mvprintw(ROW/3 +3 ,COLUMN/2 -26,"Temporary Login Successful. Press a Key to Continue.");

            refresh();

            getch();

            return 1;

        }

        int USER_EXISTS=FALSE;

        char USER_FROM_FILE[20];

        while(TRUE) {

            if(fscanf(USER_PASSWORD_LIST," %s",USER_FROM_FILE)!=EOF) {

                if(strcmp(USER_FROM_FILE,USERNAME)==0) {

                    USER_EXISTS=TRUE;

                    break;

                }

                fscanf(USER_PASSWORD_LIST," %s",USER_FROM_FILE);

                continue;

            }

            rewind(USER_PASSWORD_LIST);

            break;
        }

        if(USER_EXISTS==FALSE) {

            CLEAR_TEXT_FOR_LOGIN_ERRORS();

            mvprintw(ROW/3 +2,COLUMN/2 -11 ,"Username Doesn't Exist");

            RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

            continue;
        }

        fscanf(USER_PASSWORD_LIST," %s",CORRECT_PASSWORD);

        break;
    }
    
    //password gui and forgot my password

    clear();

    attroff(GOLD_COLORED_CELL);

    attron(MAGENTA_COLORED_CELL);

    for(int i=0 ; i<8 ; i++) {
        mvprintw(1+i,COLUMN/2 - strlen(password_art[0])/2,"%s",password_art[i]);
    }

    attroff(MAGENTA_COLORED_CELL);

    attron(GREEN_COLORED_CELL);

    for(int i=0 ; i<10 ; i++) {
        mvprintw(ROW/2 +i,1,"%s",lock[i]);
    }

    attroff(GREEN_COLORED_CELL);

    attron(GOLD_COLORED_CELL);

    mvprintw(ROW/3,COLUMN/2 -23,"Enter Your Password. Press f if You Forgot it.");

    mvprintw(2*ROW/3+1, COLUMN/2 - 7,"###############");

    move(2*ROW/3, COLUMN/2 -7);

    refresh();

    while(TRUE) {

        mvprintw(2*ROW/3,COLUMN/2 -8,">");

        move(2*ROW/3, COLUMN/2 -7);

        getstr(PASSWORD);

        if(strcmp(PASSWORD,CORRECT_PASSWORD)==0) {

            break;

        }

        if(strcmp("f",PASSWORD)==0 || strcmp("F",PASSWORD)==0) {

            mvprintw(ROW/3 +1,COLUMN/2 -18 ,"Hint : Your Password's Length is %lu.",strlen(CORRECT_PASSWORD));

            CLEAR_TEXT_FOR_LOGIN_ERRORS();

            RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

            continue;

        }

        CLEAR_TEXT_FOR_LOGIN_ERRORS();

        mvprintw(ROW/3 +2,COLUMN/2 -7,"Wrong Password");

        RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();
    }

    //display a welcome message and prompt to continue

    CLEAR_TEXT_FOR_LOGIN_ERRORS();

    RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR();

    curs_set(0);

    mvprintw(2*ROW/3,COLUMN/2 -8,">");

    move(2*ROW/3, COLUMN/2 -7);

    mvprintw(ROW/3 +3,COLUMN/2 -21 ,"Login Successful. Press a Key to Continue.");

    strcpy(GLOBAL_LOGGED_IN_USER,USERNAME);

    noecho();

    getch();

    attroff(COLOR_PAIR(1));

    curs_set(0);

    fclose(USER_PASSWORD_LIST);

}
void CLEAR_TEXT_FOR_LOGIN_ERRORS() {

    mvprintw(ROW/3+2 , COLUMN/2 -30 ,"                                                            ");

    mvprintw(2*ROW/3 , COLUMN/2-20 , "                                                           ");

    attroff(COLOR_PAIR(1));

    attron(COLOR_PAIR(3));
}
void RESET_CURSOR_AND_COLORS_FOR_LOGIN_ERROR() {

    attroff(COLOR_PAIR(3));

    attron(COLOR_PAIR(1));

    move(2*ROW/3 , COLUMN/2 -7);

    refresh();

}
void GENERATE_RANDOM_PASSWORD(char PASSWORD[]) {

    PASSWORD[0]=rand()%26 +'a';

    PASSWORD[1]=rand()%26 +'A';

    PASSWORD[2]=rand()%10 +'0';

    for(int i=3 ; i<7 ; i++) {

        PASSWORD[i]=rand()%94+'!';

    }

    PASSWORD[7]='\0';

}
int VALIDATE_EMAIL(char EMAIL[]) {
    int index=strlen(EMAIL)-1;

    while(EMAIL[index]!='.') {
        index--;
    }

    if(index==strlen(EMAIL)-1)
        return FALSE;

    if(EMAIL+index-strchr(EMAIL,'@')>=2)
        return TRUE;

    else 
        return FALSE;


}
int PRE_GAME_MENU() {

    PRINT_PREGAME_MENU();

    while(TRUE) {

        int INPUT=getch();

        int x,y;

        getyx(stdscr,y,x);

        if(y==ROW/5+1) {

            if(INPUT==KEY_DOWN) {

                attron(COLOR_PAIR(1));

                mvprintw(ROW/5+1,COLUMN/2 -4,"New Game");

                attroff(COLOR_PAIR(1));

                attron(COLOR_PAIR(2) | A_BLINK);

                mvprintw(2*ROW/5,COLUMN/2 -7,"Load Last Save");

                attroff(COLOR_PAIR(2)); attroff(A_BLINK);

                refresh();

            }

            else if(INPUT=='e' || INPUT=='E') {

                return 0;
            }
        }

        else if(y==2*ROW/5) {

            if(INPUT==KEY_UP) {

                attron(COLOR_PAIR(1));

                mvprintw(2*ROW/5,COLUMN/2 -7,"Load Last Save");

                attroff(COLOR_PAIR(1));

                attron(COLOR_PAIR(2) |A_BLINK);

                mvprintw(ROW/5+1,COLUMN/2 -4,"New Game");

                attroff(COLOR_PAIR(2)); attroff(A_BLINK);

                refresh();

            }
            if(INPUT==KEY_DOWN) {

                attron(COLOR_PAIR(1));

                mvprintw(2*ROW/5,COLUMN/2 -7,"Load Last Save");

                attroff(COLOR_PAIR(1));

                attron(COLOR_PAIR(2) |A_BLINK);

                mvprintw(3* ROW/5, COLUMN/2 -6,"Leaderboards");

                attroff(COLOR_PAIR(2)); attroff(A_BLINK);

                refresh();

            }
            if(INPUT=='e' || INPUT=='E') {

                GLOBAL_LOAD_SAVE=TRUE;

                return 0;

            }

        }

        else if(y==3* ROW/5) {
            
            if(INPUT==KEY_UP) {

                attron(COLOR_PAIR(1));

                mvprintw(3* ROW/5, COLUMN/2 -6,"Leaderboards");

                attroff(COLOR_PAIR(1));

                attron(COLOR_PAIR(2) |A_BLINK);

                mvprintw(2*ROW/5,COLUMN/2 -7,"Load Last Save");

                attroff(COLOR_PAIR(2)); attroff(A_BLINK);

                refresh();
            }

            else if(INPUT==KEY_DOWN) {

                attron(COLOR_PAIR(1));

                mvprintw(3* ROW/5, COLUMN/2 -6,"Leaderboards");

                attroff(COLOR_PAIR(1));

                attron(COLOR_PAIR(2) |A_BLINK);

                mvprintw(4*ROW/5 , COLUMN/2 -4,"Settings");

                attroff(COLOR_PAIR(2)); attroff(A_BLINK);

                refresh();
            }

            else if(INPUT=='e' || INPUT=='E') {//open leaderboards and then refresh the page once you are back

                OPEN_LEADERBOARDS();
                
                PRINT_PREGAME_MENU();

            }
        }

        else {//4/5 row

            if(INPUT==KEY_UP) {

                attron(COLOR_PAIR(1));

                mvprintw(4*ROW/5 , COLUMN/2 -4,"Settings");

                attroff(COLOR_PAIR(1));

                attron(COLOR_PAIR(2) | A_BLINK);

                mvprintw(3* ROW/5, COLUMN/2 -6,"Leaderboards");

                attroff(COLOR_PAIR(2)); attroff(A_BLINK);

                refresh();

            }

            else if(INPUT=='e' || INPUT=='E') {

                OPEN_SETTINGS();

                PRINT_PREGAME_MENU();

            }
        }

        

    }

}
void PRINT_PREGAME_MENU() {

    clear();

    noecho();

    curs_set(0);

    char menu_text[][40]={
        " _______  _______  _                ",
        "(       )(  ____ \\( (    /||\\     /|",
        "| () () || (    \\/|  \\  ( || )   ( |",
        "| || || || (__    |   \\ | || |   | |",
        "| |(_)| ||  __)   | (\\ \\) || |   | |",
        "| |   | || (      | | \\   || |   | |",
        "| )   ( || (____/\\| )  \\  || (___) |",
        "|/     \\|(_______/|/    )_)(_______)"
    };

    char sword[][40]={
        "                           .-.",
        "                          {{@}}",
        "          <>               8@8",
        "        .::::.             888",
        "    @\\\\/W\\/\\/W\\//@         8@8",
        "     \\\\/^\\/\\/^\\//     _    )8(    _",
        "      \\_O_<>_O_/     (@)__/8@8\\__(@)",
        " ____________________ `~\"-=):(=-\"~`",
        "|<><><>  |  |  <><><>|     |.|",
        "|<>      |  |      <>|     |S|",
        "|<>      |  |      <>|     |'|",
        "|<>   .--------.   <>|     |.|",
        "|     |   ()   |     |     |P|",
        "|_____| (O\\/O) |_____|     |'|",
        "|     \\   /\\   /     |     |.|",
        "|------\\  \\/  /------|     |U|",
        "|       '.__.'       |     |'|",
        "|        |  |        |     |.|",
        ":        |  |        :     |N|",
        " \\<>     |  |     <>/      |'|",
        "  \\<>    |  |    <>/       |.|",
        "   \\<>   |  |   <>/        |K|",
        "    `\\<> |  | <>/'         |'|",
        "      `-.|  |.-`           \\ /",
        "         '--'               ^"
    };

    char torch[][30]={
        "           /|",
        "        /\\/ |/\\",
        "        \\  ^   | /\\  /\\",
        "  (\\/\\  / ^   /\\/  )/^ )",
        "   \\  \\/^ /\\       ^  /",
        "    )^       ^ \\     (",
        "   (   ^   ^      ^\\  )",
        "    \\___\\/____/______/",
        "    [________________]",
        "     |              |",
        "     |     //\\\\     |",
        "     |    <<()>>    |",
        "     |     \\\\//     |",
        "      \\____________/",
        "          |    |",
        "          |    |",
        "          |    |",
        "          |    |",
        "          |    |",
        "          |    |",
        "          |    |"

    };

    attrset(MAGENTA_COLORED_CELL);

    for(int i=0 ; i<8 ; i++) {
        mvprintw(i,COLUMN/2 - strlen(menu_text[0])/2,"%s",menu_text[i]);
    }

    attroff(MAGENTA_COLORED_CELL);

    attron(RED_COLORED_CELL);

    for(int i=0 ; i<25 ; i++) {
        mvprintw(ROW/5+i,1,"%s",sword[i]);
    }

    for(int i=0 ; i<21 ; i++) {
        mvprintw(ROW/5 +i, 3*COLUMN/4,"%s",torch[i]);
    }



    attroff(RED_COLORED_CELL);

    attron(COLOR_PAIR(2) | A_BLINK);

    mvprintw(ROW/5+1,COLUMN/2 -4,"New Game");

    attroff(COLOR_PAIR(2)); attroff(A_BLINK);

    attron(COLOR_PAIR(1));

    mvprintw(2*ROW/5,COLUMN/2 -7,"Load Last Save");

    mvprintw(3* ROW/5, COLUMN/2 -6,"Leaderboards");

    mvprintw(4*ROW/5 , COLUMN/2 -4,"Settings");

    mvprintw(ROW-1,COLUMN/2 - 22,"Press e or E to Select and Arrow keys to Move");

    mvprintw(0,0,"Welcome %s!",GLOBAL_LOGGED_IN_USER);

    move(ROW/5+1,COLUMN/2 -4);

    attroff(COLOR_PAIR(1));

    refresh();
}
void OPEN_LEADERBOARDS() {

    char leaderboards_text[][120]={
        " _        _______  _______  ______   _______  _______  ______   _______  _______  _______  ______   _______ ",
        "( \\      (  ____ \\(  ___  )(  __  \\ (  ____ \\(  ____ )(  ___ \\ (  ___  )(  ___  )(  ____ )(  __  \\ (  ____ \\",
        "| (      | (    \\/| (   ) || (  \\  )| (    \\/| (    )|| (   ) )| (   ) || (   ) || (    )|| (  \\  )| (    \\/",
        "| |      | (__    | (___) || |   ) || (__    | (____)|| (__/ / | |   | || (___) || (____)|| |   ) || (_____ ",
        "| |      |  __)   |  ___  || |   | ||  __)   |     __)|  __ (  | |   | ||  ___  ||     __)| |   | |(_____  )",
        "| |      | (      | (   ) || |   ) || (      | (\\ (   | (  \\ \\ | |   | || (   ) || (\\ (   | |   ) |      ) |",
        "| (____/\\| (____/\\| )   ( || (__/  )| (____/\\| ) \\ \\__| )___) )| (___) || )   ( || ) \\ \\__| (__/  )/\\____) |",
        "(_______/(_______/|/     \\|(______/ (_______/|/   \\__/|/ \\___/ (_______)|/     \\||/   \\__/(______/ \\_______)"

    };

    char cup[][20]={
        "  ___________",
        " '._==_==_=_.'",
        " .-\\:      /-.",
        "| (|:.     |) |",
        " '-|:.     |-'",
        "   \\::.    /",
        "    '::. .'",
        "      ) (",
        "    _.' '._",
        "   `\"\"\"\"\"\"\"`"
    };

    char sword[][80]={
        "                 /\\",
        "                /  |",
        "  *            /  /________________________________________________",
        " (O)77777777777)  7                                                `~~--__",
        "8OO>>>>>>>>>>>>] <===========================================>          __-",
        " (O)LLLLLLLLLLL)  L________________________________________________.--~~",
        "  *            \\  \\",
        "                \\  |",
        "                 \\/"
    };

    attrset(MAGENTA_COLORED_CELL);

    for(int i=0 ; i<8 ; i++) {
        mvprintw(i,COLUMN/2 - strlen(leaderboards_text[0])/2,"%s",leaderboards_text[i]);
    }

    attroff(MAGENTA_COLORED_CELL);

    attron(RED_COLORED_CELL);

    for(int i=0 ; i<9 ; i++) {
        mvprintw(9+i,COLUMN/2 -strlen(sword[0])/2,"%s",sword[i]);
    }

    attroff(RED_COLORED_CELL);

    FILE *CREATE_FIRST=fopen("user_scores.txt","a+");

    fclose(CREATE_FIRST);
    
    FILE* SCORES_FILE=fopen("user_scores.txt","r+");

    SCORES_AND_DATA ALL_DATA[1000]; int index=0;

    while(fscanf(SCORES_FILE," %s",ALL_DATA[index].username)!=EOF) {

        fscanf(SCORES_FILE,"%d %d %d %d",&ALL_DATA[index].total_score,
        
        &ALL_DATA[index].total_gold,&ALL_DATA[index].number_of_games,&ALL_DATA[index].time_played);

        index++;

    }//index will be the number of users. index-1 is the last array address filled.

    for(int i=0 ; i<8 ; i++) {
        strcpy(ALL_DATA[index+i].username,"\0");
    }

    //sort data according to score.

    for(int i=0 ; i<index ; i++) {//sort from large to small.

        for(int j=i+1 ; j<index ; j++) {

            if(ALL_DATA[i].total_score<ALL_DATA[j].total_score) {

                SCORES_AND_DATA TEMP;

                TEMP=ALL_DATA[i];

                ALL_DATA[i]=ALL_DATA[j];

                ALL_DATA[j]=TEMP;
            }
        }
    }

    int CURRENT_USERS_INDEX=-1;

    if(GLOBAL_IS_GUEST==FALSE) {//find logged in user's ranking

        for(int i=0 ; i<index ; i++) {

            if(strcmp(GLOBAL_LOGGED_IN_USER,ALL_DATA[i].username)==0) {

                CURRENT_USERS_INDEX=i;

                break;
            }

        }





    }

    int CURSOR_LOCATION=0; int INPUT;

    while(TRUE) {

        clear();

        attrset(MAGENTA_COLORED_CELL);

        for(int i=0 ; i<8 ; i++) {
            mvprintw(1+i,COLUMN/2 - strlen(leaderboards_text[0])/2,"%s",leaderboards_text[i]);
        }

        attroff(MAGENTA_COLORED_CELL);

        attron(RED_COLORED_CELL);

        for(int i=0 ; i<9 ; i++) {
            mvprintw(9+i,COLUMN/2 -strlen(sword[4])/2,"%s",sword[i]);
        }

        attroff(RED_COLORED_CELL);

        attrset(GOLD_COLORED_CELL ); 

        for(int i=0 ; i<10 ; i++) {
            mvprintw(ROW/2+i,4,"%s",cup[i]);
        }

        mvprintw(3*ROW/4 -1,COLUMN/2 -32,"Rank| Username    |     Score   |   Gold   |    Games Played  |  Time Played");
        
        mvprintw(ROW/2 +1,COLUMN/2 -25 ,"Scroll to See Full List. Press Backspace to Exit.");

        attroff(GOLD_COLORED_CELL);

        for(int i=CURSOR_LOCATION ; i<CURSOR_LOCATION+5 ; i++) {

            if(strcmp("\0",ALL_DATA[i].username)==0) {

                break;

            }

            if(i==0) {

                attrset(RED_HIGHLIGHT | A_ITALIC);

                mvprintw(3*ROW/4+i-CURSOR_LOCATION,COLUMN/2 -38,"🥇GOAT");

            }

            if(i==1) {

                attrset(BLUE_HIGHLIGHT |A_ITALIC);

                mvprintw(3*ROW/4+i-CURSOR_LOCATION,COLUMN/2 -38,"🥈GOAT");

            }

            if(i==2) {

                attrset(GREEN_HIGHLIGHT | A_ITALIC);

                mvprintw(3*ROW/4+i-CURSOR_LOCATION,COLUMN/2 -38,"🥉GOAT");

            }

            if(i!=0 && i!=1 && i!=2) {

                attrset(GOLD_COLORED_CELL);
            }

            move(3*ROW/4+i-CURSOR_LOCATION,COLUMN/2 -31);

            printw("%d    %s",i+1,ALL_DATA[i].username);

            mvprintw(3*ROW/4+i-CURSOR_LOCATION,COLUMN/2 -8,"%d",ALL_DATA[i].total_score);

            mvprintw(3*ROW/4+i-CURSOR_LOCATION,COLUMN/2 +4,"%d",ALL_DATA[i].total_gold);

            mvprintw(3*ROW/4+i-CURSOR_LOCATION,COLUMN/2 +16,"%d",ALL_DATA[i].number_of_games);

            mvprintw(3*ROW/4+i-CURSOR_LOCATION,COLUMN/2 +32,"%d d %d h %d m",ALL_DATA[i].time_played/86400,(ALL_DATA[i].time_played/3600)%24
            
            ,(ALL_DATA[i].time_played/60)%60);
            
            

            if(i==CURRENT_USERS_INDEX) {

                mvprintw(3*ROW/4+i-CURSOR_LOCATION,0,"--------->");

            }


        }

        refresh();

        INPUT=getch();

        if(INPUT==KEY_BACKSPACE) {
            break;
        }
        if(INPUT==KEY_DOWN) {

            if(strcmp(ALL_DATA[CURSOR_LOCATION+5].username,"\0")!=0) {
                CURSOR_LOCATION++;
            }

        }
        if(INPUT==KEY_UP) {

            if(CURSOR_LOCATION!=0) {
                CURSOR_LOCATION--;
            }

        }

    }
    
    attrset(GOLD_COLORED_CELL); attroff(GOLD_COLORED_CELL);
    
    fclose(SCORES_FILE);

}
void OPEN_SETTINGS() {

    PRINT_SETTINGS_MENU();

    while(TRUE) {

    int INPUT=getch();

    int x,y;

    getyx(stdscr,y,x);

    if(y==ROW/5+1) {

        if(INPUT==KEY_DOWN) {

            attron(COLOR_PAIR(1));

            mvprintw(ROW/5+1,COLUMN/2 - 5 ,"Difficulty");

            attroff(COLOR_PAIR(1));

            attron(COLOR_PAIR(2) | A_BLINK);

            mvprintw(2*ROW/5,COLUMN/2 -5  ,"Hero Color");

            attroff(COLOR_PAIR(2)); attroff(A_BLINK);

            refresh();

        }
        else if(INPUT=='e' || INPUT=='E') {
            
            OPEN_DIFFICULTY_MENU();

            PRINT_SETTINGS_MENU();

        }
    }
    else if(y==2*ROW/5) {

        if(INPUT==KEY_DOWN) {

            attron(COLOR_PAIR(1));

            mvprintw(2*ROW/5,COLUMN/2 -5  ,"Hero Color");

            attroff(COLOR_PAIR(1));

            attron(COLOR_PAIR(2) | A_BLINK);

            mvprintw(3*ROW/5 , COLUMN/2 - 3 ,"Music");

            attroff(COLOR_PAIR(2)); attroff(A_BLINK);

            refresh();

        }
        else if(INPUT==KEY_UP) {

            attron(COLOR_PAIR(1));

            mvprintw(2*ROW/5,COLUMN/2 -5  ,"Hero Color");

            attroff(COLOR_PAIR(1));

            attron(COLOR_PAIR(2) | A_BLINK);

            mvprintw(ROW/5+1,COLUMN/2 - 5 ,"Difficulty");

            attroff(COLOR_PAIR(2)); attroff(A_BLINK);

            refresh();

        }
        else if(INPUT=='e' || INPUT=='E') {

            OPEN_HERO_COLOR_MENU();

            PRINT_SETTINGS_MENU();
        }
    }

    else if(y==3*ROW/5) {

        if(INPUT==KEY_DOWN) {

            attron(COLOR_PAIR(1));

            mvprintw(3*ROW/5 , COLUMN/2 - 3 ,"Music");

            attroff(COLOR_PAIR(1));

            attron(COLOR_PAIR(2) | A_BLINK);

            mvprintw(4*ROW/5 , COLUMN/2 - 2 ,"Back");

            attroff(COLOR_PAIR(2)); attroff(A_BLINK);

            refresh();
        }

        else if(INPUT==KEY_UP) {

            attron(COLOR_PAIR(1));

            mvprintw(3*ROW/5 , COLUMN/2 - 3 ,"Music");

            attroff(COLOR_PAIR(1));

            attron(COLOR_PAIR(2) | A_BLINK);

            mvprintw(2*ROW/5,COLUMN/2 -5  ,"Hero Color");           

            attroff(COLOR_PAIR(2)); attroff(A_BLINK);

            refresh();
        }

        else if(INPUT=='e' || INPUT=='E') {

            OPEN_MUSIC_MENU();

            PRINT_SETTINGS_MENU();

        }
    }
    else {
        
        if(INPUT==KEY_UP) {

            attron(COLOR_PAIR(1));

            mvprintw(4*ROW/5 , COLUMN/2 - 2 ,"Back");

            attroff(COLOR_PAIR(1));

            attron(COLOR_PAIR(2) | A_BLINK);

            mvprintw(3*ROW/5 , COLUMN/2 - 3 ,"Music");

            attroff(COLOR_PAIR(2)); attroff(A_BLINK);

            refresh();

        }
        else if(INPUT=='e' || INPUT=='E') {
            
            break;

        }
    }

    }
}
void PRINT_SETTINGS_MENU() {

    clear();

    char gear[][35]={
        "              @@@@",
        "        #*   *@@@@+   *#",
        "      *@@@@@@@@@@@@@@@@@@#",
        "       @@@@@@@@@@@@@@@@@@",
        "       -@@@@@@%**%@@@@@@=",
        "    %@@@@@@@@      @@@@@@@@%",
        "    @@@@@@@@        @@@@@@@@:",
        "    %@@@@@@@@      @@@@@@@@%",
        "       -@@@@@@%**%@@@@@@=",
        "       %@@@@@@@@@@@@@@@@%",
        "       +@@@@@@@@@@@@@@@@*",
        "        ##   *@@@@+   ##",
        "              @@@@"
    };

    char settings_text[][75]={
        " _______  _______ ___________________________ _        _______  _______ ",
        "(  ____ \\(  ____ \\\\__   __/\\__   __/\\__   __/( (    /|(  ____ \\(  ____ \\",
        "| (    \\/| (    \\/   ) (      ) (      ) (   |  \\  ( || (    \\/| (    \\/",
        "| (_____ | (__       | |      | |      | |   |   \\ | || |      | (_____ ",
        "(_____  )|  __)      | |      | |      | |   | (\\ \\) || | ____ (_____  )",
        "      ) || (         | |      | |      | |   | | \\   || | \\_  )      ) |",
        "/\\____) || (____/\\   | |      | |   ___) (___| )  \\  || (___) |/\\____) |",
        "\\_______)(_______/   )_(      )_(   \\_______/|/    )_)(_______)\\_______)"
    };

    attron(GREEN_COLORED_CELL);

    for(int i=0 ; i<13 ; i++) {

        mvprintw(ROW/3+i,1,"%s",gear[i]);
        mvprintw(ROW/3+i,3*COLUMN/4,"%s",gear[i]);

    }

    attroff(GREEN_COLORED_CELL);

    attron(MAGENTA_COLORED_CELL);

    for(int i=0 ; i<8 ; i++) {
        mvprintw(i,COLUMN/2 - strlen(settings_text[0])/2,"%s",settings_text[i]);
    }

    attroff(MAGENTA_COLORED_CELL);

    attron(COLOR_PAIR(1));

    mvprintw(0,0,"Welcome %s!",GLOBAL_LOGGED_IN_USER);

    mvprintw(2*ROW/5,COLUMN/2 -5  ,"Hero Color");

    mvprintw(3*ROW/5 , COLUMN/2 - 3 ,"Music");

    mvprintw(4*ROW/5 , COLUMN/2 - 2 ,"Back");

    mvprintw(ROW-1,COLUMN/2 - 22,"Press e or E to Select and Arrow keys to Move");

    attroff(COLOR_PAIR(1));

    attron(COLOR_PAIR(2) | A_BLINK);

    mvprintw(ROW/5+1,COLUMN/2 - 5 ,"Difficulty");

    attroff(COLOR_PAIR(2)); attroff(A_BLINK);

    refresh();

}
void OPEN_MUSIC_MENU() {

    PRINT_MUSIC_MENU();

    while(TRUE) {

        int x,y;

        getyx(stdscr,y,x);

        char LARGE_STRING[70]="Current Music is : ";

        if(GLOBAL_SETTINGS.PLAY_MUSIC=='f') {

            attron(RED_COLORED_CELL); mvprintw(3,COLUMN/2 -27,"Music is Currently Off. Press Backspace to Turn it On.");

            attroff(RED_COLORED_CELL);

        }

        else {

            attron(GREEN_COLORED_CELL); mvprintw(3,COLUMN/2 -27,"Music is Currently On. Press Backspace to Turn it Off.");

            attroff(GREEN_COLORED_CELL);

        }

        char COLOR_SPELLED_OUT[100];

        if(GLOBAL_SETTINGS.MUSIC=='s') {
            strcpy(COLOR_SPELLED_OUT,"Sleep Away");
        }
        else if(GLOBAL_SETTINGS.MUSIC=='w') {
            strcpy(COLOR_SPELLED_OUT,"Sacrifice");
        }
        else if(GLOBAL_SETTINGS.MUSIC=='r'){
            strcpy(COLOR_SPELLED_OUT,"Never Gonna Give You Up");
        }

        strcat(LARGE_STRING,COLOR_SPELLED_OUT);

        attrset(GOLD_COLORED_CELL);

        mvprintw(1,COLUMN/2-36 ,"                                                                        ");

        mvprintw(1,COLUMN/2 -strlen(LARGE_STRING)/2,"%s",LARGE_STRING);

        attroff(GOLD_COLORED_CELL); refresh();

        int INPUT=getch();

        

        if(y==ROW/5) {

            if(INPUT==KEY_DOWN) {

                attron(GOLD_COLORED_CELL);

                mvprintw(ROW/5, COLUMN/2 -12 ,"Never Gonna Give You Up");

                attroff(GOLD_COLORED_CELL);

                attrset(GOLD_HIGHLIGHT | A_BLINK);

                mvprintw(2*ROW/5, COLUMN/2 -5 ,"Sleep Away");

                attroff(GOLD_HIGHLIGHT); attroff(A_BLINK);                

            }
            else if(INPUT=='e' || INPUT=='E') {

                GLOBAL_SETTINGS.MUSIC='r';

                move(ROW/5,0);

            }
            
            else if(INPUT==KEY_BACKSPACE) {

                if(GLOBAL_SETTINGS.PLAY_MUSIC=='t') {

                    GLOBAL_SETTINGS.PLAY_MUSIC='f';
                }
                else {

                    GLOBAL_SETTINGS.PLAY_MUSIC='t';
                }

                move(ROW/5 ,0);
            }
            else {
                move(ROW/5,0);
            }

        }
        else if(y==2*ROW/5) {

            if(INPUT==KEY_UP) {

                attron(GOLD_COLORED_CELL);

                mvprintw(2*ROW/5, COLUMN/2 -5 ,"Sleep Away");

                attroff(GOLD_COLORED_CELL);

                attrset(GOLD_HIGHLIGHT | A_BLINK);

                mvprintw(ROW/5, COLUMN/2 -12 ,"Never Gonna Give You Up");

                attroff(GOLD_HIGHLIGHT); attroff(A_BLINK);

                refresh();

            }
            else if(INPUT==KEY_DOWN) {

                attron(GOLD_COLORED_CELL);

                mvprintw(2*ROW/5, COLUMN/2 -5 ,"Sleep Away");

                attroff(GOLD_COLORED_CELL);

                attrset(GOLD_HIGHLIGHT | A_BLINK);

                mvprintw(3*ROW/5, COLUMN/2 -5 ,"Sacrifice");

                attroff(GOLD_HIGHLIGHT); attroff(A_BLINK);

                refresh();

            }
            else if(INPUT=='e' || INPUT=='E') {
                GLOBAL_SETTINGS.MUSIC='s';

                move(2*ROW/5,0);
            }
            
            else if(INPUT==KEY_BACKSPACE) {

                if(GLOBAL_SETTINGS.PLAY_MUSIC=='t') {

                    GLOBAL_SETTINGS.PLAY_MUSIC='f';
                }
                else {

                    GLOBAL_SETTINGS.PLAY_MUSIC='t';
                }

                move(2*ROW/5,0);
            }

            else {
                move(2*ROW/5,0);
            }
        }
        else if(y==3*ROW/5) {

            if(INPUT==KEY_UP) {

                attron(GOLD_COLORED_CELL);

                mvprintw(3*ROW/5, COLUMN/2 -5 ,"Sacrifice");

                attroff(GOLD_COLORED_CELL);

                attrset(GOLD_HIGHLIGHT | A_BLINK);

                mvprintw(2*ROW/5, COLUMN/2 -5 ,"Sleep Away");

                attroff(GOLD_HIGHLIGHT); attroff(A_BLINK);

                refresh();

            }
            else if(INPUT==KEY_DOWN) {

                attron(GOLD_COLORED_CELL);

                mvprintw(3*ROW/5, COLUMN/2 -5 ,"Sacrifice");

                attroff(GOLD_COLORED_CELL);

                attrset(GOLD_HIGHLIGHT | A_BLINK);

                mvprintw(4*ROW/5, COLUMN/2 -2 ,"Back");

                attroff(GOLD_HIGHLIGHT); attroff(A_BLINK);

                refresh();

            }
            else if(INPUT=='e' || INPUT=='E') {
                GLOBAL_SETTINGS.MUSIC='w';

                move(3*ROW/5,0);
            }
            
            else if(INPUT==KEY_BACKSPACE) {

                if(GLOBAL_SETTINGS.PLAY_MUSIC=='t') {

                    GLOBAL_SETTINGS.PLAY_MUSIC='f';
                }
                else {

                    GLOBAL_SETTINGS.PLAY_MUSIC='t';
                }

                move(3*ROW/5,0);
            }
            else {
                move(3*ROW/5,0);
            }
        }
        else {

            if(INPUT==KEY_UP) {

                attron(GOLD_COLORED_CELL);

                mvprintw(4*ROW/5, COLUMN/2 -2 ,"Back");

                attroff(GOLD_COLORED_CELL);

                attrset(GOLD_HIGHLIGHT | A_BLINK);

                mvprintw(3*ROW/5, COLUMN/2 -5 ,"Sacrifice");

                attroff(GOLD_HIGHLIGHT); attroff(A_BLINK);

                refresh();

            }
            else if(INPUT=='e' || INPUT=='E') {
                
                break;

            }
            
            else if(INPUT==KEY_BACKSPACE) {

                if(GLOBAL_SETTINGS.PLAY_MUSIC=='t') {

                    GLOBAL_SETTINGS.PLAY_MUSIC='f';
                }
                else {

                    GLOBAL_SETTINGS.PLAY_MUSIC='t';
                }

                move(4*ROW/5,0);
            }
            else {
                move(4*ROW/5,0);
            }
        }

    }

    if(GLOBAL_IS_GUEST==FALSE) {//write final result in file

        FILE* SETTINGS_FILE=fopen("user_settings.txt","r");

        char TEMP_STRING[100000];

        fgets(TEMP_STRING,100000,SETTINGS_FILE);

        char *PTR=strstr(TEMP_STRING,GLOBAL_LOGGED_IN_USER); 

        PTR+=strlen(GLOBAL_LOGGED_IN_USER)+1;//move PTR to first char location g r n f  \green rickroll normal false/

        PTR[2]=GLOBAL_SETTINGS.MUSIC; PTR[6]=GLOBAL_SETTINGS.PLAY_MUSIC;

        fclose(SETTINGS_FILE);

        FILE *WRITE_MODE_PTR=fopen("user_settings.txt","w");

        fprintf(WRITE_MODE_PTR,"%s",TEMP_STRING);

        fclose(WRITE_MODE_PTR); 

    }


}
void OPEN_DIFFICULTY_MENU() {

    PRINT_DIFFICULTY_MENU();

    while(TRUE) {

        int x,y;

        getyx(stdscr,y,x);

        char LARGE_STRING[70]="Current Difficulty is : ";

        char COLOR_SPELLED_OUT[10];

        if(GLOBAL_SETTINGS.DIFFICULTY=='h') {
            strcpy(COLOR_SPELLED_OUT,"Hard");
        }
        else if(GLOBAL_SETTINGS.DIFFICULTY=='e') {
            strcpy(COLOR_SPELLED_OUT,"Easy");
        }
        else if(GLOBAL_SETTINGS.DIFFICULTY=='n'){
            strcpy(COLOR_SPELLED_OUT,"Normal");
        }

        strcat(LARGE_STRING,COLOR_SPELLED_OUT);

        attrset(GOLD_COLORED_CELL);

        mvprintw(1,COLUMN/2-36 ,"                                                                        ");

        mvprintw(1,COLUMN/2 -strlen(LARGE_STRING)/2,"%s",LARGE_STRING);

        attroff(GOLD_COLORED_CELL);

        int INPUT=getch();

        if(y==ROW/5) {

            if(INPUT==KEY_DOWN) {

                attron(GOLD_COLORED_CELL);

                mvprintw(ROW/5, COLUMN/2 -2 ,"Easy");

                attroff(GOLD_COLORED_CELL);

                attrset(GOLD_HIGHLIGHT | A_BLINK);

                mvprintw(2*ROW/5, COLUMN/2 -3 ,"Normal");

                attroff(GOLD_HIGHLIGHT); attrset(A_BLINK);                

            }
            else if(INPUT=='e' || INPUT=='E') {

                GLOBAL_SETTINGS.DIFFICULTY='e';

                move(ROW/5,0);

            }
            else {
                move(ROW/5,0);
            }

        }
        else if(y==2*ROW/5) {

            if(INPUT==KEY_UP) {

                attron(GOLD_COLORED_CELL);

                mvprintw(2*ROW/5, COLUMN/2 -3 ,"Normal");

                attroff(GOLD_COLORED_CELL);

                attrset(GOLD_HIGHLIGHT | A_BLINK);

                mvprintw(ROW/5, COLUMN/2 -2 ,"Easy");

                attroff(GOLD_HIGHLIGHT); attrset(A_BLINK);

                refresh();

            }
            else if(INPUT==KEY_DOWN) {

                attron(GOLD_COLORED_CELL);

                mvprintw(2*ROW/5, COLUMN/2 -3 ,"Normal");

                attroff(GOLD_COLORED_CELL);

                attrset(GOLD_HIGHLIGHT | A_BLINK);

                mvprintw(3*ROW/5, COLUMN/2 -2 ,"Hard");

                attroff(GOLD_HIGHLIGHT); attrset(A_BLINK);

                refresh();

            }
            else if(INPUT=='e' || INPUT=='E') {
                GLOBAL_SETTINGS.DIFFICULTY='n';

                move(2*ROW/5,0);
            }
            else {
                move(2*ROW/5,0);
            }
        }
        else if(y==3*ROW/5) {

            if(INPUT==KEY_UP) {

                attron(GOLD_COLORED_CELL);

                mvprintw(3*ROW/5, COLUMN/2 -2 ,"Hard");

                attroff(GOLD_COLORED_CELL);

                attrset(GOLD_HIGHLIGHT | A_BLINK);

                mvprintw(2*ROW/5, COLUMN/2 -3 ,"Normal");

                attroff(GOLD_HIGHLIGHT); attrset(A_BLINK);

                refresh();

            }
            else if(INPUT==KEY_DOWN) {

                attron(GOLD_COLORED_CELL);

                mvprintw(3*ROW/5, COLUMN/2 -2 ,"Hard");

                attroff(GOLD_COLORED_CELL);

                attrset(GOLD_HIGHLIGHT | A_BLINK);

                mvprintw(4*ROW/5, COLUMN/2 -2 ,"Back");

                attroff(GOLD_HIGHLIGHT); attrset(A_BLINK);

                refresh();

            }
            else if(INPUT=='e' || INPUT=='E') {
                GLOBAL_SETTINGS.DIFFICULTY='h';

                move(3*ROW/5,0);
            }
            else {
                move(3*ROW/5,0);
            }
        }
        else {

            if(INPUT==KEY_UP) {

                attron(GOLD_COLORED_CELL);

                mvprintw(4*ROW/5, COLUMN/2 -2 ,"Back");

                attroff(GOLD_COLORED_CELL);

                attrset(GOLD_HIGHLIGHT | A_BLINK);

                mvprintw(3*ROW/5, COLUMN/2 -2 ,"Hard");

                attroff(GOLD_HIGHLIGHT); attrset(A_BLINK);

                refresh();

            }
            else if(INPUT=='e' || INPUT=='E') {
                
                break;

            }
            else {
                move(4*ROW/5,0);
            }
        }

        

    }

    if(GLOBAL_IS_GUEST==FALSE) {//write final result in file

        FILE* SETTINGS_FILE=fopen("user_settings.txt","r");

        char TEMP_STRING[100000];

        fgets(TEMP_STRING,100000,SETTINGS_FILE);

        char *PTR=strstr(TEMP_STRING,GLOBAL_LOGGED_IN_USER); 

        PTR+=strlen(GLOBAL_LOGGED_IN_USER)+1;//move PTR to first char location w s n

        PTR[4]=GLOBAL_SETTINGS.DIFFICULTY;

        fclose(SETTINGS_FILE);

        FILE *WRITE_MODE_PTR=fopen("user_settings.txt","w");

        fprintf(WRITE_MODE_PTR,"%s",TEMP_STRING);

        fclose(WRITE_MODE_PTR); 

    }


}
void OPEN_HERO_COLOR_MENU() {
    
    PRINT_COLOR_GUI();

    while(TRUE) {

        int x,y;

        getyx(stdscr,y,x);

        char LARGE_STRING[70]="Current Color is : ";

        char COLOR_SPELLED_OUT[10];

        if(GLOBAL_SETTINGS.HERO_COLOR=='r') {
            strcpy(COLOR_SPELLED_OUT,"Red");
        }
        else if(GLOBAL_SETTINGS.HERO_COLOR=='b') {
            strcpy(COLOR_SPELLED_OUT,"Blue");
        }
        else if(GLOBAL_SETTINGS.HERO_COLOR=='g'){
            strcpy(COLOR_SPELLED_OUT,"Green");
        }

        strcat(LARGE_STRING,COLOR_SPELLED_OUT);

        attrset(GOLD_COLORED_CELL);

        mvprintw(1,COLUMN/2-36 ,"                                                                        ");

        mvprintw(1,COLUMN/2 -strlen(LARGE_STRING)/2,"%s",LARGE_STRING);

        attroff(GOLD_COLORED_CELL);

        int INPUT=getch();

        if(y==ROW/5) {

            if(INPUT==KEY_DOWN) {

                attron(RED_COLORED_CELL);

                mvprintw(ROW/5, COLUMN/2 -2 ,"Red");

                attroff(RED_COLORED_CELL);

                attrset(GREEN_HIGHLIGHT | A_BLINK);

                mvprintw(2*ROW/5, COLUMN/2 -3 ,"Green");

                attroff(GREEN_HIGHLIGHT); attrset(A_BLINK);                

            }
            else if(INPUT=='e' || INPUT=='E') {

                GLOBAL_SETTINGS.HERO_COLOR='r';

                move(ROW/5,0);

            }
            else {
                move(ROW/5,0);
            }

        }
        else if(y==2*ROW/5) {

            if(INPUT==KEY_UP) {

                attron(GREEN_COLORED_CELL);

                mvprintw(2*ROW/5, COLUMN/2 -3 ,"Green");

                attroff(GREEN_COLORED_CELL);

                attrset(RED_HIGHLIGHT | A_BLINK);

                mvprintw(ROW/5, COLUMN/2 -2 ,"Red");

                attroff(RED_HIGHLIGHT); attrset(A_BLINK);

                refresh();

            }
            else if(INPUT==KEY_DOWN) {

                attron(GREEN_COLORED_CELL);

                mvprintw(2*ROW/5, COLUMN/2 -3 ,"Green");

                attroff(GREEN_COLORED_CELL);

                attrset(BLUE_HIGHLIGHT | A_BLINK);

                mvprintw(3*ROW/5, COLUMN/2 -2 ,"Blue");

                attroff(BLUE_HIGHLIGHT); attrset(A_BLINK);

                refresh();

            }
            else if(INPUT=='e' || INPUT=='E') {
                GLOBAL_SETTINGS.HERO_COLOR='g';

                move(2*ROW/5,0);
            }
            else {
                move(2*ROW/5,0);
            }
        }
        else if(y==3*ROW/5) {

            if(INPUT==KEY_UP) {

                attron(BLUE_COLORED_CELL);

                mvprintw(3*ROW/5, COLUMN/2 -2 ,"Blue");

                attroff(BLUE_COLORED_CELL);

                attrset(GREEN_HIGHLIGHT | A_BLINK);

                mvprintw(2*ROW/5, COLUMN/2 -3 ,"Green");

                attroff(GREEN_HIGHLIGHT); attrset(A_BLINK);

                refresh();

            }
            else if(INPUT==KEY_DOWN) {

                attron(BLUE_COLORED_CELL);

                mvprintw(3*ROW/5, COLUMN/2 -2 ,"Blue");

                attroff(BLUE_COLORED_CELL);

                attrset(GOLD_HIGHLIGHT | A_BLINK);

                mvprintw(4*ROW/5, COLUMN/2 -2 ,"Back");

                attroff(GOLD_HIGHLIGHT); attrset(A_BLINK);

                refresh();

            }
            else if(INPUT=='e' || INPUT=='E') {
                GLOBAL_SETTINGS.HERO_COLOR='b';

                move(3*ROW/5,0);
            }
            else {
                move(3*ROW/5,0);
            }
        }
        else {

            if(INPUT==KEY_UP) {

                attron(GOLD_COLORED_CELL);

                mvprintw(4*ROW/5, COLUMN/2 -2 ,"Back");

                attroff(GOLD_COLORED_CELL);

                attrset(BLUE_HIGHLIGHT | A_BLINK);

                mvprintw(3*ROW/5, COLUMN/2 -2 ,"Blue");

                attroff(BLUE_HIGHLIGHT); attrset(A_BLINK);

                refresh();

            }
            else if(INPUT=='e' || INPUT=='E') {
                
                break;

            }
            else {
                move(4*ROW/5,0);
            }
        }

    }

    if(GLOBAL_IS_GUEST==FALSE) {//write final result in file

        FILE* SETTINGS_FILE=fopen("user_settings.txt","r");

        char TEMP_STRING[100000];

        fgets(TEMP_STRING,100000,SETTINGS_FILE);

        char *PTR=strstr(TEMP_STRING,GLOBAL_LOGGED_IN_USER); 

        PTR+=strlen(GLOBAL_LOGGED_IN_USER)+1;//move PTR to first char location g s n

        PTR[0]=GLOBAL_SETTINGS.HERO_COLOR;

        fclose(SETTINGS_FILE);

        FILE *WRITE_MODE_PTR=fopen("user_settings.txt","w");

        fprintf(WRITE_MODE_PTR,"%s",TEMP_STRING);

        fclose(WRITE_MODE_PTR); 

    }


}
void HANDLE_GUEST_USER() {

    GLOBAL_SETTINGS.DIFFICULTY='n';

    GLOBAL_SETTINGS.HERO_COLOR='g';

    GLOBAL_SETTINGS.MUSIC='s'; //sleep away, rick roll, sacrifice

    GLOBAL_SETTINGS.PLAY_MUSIC='f';

}
void PRINT_COLOR_GUI() {

    clear();

    char h[][30]={
        "          _____",          
        "         /\\    \\",         
        "        /::\\____\\",        
        "       /:::/    /",        
        "      /:::/    /",         
        "     /:::/    /",          
        "    /:::/____/",           
        "   /::::\\    \\",           
        "  /::::::\\    \\   _____",  
        " /:::/\\:::\\    \\ /\\    \\", 
        "/:::/  \\:::\\    /::\\____\\",
        "\\::/    \\:::\\  /:::/    /",
        " \\/____/ \\:::\\/:::/    /", 
        "          \\::::::/    /",  
        "           \\::::/    /",   
        "           /:::/    /",    
        "          /:::/    /",     
        "         /:::/    /",      
        "        /:::/    /",       
        "        \\::/    /",        
        "         \\/____/"
    };

    noecho();

    curs_set(0);
    if(GLOBAL_SETTINGS.HERO_COLOR=='r') {
        attrset(RED_COLORED_CELL);
    }
    else if(GLOBAL_SETTINGS.HERO_COLOR=='g') {
        attrset(GREEN_COLORED_CELL);
    }
    else if(GLOBAL_SETTINGS.HERO_COLOR=='b') {
        attrset(BLUE_COLORED_CELL);
    }
    

    for(int i=0 ; i<21 ; i++) {
        mvprintw(ROW/4+i,1,"%s",h[i]);
        mvprintw(ROW/4+i,3*COLUMN/4,"%s",h[i]);
    }

    attrset(GOLD_COLORED_CELL);

    char LARGE_STRING[70]="Current Color is : ";

    char COLOR_SPELLED_OUT[10];

    if(GLOBAL_SETTINGS.HERO_COLOR=='r') {
        strcpy(COLOR_SPELLED_OUT,"Red");
    }
    else if(GLOBAL_SETTINGS.HERO_COLOR=='g') {
        strcpy(COLOR_SPELLED_OUT,"Green");
    }
    else if(GLOBAL_SETTINGS.HERO_COLOR=='b'){
        strcpy(COLOR_SPELLED_OUT,"Blue");
    }

    strcat(LARGE_STRING,COLOR_SPELLED_OUT);

    mvprintw(1,COLUMN/2-36 ,"                                                                        ");

    mvprintw(1,COLUMN/2 -strlen(LARGE_STRING)/2,"%s",LARGE_STRING);

    attroff(GOLD_COLORED_CELL);

    attron(GREEN_COLORED_CELL);

    mvprintw(2*ROW/5,COLUMN/2 -3,"Green");

    attroff(GREEN_COLORED_CELL);

    attron(BLUE_COLORED_CELL);

    mvprintw(3*ROW/5, COLUMN/2 -2,"Blue");

    attroff(BLUE_COLORED_CELL);

    attron(GOLD_COLORED_CELL);

    mvprintw(4*ROW/5,COLUMN/2 -2 ,"Back");

    attroff(GOLD_COLORED_CELL); 

    attron(RED_HIGHLIGHT | A_BLINK);

    mvprintw(ROW/5, COLUMN/2 -2 ,"Red");

    attroff(RED_HIGHLIGHT); attroff(A_BLINK);

    refresh();

}

void LOAD_USER_SETTINGS() {

    FILE *SETTINGS_FILE=fopen("user_settings.txt","r");

    char USER_FROM_FILE[20]; char DUMMY_VAR;

    while(TRUE) {

        fscanf(SETTINGS_FILE," %s",USER_FROM_FILE);

        if(strcmp(USER_FROM_FILE,GLOBAL_LOGGED_IN_USER)==0) {

            fscanf(SETTINGS_FILE," %c",&GLOBAL_SETTINGS.HERO_COLOR);

            fscanf(SETTINGS_FILE," %c",&GLOBAL_SETTINGS.MUSIC);

            fscanf(SETTINGS_FILE," %c",&GLOBAL_SETTINGS.DIFFICULTY);

            fscanf(SETTINGS_FILE," %c",&GLOBAL_SETTINGS.PLAY_MUSIC);

            break;

        }

        fscanf(SETTINGS_FILE," %c",&DUMMY_VAR);    fscanf(SETTINGS_FILE," %c",&DUMMY_VAR);    fscanf(SETTINGS_FILE," %c",&DUMMY_VAR);

        fscanf(SETTINGS_FILE," %c",&DUMMY_VAR);

    }

    fclose(SETTINGS_FILE);

}

void HANDLE_SETTINGS() {

    if(GLOBAL_IS_GUEST==TRUE) {

        HANDLE_GUEST_USER();

    }

    else {

        LOAD_USER_SETTINGS();

    }
}

void PRINT_DIFFICULTY_MENU() {

    clear();

    noecho();

    curs_set(0);

    char LARGE_STRING[70]="Current Difficulty is : ";

    char COLOR_SPELLED_OUT[10];

    char skull[][40]={
        "                            ,--.",
        "                           {    }",
        "                           K,   }",
        "                          /  ~Y`",
        "                     ,   /   /",
        "                    {_'-K.__/",
        "                      `/-.__L._",
        "                      /  ' /`\\_}",
        "                     /  ' /",
        "             ____   /  ' /",
        "      ,-'~~~~    ~~/  ' /_",
        "    ,'             ``~~~  ',",
        "   (                        Y",
        "  {                         I",
        " {      -                    `,",
        " |       ',                   )",
        " |        |   ,..__      __. Y",
        " |    .,_./  Y ' / ^Y   J   )|",
        " \\           |' /   |   |   ||",
        "  \\          L_/    . _ (_,.'(",
        "   \\,   ,      ^^""' / |      )",
        "     \\_  \\          /,L]     /",
        "       '-_~-,       ` `   ./`",
        "          `'{_            )",
        "              ^^\\..___,.--`"
    };

    char swords[][80]={
        "           /\\                                                 /\\",
        " _         )( ______________________   ______________________ )(         _",
        "(_)///////(**)______________________> <______________________(**)\\\\\\\\\\\\\\(_)",
        "           )(                                                 )(",
        "           \\/                                                 \\/"
    };

    attrset(RED_COLORED_CELL);

    for(int i=0 ; i<25 ; i++) {
        mvprintw(5+i,1,"%s",skull[i]);
        mvprintw(5+i,3*COLUMN/4,"%s",skull[i]);
    }

    attroff(RED_COLORED_CELL);

    attron(MAGENTA_COLORED_CELL);

    for(int i=0 ; i<5 ; i++) {
        mvprintw(33+i,COLUMN/2 - strlen(swords[2])/2 , "%s",swords[i]);
    }


    attroff(MAGENTA_COLORED_CELL);

    if(GLOBAL_SETTINGS.DIFFICULTY=='h') {
        strcpy(COLOR_SPELLED_OUT,"Hard");
    }
    else if(GLOBAL_SETTINGS.DIFFICULTY=='e') {
        strcpy(COLOR_SPELLED_OUT,"Easy");
    }
    else if(GLOBAL_SETTINGS.DIFFICULTY=='n'){
        strcpy(COLOR_SPELLED_OUT,"Normal");
    }

    strcat(LARGE_STRING,COLOR_SPELLED_OUT);

    attrset(GOLD_COLORED_CELL);

    mvprintw(1,COLUMN/2 -strlen(LARGE_STRING)/2,"%s",LARGE_STRING);

    mvprintw(2*ROW/5,COLUMN/2 -3 ,"Normal");

    mvprintw(3*ROW/5,COLUMN/2 -2,"Hard");

    mvprintw(4*ROW/5, COLUMN/2 -2,"Back");

    attroff(GOLD_COLORED_CELL);

    attrset(GOLD_HIGHLIGHT | A_BLINK);

    mvprintw(ROW/5, COLUMN/2 -2 ,"Easy");

    attroff(GOLD_HIGHLIGHT); attrset(A_BLINK);

    refresh();

}

void PRINT_MUSIC_MENU() {

    clear();        

    noecho();

    curs_set(0);

    char LARGE_STRING[70]="Current Music is : ";

    char music_art[][30]={
        "              .+:",               
        "              -%%.",              
        "              -%%*.",             
        "              -%%%%%-",           
        "              -%%%%%%%+",         
        "              -%%#%%%%%#",        
        "              -%%-  =#%%+",       
        "              -%%-    +%#.",      
        "              -%%-     =:",       
        "          -####%%-",              
        "        *%%%%%%%%-",              
        "       *%%%%%%%%%:",              
        "       :#%%%%%%#.",               
        "         .:--."
    };

    char COLOR_SPELLED_OUT[100];

    if(GLOBAL_SETTINGS.MUSIC=='s') {
        strcpy(COLOR_SPELLED_OUT,"Sleep Away");
    }
    else if(GLOBAL_SETTINGS.MUSIC=='w') {
        strcpy(COLOR_SPELLED_OUT,"Sacrifice");
    }
    else if(GLOBAL_SETTINGS.MUSIC=='r'){
        strcpy(COLOR_SPELLED_OUT,"Never Gonna Give You Up");
    }

    strcat(LARGE_STRING,COLOR_SPELLED_OUT);

    attrset(MAGENTA_COLORED_CELL);

    for(int i=0 ; i<14 ; i++) {
        mvprintw(ROW/3+i,1,"%s",music_art[i]);
        mvprintw(ROW/3+i,3*COLUMN/4,"%s",music_art[i]);
    }



    attroff(MAGENTA_COLORED_CELL);

    attrset(GOLD_COLORED_CELL);

    mvprintw(1,COLUMN/2 -strlen(LARGE_STRING)/2,"%s",LARGE_STRING);

    mvprintw(2*ROW/5,COLUMN/2 -5 ,"Sleep Away");

    mvprintw(3*ROW/5,COLUMN/2 -5,"Sacrifice");

    mvprintw(4*ROW/5, COLUMN/2 -2,"Back");

    attroff(GOLD_COLORED_CELL);

    attrset(GOLD_HIGHLIGHT | A_BLINK);

    mvprintw(ROW/5, COLUMN/2 -12 ,"Never Gonna Give You Up");

    attroff(GOLD_HIGHLIGHT); attroff(A_BLINK);

    refresh();

}

void OPEN_GAME_LAUNCHER(int * OK_LAUNCH) {

    attrset(BLUE_SCREEN);

    for(int i=0 ; i<ROW ; i++) {
        for(int j=0 ; j<COLUMN ; j++) {
            printw(" ");
        }
    }

    char welcome[][100]={ 
    " _       __     __                             __",
    "| |     / /__  / /________  ____ ___  ___     / /",
    "| | /| / / _ \\/ / ___/ __ \\/ __ \\__ \\/ _ \\   / / ",
    "| |/ |/ /  __/ / /__/ /_/ / / / / / /  __/  /_/  ",
    "|__/|__/\\___/_/\\___/\\____/_/ /_/ /_/\\___/  (_)   "
    };

    char exclamation[][10]={
    " !!! ",
    "!!:!!",
    "!:::!",
    "!:::!",
    "!:::!",
    "!:::!",
    "!:::!",
    "!:::!",
    "!:::!",
    "!:::!",
    "!!:!!",
    " !!! ",
    "\0",
    " !!! ",
    "!!:!!",
    " !!! "
    };

    for(int i=0 ; i<5 ; i++) {
        mvprintw(ROW/3+i , COLUMN/2-strlen(welcome[0])/2,"%s",welcome[i]);
    }

    for(int i=0 ; i<16 ; i++) {
        mvprintw(ROW/3+i, COLUMN/5,"%s",exclamation[i]);
        mvprintw(ROW/3+i,4*COLUMN/5,"%s",exclamation[i]);
    }

    mvprintw(ROW/2, COLUMN/2 -9,"Launching Game...");

    if(ROW>=38 && COLUMN>=144) {
        attrset(GREEN_W_BLUE_BG);
        mvprintw(ROW/2 +2 , COLUMN/2 -24,"Your Screen Size is OK; Press a Key to Continue.");
        attrset(BLUE_SCREEN);
        refresh(); getch();
    }

    else {
        attrset(RED_W_BLUE_BG);
        mvprintw(ROW/2+2, COLUMN/2 -39,"Your Terminal Size is Too Small; Change it and try again. Press a key to exit.");
        attrset(BLUE_SCREEN);
        refresh();  getch();
        *OK_LAUNCH=FALSE;
    }

    attroff(BLUE_SCREEN);

    clear();
}





void LOAD_MAP_AND_INVENTORY(POINT MAP[4][38][144]) {

    if(GLOBAL_IS_GUEST==TRUE) {

        clear(); 

        attron(RED_COLORED_CELL); 

        mvprintw(ROW/2, COLUMN/2 -31, "As a Guest You Have No Saves. Press a Key to Create New Game.");

        attroff(RED_COLORED_CELL); refresh();

        getch();

        GENERATE_MAP(MAP);

    }

    else {

        char FILE_NAME[100]="saves_";

        strcat(FILE_NAME,GLOBAL_LOGGED_IN_USER);

        strcat(FILE_NAME,".txt");

        FILE *SAVES=fopen(FILE_NAME,"r+");

        char DUMMY_DATA[20];

        fgets(DUMMY_DATA,19,SAVES);

        rewind(SAVES);

        int TEMPORARY;

        char *USER_POINTER=strstr(DUMMY_DATA,GLOBAL_LOGGED_IN_USER);

        if(USER_POINTER==NULL) {

            clear(); 

            attron(RED_COLORED_CELL); 

            mvprintw(ROW/2, COLUMN/2 -24, "No Saves Found. Press a Key to Create New Game.");

            attroff(RED_COLORED_CELL); refresh();

            getch();

            GENERATE_MAP(MAP);
        }

        else {

            fscanf(SAVES,"%s",DUMMY_DATA);//get dummy username first

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.H_SPELL);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.S_SPELL);
            
            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.D_SPELL);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.MACE);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.DAGGER);
            
            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.WAND);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.ARROW);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.SWORD);
            
            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.GOLD);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.SCORE);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.FOOD_MAGIC);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.FOOD_ELITE);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.FOOD_SPOILED);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON);

            fscanf(SAVES,"%d",&GLOBAL_EFFECTS_STORAGE.D);

            fscanf(SAVES,"%d",&GLOBAL_EFFECTS_STORAGE.H);

            fscanf(SAVES,"%d",&GLOBAL_EFFECTS_STORAGE.S);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.HP);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.HUNGER);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.TIME_PLAYED);
            
            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.x);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.y);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.FLOOR);
            
            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.KEYS);

            fscanf(SAVES,"%d",&GLOBAL_INVENTORY_AND_COORDINATES.BROKEN_KEYS);

            for(int i=0 ; i<4 ; i++) {
                for(int j=0 ; j<38 ; j++) {
                    for(int k=0 ; k<144 ; k++) {
                        fscanf(SAVES," %c%c%c%c%c%c",&MAP[i][j][k].COLOR,&MAP[i][j][k].IS_DISCOVERED,&MAP[i][j][k].IS_START
                        
                        ,&MAP[i][j][k].PASSWORD_DOOR_TYPE,&MAP[i][j][k].REAL_CONTENTS,&MAP[i][j][k].SYMBOL);
                        
                    }
                }
            }

            for(int i=0 ; i<4 ; i++) {
                for(int j=0 ; j<6 ; j++) {
                    fscanf(SAVES,"%c",&GLOBAL_ALL_THEMES_COLOR[i][j]);
                }
            }

            for(int i=0 ; i<4 ; i++) {
                for(int j=0 ; j<6 ; j++) {
                    fscanf(SAVES,"%d %d %d %d %d %d %d %d",&GLOBAL_ALL_ENEMIES[i][j].DMG,&GLOBAL_ALL_ENEMIES[i][j].HP
                
                    ,&GLOBAL_ALL_ENEMIES[i][j].MAX_HP,&GLOBAL_ALL_ENEMIES[i][j].MAX_MOVE_TILES,&GLOBAL_ALL_ENEMIES[i][j].MOVES_LEFT,
                
                    &GLOBAL_ALL_ENEMIES[i][j].SYMBOL,&GLOBAL_ALL_ENEMIES[i][j].x,&GLOBAL_ALL_ENEMIES[i][j].y);
                }
            }
        
            for(int i=0 ; i<4 ; i++) { 

                fscanf(SAVES,"%d %d %d %d %d %d %d %d",&GLOBAL_BOSSES_IN_LAST_ROOM[i].DMG,&GLOBAL_BOSSES_IN_LAST_ROOM[i].HP
                    
                ,&GLOBAL_BOSSES_IN_LAST_ROOM[i].MAX_HP,&GLOBAL_BOSSES_IN_LAST_ROOM[i].MAX_MOVE_TILES,&GLOBAL_BOSSES_IN_LAST_ROOM[i].MOVES_LEFT,
                    
                &GLOBAL_BOSSES_IN_LAST_ROOM[i].SYMBOL,&GLOBAL_BOSSES_IN_LAST_ROOM[i].x,&GLOBAL_BOSSES_IN_LAST_ROOM[i].y);
            }
        
        
        }

        fclose(SAVES);

    }

}

void GENERATE_MAP(POINT MAP[4][38][144]) {

    for(int i=0 ; i<4 ; i++) {//default theme values
        for(int j=0 ; j<6 ; j++) {
            GLOBAL_ALL_THEMES_COLOR[i][j]=0;
        }
    }

    int NEXT_START=GENERATE_FLOOR_SKELETON(MAP[0],-1,1);

    NEXT_START=GENERATE_FLOOR_SKELETON(MAP[1],NEXT_START,2);

    NEXT_START=GENERATE_FLOOR_SKELETON(MAP[2],NEXT_START,3);

    NEXT_START=GENERATE_FLOOR_SKELETON(MAP[3],NEXT_START,4);

    for(int i=0 ; i<38 ; i++) {//find and store game exit and start in 1st and 4th floors. Specify player start coords

        for(int j=0 ; j<144 ; j++) {

            if(MAP[0][i][j].IS_START==1) {

                GLOBAL_INVENTORY_AND_COORDINATES.x=j;

                GLOBAL_INVENTORY_AND_COORDINATES.y=i;

                MAP[0][i][j].SYMBOL='H';

                MAP[0][i][j].REAL_CONTENTS='.';

                MAP[0][i][j].IS_START=0;

            }

            if(MAP[3][i][j].IS_START==-1) {

                MAP[3][i][j].SYMBOL='x';

                MAP[3][i][j].REAL_CONTENTS='x';

                MAP[3][i][j].IS_START=0;

            }

        }
    }

}

int GENERATE_FLOOR_SKELETON(POINT FLOOR[38][144],int START_SECTOR, int FLOOR_NUMBER) {

    for(int i=0 ; i<38 ; i++) {//insert default values for IS_DISCOVERED, SYMBOL, COLOR, IS_START, and passdoor type.

        for(int j=0 ; j<144 ; j++) {

            FLOOR[i][j].IS_DISCOVERED=0;

            FLOOR[i][j].SYMBOL=' ';

            FLOOR[i][j].IS_START=0;

            FLOOR[i][j].COLOR='w';

            FLOOR[i][j].PASSWORD_DOOR_TYPE='a';

        }

    }
    
    int X_START=rand()%27;  int Y_START=rand()%9+1; int BIG_OR_SMALL=rand()%2;

    if(BIG_OR_SMALL==1) {
        int door1=rand()%14+X_START+1;

        int door2=rand()%5+Y_START+1;

        int WINDOW_QUERRY=rand()%100+1;

        for(int i=X_START ; i<X_START+16 ; i++) {
            FLOOR[Y_START][i].SYMBOL='_';
        }

        for(int j=Y_START+1 ; j<=Y_START+5 ; j++) {
            FLOOR[j][X_START].SYMBOL='|';
            for(int i=X_START+1 ; i<X_START+15 ; i++) {

                FLOOR[j][i].SYMBOL='.';

            }
            FLOOR[j][X_START+15].SYMBOL='|';
        }

        for(int i=X_START ; i<X_START+16 ; i++) {
            FLOOR[Y_START+6][i].SYMBOL='_';
        }

        if(WINDOW_QUERRY<=20) {
            if(door1<X_START+14) {
                FLOOR[Y_START+6][door1+1].SYMBOL='=';
            }
            else {
                FLOOR[Y_START+6][door1-1].SYMBOL='=';
            }
        }

        FLOOR[door2][X_START+15].SYMBOL='+';

        FLOOR[Y_START+6][door1].SYMBOL='+';
    }
    else {

        int door1=rand()%11+X_START+1;

        int door2=rand()%4+Y_START+1;


        for(int i=X_START ; i<X_START+13 ; i++) {
            FLOOR[Y_START][i].SYMBOL='_';
        }

        for(int j=Y_START+1 ; j<=Y_START+4 ; j++) {
            FLOOR[j][X_START].SYMBOL='|';
            for(int i=X_START+1 ; i<X_START+12 ; i++) {

                FLOOR[j][i].SYMBOL='.';

            }
            FLOOR[j][X_START+12].SYMBOL='|';
        }

        for(int i=X_START ; i<X_START+13 ; i++) {
            FLOOR[Y_START+5][i].SYMBOL='_';
        }

        FLOOR[door2][X_START+12].SYMBOL='+';

        FLOOR[Y_START+5][door1].SYMBOL='+';
    }

    X_START=rand()%27+48;   Y_START=rand()%9+1; BIG_OR_SMALL=rand()%2;

    if(BIG_OR_SMALL==1) {

        int door1=rand()%14+X_START+1;

        int door2=rand()%5+Y_START+1;

        int door3=rand()%5+Y_START+1;

        int WINDOW_QUERRY=rand()%100+1;

        for(int i=X_START ; i<X_START+16 ; i++) {
            FLOOR[Y_START][i].SYMBOL='_';
        }

        for(int j=Y_START+1 ; j<=Y_START+5 ; j++) {
            FLOOR[j][X_START].SYMBOL='|';
            for(int i=X_START+1 ; i<X_START+15 ; i++) {

                FLOOR[j][i].SYMBOL='.';

            }
            FLOOR[j][X_START+15].SYMBOL='|';
        }

        for(int i=X_START ; i<X_START+16 ; i++) {
            FLOOR[Y_START+6][i].SYMBOL='_';
        }

        if(WINDOW_QUERRY<=20) {
            if(door1<X_START+14) {
                FLOOR[Y_START+6][door1+1].SYMBOL='=';
            }
            else {
                FLOOR[Y_START+6][door1-1].SYMBOL='=';
            }
        }

        FLOOR[door2][X_START+15].SYMBOL='+';

        FLOOR[Y_START+6][door1].SYMBOL='+';

        FLOOR[door3][X_START].SYMBOL='+';
    }
    else {

        int door1=rand()%11+X_START+1;

        int door2=rand()%4+Y_START+1;

        int door3=rand()%4+Y_START+1;

        for(int i=X_START ; i<X_START+13 ; i++) {
            FLOOR[Y_START][i].SYMBOL='_';
        }

        for(int j=Y_START+1 ; j<=Y_START+4 ; j++) {
            FLOOR[j][X_START].SYMBOL='|';
            for(int i=X_START+1 ; i<X_START+12 ; i++) {

                FLOOR[j][i].SYMBOL='.';

            }
            FLOOR[j][X_START+12].SYMBOL='|';
        }

        for(int i=X_START ; i<X_START+13 ; i++) {
            FLOOR[Y_START+5][i].SYMBOL='_';
        }

        FLOOR[door2][X_START+12].SYMBOL='+';

        FLOOR[Y_START+5][door1].SYMBOL='+';

        FLOOR[door3][X_START].SYMBOL='+';

    }
    
    X_START=rand()%27+96;   Y_START=rand()%9+1; BIG_OR_SMALL=rand()%2;

    if(BIG_OR_SMALL==1) {

        int door1=rand()%14+X_START+1;

        int door3=rand()%5+Y_START+1;

        int WINDOW_QUERRY=rand()%100+1;

        for(int i=X_START ; i<X_START+16 ; i++) {
            FLOOR[Y_START][i].SYMBOL='_';
        }

        for(int j=Y_START+1 ; j<=Y_START+5 ; j++) {
            FLOOR[j][X_START].SYMBOL='|';
            for(int i=X_START+1 ; i<X_START+15 ; i++) {

                FLOOR[j][i].SYMBOL='.';

            }
            FLOOR[j][X_START+15].SYMBOL='|';
        }

        for(int i=X_START ; i<X_START+16 ; i++) {
            FLOOR[Y_START+6][i].SYMBOL='_';
        }

        if(WINDOW_QUERRY<=20) {
            if(door1<X_START+14) {
                FLOOR[Y_START+6][door1+1].SYMBOL='=';
            }
            else {
                FLOOR[Y_START+6][door1-1].SYMBOL='=';
            }
        }

        FLOOR[Y_START+6][door1].SYMBOL='+';

        FLOOR[door3][X_START].SYMBOL='+';
    }
    else {

        int door1=rand()%11+X_START+1;

        int door3=rand()%4+Y_START+1;

        for(int i=X_START ; i<X_START+13 ; i++) {
            FLOOR[Y_START][i].SYMBOL='_';
        }

        for(int j=Y_START+1 ; j<=Y_START+4 ; j++) {
            FLOOR[j][X_START].SYMBOL='|';
            for(int i=X_START+1 ; i<X_START+12 ; i++) {

                FLOOR[j][i].SYMBOL='.';

            }
            FLOOR[j][X_START+12].SYMBOL='|';
        }

        for(int i=X_START ; i<X_START+13 ; i++) {
            FLOOR[Y_START+5][i].SYMBOL='_';
        }


        FLOOR[Y_START+5][door1].SYMBOL='+';

        FLOOR[door3][X_START].SYMBOL='+';


    }

    X_START=rand()%27;  Y_START=rand()%9+20;    BIG_OR_SMALL=rand()%2;
    if(BIG_OR_SMALL==1) {

        int door1=rand()%14+X_START+1;

        int door2=rand()%5+Y_START+1;

        int WINDOW_QUERRY=rand()%100+1;

        for(int i=X_START ; i<X_START+16 ; i++) {
            FLOOR[Y_START][i].SYMBOL='_';
        }

        for(int j=Y_START+1 ; j<=Y_START+5 ; j++) {
            FLOOR[j][X_START].SYMBOL='|';
            for(int i=X_START+1 ; i<X_START+15 ; i++) {

                FLOOR[j][i].SYMBOL='.';

            }
            FLOOR[j][X_START+15].SYMBOL='|';
        }

        for(int i=X_START ; i<X_START+16 ; i++) {
            FLOOR[Y_START+6][i].SYMBOL='_';
        }

        if(WINDOW_QUERRY<=20) {
            if(door1<X_START+14) {
                FLOOR[Y_START][door1+1].SYMBOL='=';
            }
            else {
                FLOOR[Y_START][door1-1].SYMBOL='=';
            }
        }

        FLOOR[door2][X_START+15].SYMBOL='+';

        FLOOR[Y_START][door1].SYMBOL='+';

    }
    else {

        int door1=rand()%11+X_START+1;

        int door2=rand()%4+Y_START+1;

        for(int i=X_START ; i<X_START+13 ; i++) {
            FLOOR[Y_START][i].SYMBOL='_';
        }

        for(int j=Y_START+1 ; j<=Y_START+4 ; j++) {
            FLOOR[j][X_START].SYMBOL='|';
            for(int i=X_START+1 ; i<X_START+12 ; i++) {

                FLOOR[j][i].SYMBOL='.';

            }
            FLOOR[j][X_START+12].SYMBOL='|';
        }

        for(int i=X_START ; i<X_START+13 ; i++) {
            FLOOR[Y_START+5][i].SYMBOL='_';
        }

        FLOOR[door2][X_START+12].SYMBOL='+';

        FLOOR[Y_START][door1].SYMBOL='+';

    }

    X_START=rand()%27+48;   Y_START=rand()%9+20;    BIG_OR_SMALL=rand()%2;

    if(BIG_OR_SMALL==1) {

        int door1=rand()%14+X_START+1;

        int door2=rand()%5+Y_START+1;

        int door3=rand()%5+Y_START+1;

        int WINDOW_QUERRY=rand()%100+1;

        for(int i=X_START ; i<X_START+16 ; i++) {
            FLOOR[Y_START][i].SYMBOL='_';
        }

        for(int j=Y_START+1 ; j<=Y_START+5 ; j++) {
            FLOOR[j][X_START].SYMBOL='|';
            for(int i=X_START+1 ; i<X_START+15 ; i++) {

                FLOOR[j][i].SYMBOL='.';

            }
            FLOOR[j][X_START+15].SYMBOL='|';
        }

        for(int i=X_START ; i<X_START+16 ; i++) {
            FLOOR[Y_START+6][i].SYMBOL='_';
        }

        if(WINDOW_QUERRY<=20) {
            if(door1<X_START+14) {
                FLOOR[Y_START][door1+1].SYMBOL='=';
            }
            else {
                FLOOR[Y_START][door1-1].SYMBOL='=';
            }
        }


        FLOOR[door2][X_START+15].SYMBOL='+';

        FLOOR[Y_START][door1].SYMBOL='+';

        FLOOR[door3][X_START].SYMBOL='+';
    }
    else {
        
        int door1=rand()%11+X_START+1;

        int door2=rand()%4+Y_START+1;

        int door3=rand()%4+Y_START+1;

        for(int i=X_START ; i<X_START+13 ; i++) {
            FLOOR[Y_START][i].SYMBOL='_';
        }

        for(int j=Y_START+1 ; j<=Y_START+4 ; j++) {
            FLOOR[j][X_START].SYMBOL='|';
            for(int i=X_START+1 ; i<X_START+12 ; i++) {

                FLOOR[j][i].SYMBOL='.';

            }
            FLOOR[j][X_START+12].SYMBOL='|';
        }

        for(int i=X_START ; i<X_START+13 ; i++) {
            FLOOR[Y_START+5][i].SYMBOL='_';
        }

        FLOOR[door2][X_START+12].SYMBOL='+';

        FLOOR[Y_START][door1].SYMBOL='+';

        FLOOR[door3][X_START].SYMBOL='+';
    }

    X_START=rand()%27+96;   Y_START=rand()%9+20;    BIG_OR_SMALL=rand()%2; 

    if(BIG_OR_SMALL==1) {

        int door1=rand()%14+X_START+1;

        int door3=rand()%5+Y_START+1;

        int WINDOW_QUERRY=rand()%100+1;

        for(int i=X_START ; i<X_START+16 ; i++) {
            FLOOR[Y_START][i].SYMBOL='_';
        }

        for(int j=Y_START+1 ; j<=Y_START+5 ; j++) {
            FLOOR[j][X_START].SYMBOL='|';
            for(int i=X_START+1 ; i<X_START+15 ; i++) {

                FLOOR[j][i].SYMBOL='.';

            }
            FLOOR[j][X_START+15].SYMBOL='|';
        }

        for(int i=X_START ; i<X_START+16 ; i++) {
            FLOOR[Y_START+6][i].SYMBOL='_';
        }

        if(WINDOW_QUERRY<=20) {
            if(door1<X_START+14) {
                FLOOR[Y_START][door1+1].SYMBOL='=';
            }
            else {
                FLOOR[Y_START][door1-1].SYMBOL='=';
            }
        }

        FLOOR[Y_START][door1].SYMBOL='+';

        FLOOR[door3][X_START].SYMBOL='+';

    }
    else {

        int door1=rand()%11+X_START+1;

        int door3=rand()%4+Y_START+1;

        for(int i=X_START ; i<X_START+13 ; i++) {
            FLOOR[Y_START][i].SYMBOL='_';
        }

        for(int j=Y_START+1 ; j<=Y_START+4 ; j++) {
            FLOOR[j][X_START].SYMBOL='|';
            for(int i=X_START+1 ; i<X_START+12 ; i++) {

                FLOOR[j][i].SYMBOL='.';

            }
            FLOOR[j][X_START+12].SYMBOL='|';
        }

        for(int i=X_START ; i<X_START+13 ; i++) {
            FLOOR[Y_START+5][i].SYMBOL='_';
        }

        FLOOR[Y_START][door1].SYMBOL='+';

        FLOOR[door3][X_START].SYMBOL='+';

    }

    //generate non-secret random features

    DOOR RETURN_DOORS[14];

    CONNECT_ROOMS_AND_RETURN_DOORS(FLOOR,RETURN_DOORS);       

    int TEMP=GENERATE_ENTRY_EXIT(FLOOR,START_SECTOR);   

    GENERATE_PILLARS(FLOOR);    

    int ANOTHER_RANDOM_QUERRY=rand()%100+1;

    int PASSWORD_DOOR_EXISTS=FALSE;

    int PASSWORD_DOOR_SECTOR;

    if(ANOTHER_RANDOM_QUERRY<=40) {//generate password door 

        ANOTHER_RANDOM_QUERRY=rand()%3+1;

        if(ANOTHER_RANDOM_QUERRY==1 || FLOOR_NUMBER==4) {//normal pass door with 1 or 2 passwords

            if(FLOOR_NUMBER==4) {//2 passes

                int RAND_X,RAND_Y;

                while(TRUE) {

                    RAND_X=rand()%144; RAND_Y=rand()%38;

                    if(FLOOR[RAND_Y][RAND_X].SYMBOL=='.') {

                        if(FLOOR[RAND_Y][RAND_X-1].SYMBOL=='|' && FLOOR[RAND_Y-1][RAND_X].SYMBOL=='_' 
                        
                        && FLOOR[RAND_Y+1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X+1].SYMBOL!='O' ) {
                            break;
                        }

                        if(FLOOR[RAND_Y][RAND_X+1].SYMBOL=='|' && FLOOR[RAND_Y-1][RAND_X].SYMBOL=='_' 
                        
                        && FLOOR[RAND_Y+1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X-1].SYMBOL!='O' ) {
                            break;
                        }

                        if(FLOOR[RAND_Y][RAND_X-1].SYMBOL=='|' && FLOOR[RAND_Y+1][RAND_X].SYMBOL=='_' 
                        
                        && FLOOR[RAND_Y-1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X+1].SYMBOL!='O' ) {
                            break;
                        }

                        if(FLOOR[RAND_Y][RAND_X+1].SYMBOL=='|' && FLOOR[RAND_Y+1][RAND_X].SYMBOL=='_' 
                        
                        && FLOOR[RAND_Y-1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X-1].SYMBOL!='O' ) {
                            break;
                        }

                    }

                }

                FLOOR[RAND_Y][RAND_X].SYMBOL='&';

                FLOOR[RAND_Y][RAND_X].COLOR='w';

                PASSWORD_DOOR_SECTOR=GIVE_SECTOR_NUMBER(RAND_X,RAND_Y);

                while(TRUE) {

                    RAND_X=rand()%144; RAND_Y=rand()%38;

                    if(FLOOR[RAND_Y][RAND_X].SYMBOL=='.' && GIVE_SECTOR_NUMBER(RAND_X,RAND_Y)==PASSWORD_DOOR_SECTOR && FLOOR[RAND_Y][RAND_X].SYMBOL!='&') {

                        if(FLOOR[RAND_Y][RAND_X-1].SYMBOL=='|' && FLOOR[RAND_Y-1][RAND_X].SYMBOL=='_' 
                        
                        && FLOOR[RAND_Y+1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X+1].SYMBOL!='O' ) {
                            break;
                        }

                        if(FLOOR[RAND_Y][RAND_X+1].SYMBOL=='|' && FLOOR[RAND_Y-1][RAND_X].SYMBOL=='_' 
                        
                        && FLOOR[RAND_Y+1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X-1].SYMBOL!='O' ) {
                            break;
                        }

                        if(FLOOR[RAND_Y][RAND_X-1].SYMBOL=='|' && FLOOR[RAND_Y+1][RAND_X].SYMBOL=='_' 
                        
                        && FLOOR[RAND_Y-1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X+1].SYMBOL!='O' ) {
                            break;
                        }

                        if(FLOOR[RAND_Y][RAND_X+1].SYMBOL=='|' && FLOOR[RAND_Y+1][RAND_X].SYMBOL=='_' 
                        
                        && FLOOR[RAND_Y-1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X-1].SYMBOL!='O' ) {
                            break;
                        }

                    }

                }

                FLOOR[RAND_Y][RAND_X].SYMBOL='&';

                FLOOR[RAND_Y][RAND_X].COLOR='w';

                for(int k=0 ; k<14 ; k++) {

                    if(RETURN_DOORS[k].SECTOR==PASSWORD_DOOR_SECTOR) {

                        FLOOR[RETURN_DOORS[k].y][RETURN_DOORS[k].x].SYMBOL='@';

                        FLOOR[RETURN_DOORS[k].y][RETURN_DOORS[k].x].COLOR='r';

                        FLOOR[RETURN_DOORS[k].y][RETURN_DOORS[k].x].PASSWORD_DOOR_TYPE='2';

                        break;

                    }

                }

            }

            else {// 1 pass

                int RAND_X,RAND_Y;

                while(TRUE) {

                    RAND_X=rand()%144; RAND_Y=rand()%38;

                    if(FLOOR[RAND_Y][RAND_X].SYMBOL=='.') {

                        if(FLOOR[RAND_Y][RAND_X-1].SYMBOL=='|' && FLOOR[RAND_Y-1][RAND_X].SYMBOL=='_' 
                        
                        && FLOOR[RAND_Y+1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X+1].SYMBOL!='O' ) {
                            break;
                        }

                        if(FLOOR[RAND_Y][RAND_X+1].SYMBOL=='|' && FLOOR[RAND_Y-1][RAND_X].SYMBOL=='_' 
                        
                        && FLOOR[RAND_Y+1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X-1].SYMBOL!='O' ) {
                            break;
                        }

                        if(FLOOR[RAND_Y][RAND_X-1].SYMBOL=='|' && FLOOR[RAND_Y+1][RAND_X].SYMBOL=='_' 
                        
                        && FLOOR[RAND_Y-1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X+1].SYMBOL!='O' ) {
                            break;
                        }

                        if(FLOOR[RAND_Y][RAND_X+1].SYMBOL=='|' && FLOOR[RAND_Y+1][RAND_X].SYMBOL=='_' 
                        
                        && FLOOR[RAND_Y-1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X-1].SYMBOL!='O' ) {
                            break;
                        }

                    }

                }

                FLOOR[RAND_Y][RAND_X].SYMBOL='&';

                FLOOR[RAND_Y][RAND_X].COLOR='w';

                PASSWORD_DOOR_SECTOR=GIVE_SECTOR_NUMBER(RAND_X,RAND_Y);

                for(int k=0 ; k<14 ; k++) {

                    if(RETURN_DOORS[k].SECTOR==PASSWORD_DOOR_SECTOR) {

                        FLOOR[RETURN_DOORS[k].y][RETURN_DOORS[k].x].SYMBOL='@';

                        FLOOR[RETURN_DOORS[k].y][RETURN_DOORS[k].x].COLOR='r';

                        FLOOR[RETURN_DOORS[k].y][RETURN_DOORS[k].x].PASSWORD_DOOR_TYPE='1';

                        break;

                    }

                }

            }

        }
        
        else if(ANOTHER_RANDOM_QUERRY==2) {//reverse ordered pass

            int RAND_X,RAND_Y;

            while(TRUE) {

                RAND_X=rand()%144; RAND_Y=rand()%38;

                if(FLOOR[RAND_Y][RAND_X].SYMBOL=='.') {

                    if(FLOOR[RAND_Y][RAND_X-1].SYMBOL=='|' && FLOOR[RAND_Y-1][RAND_X].SYMBOL=='_' 
                        
                    && FLOOR[RAND_Y+1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X+1].SYMBOL!='O' ) {
                        break;
                    }

                    if(FLOOR[RAND_Y][RAND_X+1].SYMBOL=='|' && FLOOR[RAND_Y-1][RAND_X].SYMBOL=='_' 
                        
                    && FLOOR[RAND_Y+1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X-1].SYMBOL!='O' ) {
                        break;
                    }

                    if(FLOOR[RAND_Y][RAND_X-1].SYMBOL=='|' && FLOOR[RAND_Y+1][RAND_X].SYMBOL=='_' 
                        
                    && FLOOR[RAND_Y-1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X+1].SYMBOL!='O' ) {
                        break;
                    }

                    if(FLOOR[RAND_Y][RAND_X+1].SYMBOL=='|' && FLOOR[RAND_Y+1][RAND_X].SYMBOL=='_' 
                        
                    && FLOOR[RAND_Y-1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X-1].SYMBOL!='O' ) {
                        break;
                    }

                }

            }

            FLOOR[RAND_Y][RAND_X].SYMBOL='&';

            FLOOR[RAND_Y][RAND_X].COLOR='w';

            PASSWORD_DOOR_SECTOR=GIVE_SECTOR_NUMBER(RAND_X,RAND_Y);

            for(int k=0 ; k<14 ; k++) {

                if(RETURN_DOORS[k].SECTOR==PASSWORD_DOOR_SECTOR) {

                    FLOOR[RETURN_DOORS[k].y][RETURN_DOORS[k].x].SYMBOL='@';

                    FLOOR[RETURN_DOORS[k].y][RETURN_DOORS[k].x].COLOR='r';

                    FLOOR[RETURN_DOORS[k].y][RETURN_DOORS[k].x].PASSWORD_DOOR_TYPE='r';

                    break;

                }

            }


        }

        else {//changing pass

            int RAND_X,RAND_Y;

            while(TRUE) {

                RAND_X=rand()%144; RAND_Y=rand()%38;

                if(FLOOR[RAND_Y][RAND_X].SYMBOL=='.') {

                    if(FLOOR[RAND_Y][RAND_X-1].SYMBOL=='|' && FLOOR[RAND_Y-1][RAND_X].SYMBOL=='_' 
                        
                    && FLOOR[RAND_Y+1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X+1].SYMBOL!='O' ) {
                        break;
                    }

                    if(FLOOR[RAND_Y][RAND_X+1].SYMBOL=='|' && FLOOR[RAND_Y-1][RAND_X].SYMBOL=='_' 
                        
                    && FLOOR[RAND_Y+1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X-1].SYMBOL!='O' ) {
                        break;
                    }

                    if(FLOOR[RAND_Y][RAND_X-1].SYMBOL=='|' && FLOOR[RAND_Y+1][RAND_X].SYMBOL=='_' 
                        
                    && FLOOR[RAND_Y-1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X+1].SYMBOL!='O' ) {
                        break;
                    }

                    if(FLOOR[RAND_Y][RAND_X+1].SYMBOL=='|' && FLOOR[RAND_Y+1][RAND_X].SYMBOL=='_' 
                        
                    && FLOOR[RAND_Y-1][RAND_X].SYMBOL!='O' && FLOOR[RAND_Y][RAND_X-1].SYMBOL!='O' ) {
                        break;
                    }

                }

            }

            FLOOR[RAND_Y][RAND_X].SYMBOL='&';

            FLOOR[RAND_Y][RAND_X].COLOR='w';

            PASSWORD_DOOR_SECTOR=GIVE_SECTOR_NUMBER(RAND_X,RAND_Y);

            for(int k=0 ; k<14 ; k++) {

                if(RETURN_DOORS[k].SECTOR==PASSWORD_DOOR_SECTOR) {

                    FLOOR[RETURN_DOORS[k].y][RETURN_DOORS[k].x].SYMBOL='@';

                    FLOOR[RETURN_DOORS[k].y][RETURN_DOORS[k].x].COLOR='r';

                    FLOOR[RETURN_DOORS[k].y][RETURN_DOORS[k].x].PASSWORD_DOOR_TYPE='t';

                    break;

                }

            }            

        }

        PASSWORD_DOOR_EXISTS=TRUE;

    }

    //theme randomizer here.

    int TREASURE_SECTOR=-1;
    
    if(FLOOR_NUMBER==4) {

        for(int i=0 ; i<38 ; i++) {
            
            int BREAK=0;

            for(int j=0 ; j<144 ; j++) {

                if(FLOOR[i][j].IS_START==-1) {
                    
                    TREASURE_SECTOR=GIVE_SECTOR_NUMBER(j,i);

                    GLOBAL_ALL_THEMES_COLOR[3][TREASURE_SECTOR-1]='y';

                    break;
                }

            }

            if(BREAK==TRUE) {
                break;
            }
        }
    }

    GENERATE_ANCIENT_KEY(FLOOR); 

    for(int i=0 ; i<38 ; i++) {
        for(int j=0 ; j<144 ; j++) {

            FLOOR[i][j].REAL_CONTENTS=FLOOR[i][j].SYMBOL;

        }
    }

    if(TREASURE_SECTOR!=-1) {

        SPAWN_BLACK_GOLD(3,45,TREASURE_SECTOR,FLOOR);

        SPAWN_GOLD(7,40,TREASURE_SECTOR,FLOOR);

        SPAWN_TRAPS(6,100,TREASURE_SECTOR,FLOOR);

    }

    COORDS START_COORDS=GIVE_STAIRS_ADDRESS_ENTRY(FLOOR);   COORDS END_COORDS=GIVE_STAIRS_ADDRESS_EXIT(FLOOR);

    int START_SECTOR_FOR_RNG=GIVE_SECTOR_NUMBER(START_COORDS.x,START_COORDS.y); int END_SECTOR=GIVE_SECTOR_NUMBER(END_COORDS.x,END_COORDS.y);

    int RANDOM_QUERRY=rand()%100+1; int SECRET_ROOM_SECTOR=-1;

    if(RANDOM_QUERRY<=40 && PASSWORD_DOOR_EXISTS==FALSE) {

        while(TRUE) {

            SECRET_ROOM_SECTOR=rand()%6+1;

            if((SECRET_ROOM_SECTOR==1 || SECRET_ROOM_SECTOR==3 || SECRET_ROOM_SECTOR==4 || SECRET_ROOM_SECTOR==6 )

            &&(SECRET_ROOM_SECTOR!=START_SECTOR_FOR_RNG)

            &&(SECRET_ROOM_SECTOR!=END_SECTOR)) 

            {//valid generation sector selected

                break;

            }

        }

        //turn regular doors' chars into walls and real insides into ? . 1 2 3
                                                                    //   4 5 6
        if(SECRET_ROOM_SECTOR==1) {//connection : 1r <-> 2l, 1d <-> 4u

            int DOOR3L=FIND_SPECIFIED_DOOR('r',1,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR3L].y][RETURN_DOORS[DOOR3L].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR3L].y][RETURN_DOORS[DOOR3L].x].SYMBOL='|';

            int DOOR4R=FIND_SPECIFIED_DOOR('l',2,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR4R].y][RETURN_DOORS[DOOR4R].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR4R].y][RETURN_DOORS[DOOR4R].x].SYMBOL='|';

            int DOOR1D=FIND_SPECIFIED_DOOR('d',1,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR1D].y][RETURN_DOORS[DOOR1D].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR1D].y][RETURN_DOORS[DOOR1D].x].SYMBOL='_';

            int DOOR4U=FIND_SPECIFIED_DOOR('u',4,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR4U].y][RETURN_DOORS[DOOR4U].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR4U].y][RETURN_DOORS[DOOR4U].x].SYMBOL='_';

        }
    
        else if(SECRET_ROOM_SECTOR==3) {//connection : 3l <-> 2r, 3d <-> 6u

            int DOOR3L=FIND_SPECIFIED_DOOR('l',3,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR3L].y][RETURN_DOORS[DOOR3L].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR3L].y][RETURN_DOORS[DOOR3L].x].SYMBOL='|';

            int DOOR6L=FIND_SPECIFIED_DOOR('r',2,RETURN_DOORS);
            
            FLOOR[RETURN_DOORS[DOOR6L].y][RETURN_DOORS[DOOR6L].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR6L].y][RETURN_DOORS[DOOR6L].x].SYMBOL='|';

            int DOOR3D=FIND_SPECIFIED_DOOR('d',3,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR3D].y][RETURN_DOORS[DOOR3D].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR3D].y][RETURN_DOORS[DOOR3D].x].SYMBOL='_';

            int DOOR6U=FIND_SPECIFIED_DOOR('u',6,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR6U].y][RETURN_DOORS[DOOR6U].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR6U].y][RETURN_DOORS[DOOR6U].x].SYMBOL='_';

        }

        else if(SECRET_ROOM_SECTOR==4) {// connection : 4u <-> 1d, 4r <-> 5l

            int DOOR4U=FIND_SPECIFIED_DOOR('u',4,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR4U].y][RETURN_DOORS[DOOR4U].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR4U].y][RETURN_DOORS[DOOR4U].x].SYMBOL='_';

            int DOOR1D=FIND_SPECIFIED_DOOR('d',1,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR1D].y][RETURN_DOORS[DOOR1D].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR1D].y][RETURN_DOORS[DOOR1D].x].SYMBOL='_';

            int DOOR4R=FIND_SPECIFIED_DOOR('r',4,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR4R].y][RETURN_DOORS[DOOR4R].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR4R].y][RETURN_DOORS[DOOR4R].x].SYMBOL='|';

            int DOOR5L=FIND_SPECIFIED_DOOR('l',5,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR5L].y][RETURN_DOORS[DOOR5L].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR5L].y][RETURN_DOORS[DOOR5L].x].SYMBOL='|';

        }

        else {//6 connection : 6l <-> 5r, 6u <-> 3d

            int DOOR3D=FIND_SPECIFIED_DOOR('d',3,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR3D].y][RETURN_DOORS[DOOR3D].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR3D].y][RETURN_DOORS[DOOR3D].x].SYMBOL='_';

            int DOOR6U=FIND_SPECIFIED_DOOR('u',6,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR6U].y][RETURN_DOORS[DOOR6U].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR6U].y][RETURN_DOORS[DOOR6U].x].SYMBOL='_';

            int DOOR6L=FIND_SPECIFIED_DOOR('l',6,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR6L].y][RETURN_DOORS[DOOR6L].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR6L].y][RETURN_DOORS[DOOR6L].x].SYMBOL='|';

            int DOOR5R=FIND_SPECIFIED_DOOR('r',5,RETURN_DOORS);

            FLOOR[RETURN_DOORS[DOOR5R].y][RETURN_DOORS[DOOR5R].x].REAL_CONTENTS='?';

            FLOOR[RETURN_DOORS[DOOR5R].y][RETURN_DOORS[DOOR5R].x].SYMBOL='|';

        }

    }

    //if an object didn't have a specified color, set their color to room theme

    if(START_SECTOR!=-1) {//that means start sector is accessed via stairs. and is an enchant room.

        SPAWN_SPELLS(8,30,START_SECTOR,FLOOR);

        GLOBAL_ALL_THEMES_COLOR[FLOOR_NUMBER-1][START_SECTOR-1]='b';

    }

    int TRIAL_FOR_NIGHTMARE_ROOM=rand()%100+1;

    int NIGHTMARE_SECTOR=-1;

    if(TRIAL_FOR_NIGHTMARE_ROOM<=40) {

        for(int k=0 ; k<6 ; k++) {

            if(GLOBAL_ALL_THEMES_COLOR[FLOOR_NUMBER-1][k]==0) {

                GLOBAL_ALL_THEMES_COLOR[FLOOR_NUMBER-1][k]='r';

                SPAWN_GOLD(2,4,k+1,FLOOR);

                SPAWN_FOOD(1,20,k+1,FLOOR);

                SPAWN_WEAPONS(1,1,k+1,FLOOR);

                SPAWN_SPELLS(1,5,k+1,FLOOR);

                SPAWN_TRAPS(2,30,k+1,FLOOR);

                NIGHTMARE_SECTOR=k+1;

                break;

            }

        }

    }
  
    if(SECRET_ROOM_SECTOR!=-1) {

        SPAWN_SPELLS(8,30,SECRET_ROOM_SECTOR,FLOOR);

        GLOBAL_ALL_THEMES_COLOR[FLOOR_NUMBER-1][SECRET_ROOM_SECTOR-1]='b';

    }

    for(int i=0 ; i<6 ; i++) {//if theme is still 0, turn it into 'w' (normal room).

        if(GLOBAL_ALL_THEMES_COLOR[FLOOR_NUMBER-1][i]==0) {

            GLOBAL_ALL_THEMES_COLOR[FLOOR_NUMBER-1][i]='w';

            SPAWN_GOLD(2,4,i+1,FLOOR);

            SPAWN_FOOD(1,20,i+1,FLOOR);

            SPAWN_WEAPONS(1,1,i+1,FLOOR);

            SPAWN_SPELLS(1,5,i+1,FLOOR);

            SPAWN_TRAPS(2,30,i+1,FLOOR);

        }

    }

    for(int i=0 ; i<38 ; i++) {//if a cell isn't a walkway or a special tile, turn its color into theme color.

        for(int j=0 ; j<144 ; j++) {

            if(FLOOR[i][j].COLOR=='w' && FLOOR[i][j].SYMBOL!='#' && FLOOR[i][j].SYMBOL!='&') {

                FLOOR[i][j].COLOR=GLOBAL_ALL_THEMES_COLOR[FLOOR_NUMBER-1][GIVE_SECTOR_NUMBER(j,i)-1];

            }

        }

    }


    //Generate RNG based Enemies-------------------------------------------------------------------------------------------------------

    GENERATE_ENEMIES(FLOOR, FLOOR_NUMBER);// <-------


    return TEMP;

}

void CONNECT_ROOMS_AND_RETURN_DOORS(POINT FLOOR[38][144], DOOR RETURN_DOORS[14]) {

    int k=0;

    //search the board for doors, mark their locations and sectors
    for( int i=0 ; i<38 ; i++) {
        for( int j=0 ; j<144 ; j++) {
            if(FLOOR[i][j].SYMBOL=='+') {

                RETURN_DOORS[k].x=j;

                RETURN_DOORS[k].y=i;

                if(i>=0 && i<19) {//sectors 1,2,3

                    if(j>=0 && j<48) {

                        RETURN_DOORS[k].SECTOR=1;

                    }

                    if(j>=48 && j<96) {

                        RETURN_DOORS[k].SECTOR=2;

                    }

                    if(j>=96 && j<144) {

                        RETURN_DOORS[k].SECTOR=3;

                    }

                }

                else {//sectors 4,5,6

                    if(j>=0 && j<48) {

                        RETURN_DOORS[k].SECTOR=4;

                    }

                    if(j>=48 && j<96) {

                        RETURN_DOORS[k].SECTOR=5;

                    }

                    if(j>=96 && j<144) {

                        RETURN_DOORS[k].SECTOR=6;

                    }

                }

                k++;

            }
        }
    }

    //determine the direction of the doors. for easier reference, sort them first (in terms of sector).

    for(int i=0 ; i<14 ; i++) {
        for(int j=i+1 ; j<14 ; j++) {
            if(RETURN_DOORS[i].SECTOR>RETURN_DOORS[j].SECTOR) {
                DOOR temp=RETURN_DOORS[i];
                RETURN_DOORS[i]=RETURN_DOORS[j];
                RETURN_DOORS[j]=temp;

            }

        }
    }

    //sector 1 has 2 doors :

    if(RETURN_DOORS[0].x>RETURN_DOORS[1].x) {

        RETURN_DOORS[0].DIRECTION='r';

        RETURN_DOORS[1].DIRECTION='d';

    }
    else {
        RETURN_DOORS[1].DIRECTION='r';

        RETURN_DOORS[0].DIRECTION='d';
    }

    //sector 2 has 3 :

    if(RETURN_DOORS[2].y>RETURN_DOORS[3].y && RETURN_DOORS[2].y>RETURN_DOORS[4].y) {

        RETURN_DOORS[2].DIRECTION='d';

        if(RETURN_DOORS[3].x>RETURN_DOORS[4].x) {

            RETURN_DOORS[3].DIRECTION='r';

            RETURN_DOORS[4].DIRECTION='l';
        }

        else {
            RETURN_DOORS[4].DIRECTION='r';

            RETURN_DOORS[3].DIRECTION='l';
        }


    }

    if(RETURN_DOORS[3].y>RETURN_DOORS[2].y && RETURN_DOORS[3].y>RETURN_DOORS[4].y) {

        RETURN_DOORS[3].DIRECTION='d';

        if(RETURN_DOORS[2].x>RETURN_DOORS[4].x) {

            RETURN_DOORS[2].DIRECTION='r';

            RETURN_DOORS[4].DIRECTION='l';
        }

        else {
            RETURN_DOORS[4].DIRECTION='r';

            RETURN_DOORS[2].DIRECTION='l';
        }

    }

    if(RETURN_DOORS[4].y>RETURN_DOORS[2].y && RETURN_DOORS[4].y>RETURN_DOORS[3].y) {

        RETURN_DOORS[4].DIRECTION='d';

        if(RETURN_DOORS[3].x>RETURN_DOORS[2].x) {

            RETURN_DOORS[3].DIRECTION='r';

            RETURN_DOORS[2].DIRECTION='l';
        }

        else {
            RETURN_DOORS[2].DIRECTION='r';

            RETURN_DOORS[3].DIRECTION='l';
        }

    }

    //sector 3 has 2:

    if(RETURN_DOORS[5].y>RETURN_DOORS[6].y) {

        RETURN_DOORS[5].DIRECTION='d';

        RETURN_DOORS[6].DIRECTION='l';

    }

    else {

        RETURN_DOORS[6].DIRECTION='d';

        RETURN_DOORS[5].DIRECTION='l';

    }

    //sector 4 has 2

    if(RETURN_DOORS[7].x>RETURN_DOORS[8].x) {

        RETURN_DOORS[7].DIRECTION='r';

        RETURN_DOORS[8].DIRECTION='u';

    }
    
    else {

        RETURN_DOORS[8].DIRECTION='r';

        RETURN_DOORS[7].DIRECTION='u';

    }

    //sector 5 has 3

    if(RETURN_DOORS[9].y<RETURN_DOORS[10].y && RETURN_DOORS[9].y<RETURN_DOORS[11].y) {

        RETURN_DOORS[9].DIRECTION='u';

        if(RETURN_DOORS[10].x>RETURN_DOORS[11].x) {

            RETURN_DOORS[10].DIRECTION='r';

            RETURN_DOORS[11].DIRECTION='l';

        }

        else {

            RETURN_DOORS[11].DIRECTION='r';

            RETURN_DOORS[10].DIRECTION='l';

        }

    }

    else if(RETURN_DOORS[10].y<RETURN_DOORS[9].y && RETURN_DOORS[10].y<RETURN_DOORS[11].y) {

        RETURN_DOORS[10].DIRECTION='u';

        if(RETURN_DOORS[9].x>RETURN_DOORS[11].x) {

            RETURN_DOORS[9].DIRECTION='r';

            RETURN_DOORS[11].DIRECTION='l';

        }

        else {

            RETURN_DOORS[11].DIRECTION='r';

            RETURN_DOORS[9].DIRECTION='l';

        }
    }

    else {

        RETURN_DOORS[11].DIRECTION='u';

        if(RETURN_DOORS[10].x>RETURN_DOORS[9].x) {

            RETURN_DOORS[10].DIRECTION='r';

            RETURN_DOORS[9].DIRECTION='l';

        }

        else {

            RETURN_DOORS[9].DIRECTION='r';

            RETURN_DOORS[10].DIRECTION='l';

        }
    }

    //sector 6 has 2

    if(RETURN_DOORS[12].y>RETURN_DOORS[13].y) {

        RETURN_DOORS[12].DIRECTION='l';

        RETURN_DOORS[13].DIRECTION='u';

    }

    else {

        RETURN_DOORS[13].DIRECTION='l';

        RETURN_DOORS[12].DIRECTION='u';
    }

    //all doors now have been found and classified in terms of direction and sector. now to connect them.

    // 1r -> 2l & 1d -> 4u | 2r ->3l & 2d -> 5u | 3d ->6u | 4r -> 5l | 5r -> 6l //

    for(int k=0 ; k<14 ; k++) {//hallway gen completed

        if(RETURN_DOORS[k].SECTOR==1 && RETURN_DOORS[k].DIRECTION=='r') {//1r

            int i=RETURN_DOORS[k].y;

            int j=RETURN_DOORS[k].x+1;

            int I_FINAL;

            int J_FINAL;

            for(int l=0 ; l<14 ; l++) {

                if(RETURN_DOORS[l].SECTOR==2 && RETURN_DOORS[l].DIRECTION=='l') {

                    I_FINAL=RETURN_DOORS[l].y;

                    J_FINAL=RETURN_DOORS[l].x;

                    break;

                }

            }

            while (i!=I_FINAL) {

                FLOOR[i][j].SYMBOL='#';

                if(i<I_FINAL)
                    i++;
                else
                    i--;
            }

            for(int l=j ; l<J_FINAL ; l++) {
                FLOOR[i][l].SYMBOL='#';
            }
        }

        if(RETURN_DOORS[k].SECTOR==1 && RETURN_DOORS[k].DIRECTION=='d') {//1d
            int i=RETURN_DOORS[k].y+1;

            int j=RETURN_DOORS[k].x;

            int I_FINAL;

            int J_FINAL;

            for(int l=0 ; l<14 ; l++) {

                if(RETURN_DOORS[l].SECTOR==4 && RETURN_DOORS[l].DIRECTION=='u') {

                    I_FINAL=RETURN_DOORS[l].y;

                    J_FINAL=RETURN_DOORS[l].x;

                    break;

                }

            }

            while (j!=J_FINAL) {

                FLOOR[i][j].SYMBOL='#';

                if(j<J_FINAL)
                    j++;
                else
                    j--;
            }

            for(int l=i ; l<I_FINAL ; l++) {
                FLOOR[l][J_FINAL].SYMBOL='#';
            }
        }

        if(RETURN_DOORS[k].SECTOR==2 && RETURN_DOORS[k].DIRECTION=='r') {//2r
            int i=RETURN_DOORS[k].y;

            int j=RETURN_DOORS[k].x+1;

            int I_FINAL;

            int J_FINAL;

            for(int l=0 ; l<14 ; l++) {

                if(RETURN_DOORS[l].SECTOR==3 && RETURN_DOORS[l].DIRECTION=='l') {

                    I_FINAL=RETURN_DOORS[l].y;

                    J_FINAL=RETURN_DOORS[l].x;

                    break;

                }

            }

            while (i!=I_FINAL) {

                FLOOR[i][j].SYMBOL='#';

                if(i<I_FINAL)
                    i++;
                else
                    i--;
            }

            for(int l=j ; l<J_FINAL ; l++) {
                FLOOR[i][l].SYMBOL='#';
            }
        }

        if(RETURN_DOORS[k].SECTOR==2 && RETURN_DOORS[k].DIRECTION=='d') {//2d
            int i=RETURN_DOORS[k].y+1;

            int j=RETURN_DOORS[k].x;

            int I_FINAL;

            int J_FINAL;

            for(int l=0 ; l<14 ; l++) {

                if(RETURN_DOORS[l].SECTOR==5 && RETURN_DOORS[l].DIRECTION=='u') {

                    I_FINAL=RETURN_DOORS[l].y;

                    J_FINAL=RETURN_DOORS[l].x;

                    break;

                }

            }

            while (j!=J_FINAL) {

                FLOOR[i][j].SYMBOL='#';

                if(j<J_FINAL)
                    j++;
                else
                    j--;
            }

            for(int l=i ; l<I_FINAL ; l++) {
                FLOOR[l][j].SYMBOL='#';
            }
        }

        if(RETURN_DOORS[k].SECTOR==3 && RETURN_DOORS[k].DIRECTION=='d') {//3d
            int i=RETURN_DOORS[k].y+1;

            int j=RETURN_DOORS[k].x;

            int I_FINAL;

            int J_FINAL;

            for(int l=0 ; l<14 ; l++) {

                if(RETURN_DOORS[l].SECTOR==6 && RETURN_DOORS[l].DIRECTION=='u') {

                    I_FINAL=RETURN_DOORS[l].y;

                    J_FINAL=RETURN_DOORS[l].x;

                    break;

                }

            }

            while (j!=J_FINAL) {

                FLOOR[i][j].SYMBOL='#';

                if(j<J_FINAL)
                    j++;
                else
                    j--;
            }

            for(int l=i ; l<I_FINAL ; l++) {
                FLOOR[l][j].SYMBOL='#';
            }
        }

        if(RETURN_DOORS[k].SECTOR==4 && RETURN_DOORS[k].DIRECTION=='r') {//4r
            int i=RETURN_DOORS[k].y;

            int j=RETURN_DOORS[k].x+1;

            int I_FINAL;

            int J_FINAL;

            for(int l=0 ; l<14 ; l++) {

                if(RETURN_DOORS[l].SECTOR==5 && RETURN_DOORS[l].DIRECTION=='l') {

                    I_FINAL=RETURN_DOORS[l].y;

                    J_FINAL=RETURN_DOORS[l].x;

                    break;

                }

            }

            while (i!=I_FINAL) {

                FLOOR[i][j].SYMBOL='#';

                if(i<I_FINAL)
                    i++;
                else
                    i--;
            }

            for(int l=j ; l<J_FINAL ; l++) {
                FLOOR[i][l].SYMBOL='#';
            }
        }

        if(RETURN_DOORS[k].SECTOR==5 && RETURN_DOORS[k].DIRECTION=='r') {//5r
            int i=RETURN_DOORS[k].y;

            int j=RETURN_DOORS[k].x+1;

            int I_FINAL;

            int J_FINAL;

            for(int l=0 ; l<14 ; l++) {

                if(RETURN_DOORS[l].SECTOR==6 && RETURN_DOORS[l].DIRECTION=='l') {

                    I_FINAL=RETURN_DOORS[l].y;

                    J_FINAL=RETURN_DOORS[l].x;

                    break;

                }

            }

            while (i!=I_FINAL) {

                FLOOR[i][j].SYMBOL='#';

                if(i<I_FINAL)
                    i++;
                else
                    i--;
            }

            for(int l=j ; l<J_FINAL ; l++) {
                FLOOR[i][l].SYMBOL='#';
            }
        }

    }

}

void GENERATE_PILLARS(POINT FLOOR[38][144]) {

    for(int k=0 ; k<6 ; k++) {//only 2 pillars for each sector

        int NUMBER=2;

        for(int i=(k/3)*19 ; i<19+(k/3)*19 ; i++ ) {

            for(int j=(k%3)*48; j<48+(k%3)*48 ;j++) {

                if(FLOOR[i][j].SYMBOL=='.') {

                    int CAN_BE_PUT=TRUE;

                    if(NUMBER) {

                        if(FLOOR[i][j-1].SYMBOL=='+' || FLOOR[i][j-1].SYMBOL=='=' || FLOOR[i][j-1].SYMBOL=='<')
                            CAN_BE_PUT=FALSE;
                        if(FLOOR[i][j+1].SYMBOL=='+' || FLOOR[i][j+1].SYMBOL=='=' || FLOOR[i][j+1].SYMBOL=='<')
                            CAN_BE_PUT=FALSE;
                        if(FLOOR[i-1][j].SYMBOL=='+' || FLOOR[i-1][j].SYMBOL=='=' || FLOOR[i-1][j].SYMBOL=='<')
                            CAN_BE_PUT=FALSE;
                        if(FLOOR[i+1][j].SYMBOL=='+' || FLOOR[i+1][j].SYMBOL=='=' || FLOOR[i+1][j].SYMBOL=='<')
                            CAN_BE_PUT=FALSE;
                        if(FLOOR[i-1][j-1].SYMBOL=='+' || FLOOR[i-1][j-1].SYMBOL=='=' || FLOOR[i-1][j-1].SYMBOL=='<')
                            CAN_BE_PUT=FALSE;
                        if(FLOOR[i-1][j+1].SYMBOL=='+' || FLOOR[i-1][j+1].SYMBOL=='=' || FLOOR[i-1][j+1].SYMBOL=='<')
                            CAN_BE_PUT=FALSE;
                        if(FLOOR[i+1][j-1].SYMBOL=='+' || FLOOR[i+1][j-1].SYMBOL=='=' || FLOOR[i+1][j-1].SYMBOL=='<')
                            CAN_BE_PUT=FALSE;
                        if(FLOOR[i+1][j+1].SYMBOL=='+' || FLOOR[i+1][j+1].SYMBOL=='=' || FLOOR[i+1][j+1].SYMBOL=='<')
                            CAN_BE_PUT=FALSE;

                    }

                    int QUERRY=rand()%100+1;

                    if(QUERRY<=3 && CAN_BE_PUT==TRUE && NUMBER>0)  {
                        FLOOR[i][j].SYMBOL='O';
                        NUMBER--;
                    }
                        

                }
                
            


            }

        }
    }

}

int GENERATE_ENTRY_EXIT(POINT FLOOR[38][144], int PREDETERMINED_START_SECTOR ) {

    //if passed on sector is -1, generate random start

    int X_START;

    int Y_START;

    if(PREDETERMINED_START_SECTOR==-1)  {//random start

        while(TRUE) {

            X_START=rand()%144;

            Y_START=rand()%38;

            int IS_VALID=FALSE;

            if(FLOOR[Y_START][X_START].SYMBOL=='.') {

                IS_VALID=TRUE;

                if(FLOOR[Y_START+1][X_START].SYMBOL=='=' || FLOOR[Y_START+1][X_START].SYMBOL=='+') {
                    IS_VALID=FALSE;
                }
                if(FLOOR[Y_START-1][X_START].SYMBOL=='=' || FLOOR[Y_START-1][X_START].SYMBOL=='+') {
                    IS_VALID=FALSE;
                }
                if(FLOOR[Y_START][X_START+1].SYMBOL=='=' || FLOOR[Y_START][X_START+1].SYMBOL=='+') {
                    IS_VALID=FALSE;
                }
                if(FLOOR[Y_START][X_START-1].SYMBOL=='=' || FLOOR[Y_START][X_START-1].SYMBOL=='+') {
                    IS_VALID=FALSE;
                }
                
            }

            if(IS_VALID==TRUE) {
                break;
            }

        }

    }

    else {

        while(TRUE) {

            X_START=rand()%144;

            Y_START=rand()%38;

            int IS_VALID=FALSE;

            if(FLOOR[Y_START][X_START].SYMBOL=='.') {

                IS_VALID=TRUE;

                if(FLOOR[Y_START+1][X_START].SYMBOL=='=' || FLOOR[Y_START+1][X_START].SYMBOL=='+') {
                    IS_VALID=FALSE;
                }
                if(FLOOR[Y_START-1][X_START].SYMBOL=='=' || FLOOR[Y_START-1][X_START].SYMBOL=='+') {
                    IS_VALID=FALSE;
                }
                if(FLOOR[Y_START][X_START+1].SYMBOL=='=' || FLOOR[Y_START][X_START+1].SYMBOL=='+') {
                    IS_VALID=FALSE;
                }
                if(FLOOR[Y_START][X_START-1].SYMBOL=='=' || FLOOR[Y_START][X_START-1].SYMBOL=='+') {
                    IS_VALID=FALSE;
                }
                
            }

            if(IS_VALID==TRUE && GIVE_SECTOR_NUMBER(X_START,Y_START)==PREDETERMINED_START_SECTOR) {
                break;
            }

        }

    }

    int PROHIBITED_EXIT_SECTOR=GIVE_SECTOR_NUMBER(X_START,Y_START);

    int X_END;

    int Y_END;

    while(TRUE) {

            X_END=rand()%144;

            Y_END=rand()%38;

            int IS_VALID=FALSE;

            if(FLOOR[Y_END][X_END].SYMBOL=='.') {

                IS_VALID=TRUE;

                if(FLOOR[Y_END+1][X_END].SYMBOL=='=' || FLOOR[Y_END+1][X_END].SYMBOL=='+') {
                    IS_VALID=FALSE;
                }
                if(FLOOR[Y_END-1][X_END].SYMBOL=='=' || FLOOR[Y_END-1][X_END].SYMBOL=='+') {
                    IS_VALID=FALSE;
                }
                if(FLOOR[Y_END][X_END+1].SYMBOL=='=' || FLOOR[Y_END][X_END+1].SYMBOL=='+') {
                    IS_VALID=FALSE;
                }
                if(FLOOR[Y_END][X_END-1].SYMBOL=='=' || FLOOR[Y_END][X_END-1].SYMBOL=='+') {
                    IS_VALID=FALSE;
                }
                
            }

            if(IS_VALID==TRUE && GIVE_SECTOR_NUMBER(X_END,Y_END)!=PROHIBITED_EXIT_SECTOR) {
                break;
            }

    }

    FLOOR[Y_START][X_START].IS_START=1;

    FLOOR[Y_START][X_START].SYMBOL='<';

    FLOOR[Y_END][X_END].IS_START=-1;

    FLOOR[Y_END][X_END].SYMBOL='<';

    return GIVE_SECTOR_NUMBER(X_END,Y_END);

}

int GIVE_SECTOR_NUMBER(int x, int y) {

    if(y<19) {

        if(x<48) {

            return 1;
        }
        else if(x>=48 && x<96) {

            return 2;

        }
        else {
            return 3;
        }
    }

    else {

        if(x<48) {

            return 4;

        }
        else if(x>=48 && x<96) {

            return 5;
        }
        else {
            return 6;
        }

    }
}

COORDS GIVE_STAIRS_ADDRESS_ENTRY(POINT FLOOR[38][144]) {

    for(int i=0 ; i<38 ; i++) {

        for(int j=0 ; j<144 ; j++) {

            if(FLOOR[i][j].SYMBOL=='<' && FLOOR[i][j].IS_START==1) {

                COORDS ANS;

                ANS.x=j; ANS.y=i;

                return ANS;

            }
        }
    }
}

COORDS GIVE_STAIRS_ADDRESS_EXIT(POINT FLOOR[38][144]) {

    for(int i=0 ; i<38 ; i++) {
        
        for(int j=0 ; j<144 ; j++) {

            if(FLOOR[i][j].SYMBOL=='<' && FLOOR[i][j].IS_START==-1) {

                COORDS ANS;

                ANS.x=j; ANS.y=i;

                return ANS;

            }
        }
    }
}

int FIND_SPECIFIED_DOOR(char WANTED_DIRECTION,  int WANTED_SECTOR, DOOR ALL_DOORS[14]) {

    for(int k=0 ; k<14 ; k++) {

        if(ALL_DOORS[k].DIRECTION==WANTED_DIRECTION && ALL_DOORS[k].SECTOR==WANTED_SECTOR) {

            return k;

        }
    }

}

void GENERATE_ANCIENT_KEY(POINT FLOOR[38][144]) {

    int RAND_X;

    int RAND_Y;

    while(TRUE) {

        RAND_X=rand()%144;

        RAND_Y=rand()%38;

        if(FLOOR[RAND_Y][RAND_X].SYMBOL=='.') {

            FLOOR[RAND_Y][RAND_X].SYMBOL=-1; // Placeholder Ancient Key Convention

            FLOOR[RAND_Y][RAND_X].COLOR='y';

            break;

        }
    }


} 

void HANDLE_USER_INPUT_AND_MOVE_HERO(char *TEMP_PTR, POINT MAP[4][38][144]) {

    int USER_INPUT=getch();

    int VALID;

    if(USER_INPUT!=ERR && USER_INPUT!=KEY_BACKSPACE && USER_INPUT!='f' && USER_INPUT!='F' && USER_INPUT!='g' && USER_INPUT!='G' 
    
    && GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1]!='r') {

        int CURRENT_X=GLOBAL_INVENTORY_AND_COORDINATES.x,CURRENT_Y=GLOBAL_INVENTORY_AND_COORDINATES.y;

        PROCESS_PLAYER_INPUT(USER_INPUT,MAP, TEMP_PTR);

        if(CURRENT_X!=GLOBAL_INVENTORY_AND_COORDINATES.x || CURRENT_Y!=GLOBAL_INVENTORY_AND_COORDINATES.y) {

            HANDLE_ITEM_PICKUPS(MAP,TEMP_PTR);

        }

    }  

    else if(USER_INPUT==KEY_BACKSPACE) {//open pause menu

        cbreak(); //if user chooses to quit, get appropriate exit code from pause menu function
        //////////////for now just closes the program
        //load pause menu
        OPEN_PAUSE_MENU();


        halfdelay(20);

    }

    else if((USER_INPUT=='f' || USER_INPUT=='F') && GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1]!='r') {//movement Macro

        int MACRO_MOVEMENT=getch();

        if(MACRO_MOVEMENT=='1' || MACRO_MOVEMENT=='2'||MACRO_MOVEMENT=='3' || MACRO_MOVEMENT=='4'
        
        || MACRO_MOVEMENT=='6' || MACRO_MOVEMENT=='7'||MACRO_MOVEMENT=='8' || MACRO_MOVEMENT=='9'
        
        ) {//initiate macro

            int CURRENT_X,CURRENT_Y;

            do {

                CURRENT_X=GLOBAL_INVENTORY_AND_COORDINATES.x; CURRENT_Y=GLOBAL_INVENTORY_AND_COORDINATES.y;

                PROCESS_PLAYER_INPUT(MACRO_MOVEMENT,MAP,TEMP_PTR);

                UPDATE_EXPLORATION_AND_HANDLE_INTERACTIVE_OBJECTS(MAP);

                HANDLE_ITEM_PICKUPS(MAP,TEMP_PTR);

                PRINT_MAP_ON_SCREEN(MAP);

                MOVE_ENEMIES(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR]);

                //add anything else as added in main

            } while(CURRENT_X!=GLOBAL_INVENTORY_AND_COORDINATES.x || CURRENT_Y!= GLOBAL_INVENTORY_AND_COORDINATES.y);

        }

    }

    else if(USER_INPUT=='g' || USER_INPUT=='G'|| GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1]=='r') {

        USER_INPUT=getch();

        PROCESS_PLAYER_INPUT(USER_INPUT,MAP,TEMP_PTR);

    }
    
    //no input received. loop in main will go on

}

int PROCESS_PLAYER_INPUT(int USER_INPUT,POINT MAP[4][38][144], char * TEMP_PTR) {

    switch(USER_INPUT) //inventory and other stuff will be implemented later.
    //movement with numpad added
    {
        case '8': {//up

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='U'

            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.y--;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            else if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=='='
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='#'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='+') 
            {

                REVEAL_ENTIRE_SECTOR(MAP,GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-3);

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='?';

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='@'
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].PASSWORD_DOOR_TYPE!='l'

            ) {

                OPEN_PASSKEY_GUI(MAP);

            }


            break;
        }

        case '6': {//right

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='U'

            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.x++;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            else if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL=='='
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='#'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='+')
            {

                REVEAL_ENTIRE_SECTOR(MAP,GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)+1);

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL='?';

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='@'
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].PASSWORD_DOOR_TYPE!='l'

            ) {

                OPEN_PASSKEY_GUI(MAP);

            }

            break;
        }

        case '4': {//left

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='U'
            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.x--;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            else if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL=='='
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='#'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='+'
            
            )
            {

                REVEAL_ENTIRE_SECTOR(MAP,GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1);

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL='?';

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='@'
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].PASSWORD_DOOR_TYPE!='l'

            ) {

                OPEN_PASSKEY_GUI(MAP);

            }

            break;
        }

        case '2': {//down

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='U'

            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.y++;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            else if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=='='
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='#'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='+' 
            ) {

                REVEAL_ENTIRE_SECTOR(MAP,GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)+3);

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='?';

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='@'
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].PASSWORD_DOOR_TYPE!='l'

            ) {

                OPEN_PASSKEY_GUI(MAP);

            }

            break;
        }

        case '9' : {// up right

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='U'
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='U'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='U'

            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.x++;    GLOBAL_INVENTORY_AND_COORDINATES.y--;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            break;
        }

        case '7' : {//up left

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='U'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='U'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='U'

            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.x--;    GLOBAL_INVENTORY_AND_COORDINATES.y--;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }
        
            break;
        }

        case '3' : {//down right

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='U'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='U'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='U'

            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.x++;    GLOBAL_INVENTORY_AND_COORDINATES.y++;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            break;
        }

        case '1' : {//down left

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='U'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='U'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='U'

            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.y++; GLOBAL_INVENTORY_AND_COORDINATES.x--;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            break;
        }
        
        case KEY_RIGHT : {//deeper into a a dungeon

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].IS_START==-1) {

                GLOBAL_INVENTORY_AND_COORDINATES.FLOOR++;

                int BREAK=0;

                GLOBAL_DOOR_PASSWORD=-1;

                GLOBAL_IS_PASSWORD_DYNAMIC=FALSE;

                GLOBAL_PASSWORD_DOOR_BACKGROUND_CHECK=FALSE;

                for(int i=0 ; i<38 ; i++) {

                    for(int j=0 ; j<144 ; j++) {

                        if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].IS_START==1) {

                            GLOBAL_INVENTORY_AND_COORDINATES.y=i;

                            GLOBAL_INVENTORY_AND_COORDINATES.x=j;

                            BREAK++;

                            break;
                        }

                    }

                    if(BREAK==1) {

                        break;
                    }

                }

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            break; 
        }

        case KEY_LEFT : {//back a floor

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].IS_START==1) {

                GLOBAL_INVENTORY_AND_COORDINATES.FLOOR--;

                GLOBAL_DOOR_PASSWORD=-1;

                GLOBAL_IS_PASSWORD_DYNAMIC=FALSE;

                GLOBAL_PASSWORD_DOOR_BACKGROUND_CHECK=FALSE;

                int BREAK=0;

                for(int i=0 ; i<38 ; i++) {

                    for(int j=0 ; j<144 ; j++) {

                        if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].IS_START==-1) {

                            GLOBAL_INVENTORY_AND_COORDINATES.y=i;

                            GLOBAL_INVENTORY_AND_COORDINATES.x=j;

                            BREAK++;

                            break;
                        }

                    }

                    if(BREAK==1) {

                        break;
                    }

                }

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }


            break;
        }

        case 'm' : {

            if(GLOBAL_SHOW_ALL==FALSE) {
                GLOBAL_SHOW_ALL=TRUE;
            }
            else {
                GLOBAL_SHOW_ALL=FALSE;
            }

            break;
        }

        case 'M' : {

            if(GLOBAL_SHOW_ALL==FALSE) {
                GLOBAL_SHOW_ALL=TRUE;
            }
            else {
                GLOBAL_SHOW_ALL=FALSE;
            }

            break;
        }

        case 's' : {

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='^';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='^';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL='^';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL='^';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL='^';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL='^';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL='^';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL='^';

            }

            break;
        }

        case 'S' : {

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL='?';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='^';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='^';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL='^';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL='^';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL='^';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL='^';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL='^';

            }
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='^') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL='^';

            }

            break;

        }

        case 'e' : {

            OPEN_FOOD_MENU();

            break;
        }

        case 'E' : {

            OPEN_FOOD_MENU();

            break;
        }

        case 'i' : {

            OPEN_WEAPONS_MENU();

            break;
        }

        case 'I' : {

            OPEN_WEAPONS_MENU();

            break;
        }

        case 'p' : {

            OPEN_SPELLS_MENU();

            break;
        }

        case 'P' : {

            OPEN_SPELLS_MENU();

            break;
        }

        case ' ' : {
            
            if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='m' || GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='s') {
                HANDLE_PLAYER_COMBAT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR],0);
            }
            else {
                switch(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON) {

                    case 'w' :{

                        if(GLOBAL_INVENTORY_AND_COORDINATES.WAND>0) {
                            int DIR=getch();

                            if(DIR!=ERR) {
                                GLOBAL_LAST_FIRED_DIR=DIR;
                                HANDLE_PLAYER_COMBAT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR],DIR);
                            }

                        }
                        else {
                            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';
                            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"No Ammo!");
                        }


                        break;
                    }
                    case 'd' :{

                        if(GLOBAL_INVENTORY_AND_COORDINATES.DAGGER>0) {

                            int DIR=getch();

                            if(DIR!=ERR) {
                                GLOBAL_LAST_FIRED_DIR=DIR;
                                HANDLE_PLAYER_COMBAT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR],DIR);
                            }
                            
                        }
                        else {
                            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';
                            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"No Ammo!");
                        }

                        break;
                    }
                    case 'a' :{

                        if(GLOBAL_INVENTORY_AND_COORDINATES.ARROW>0) {
                            
                            int DIR=getch();

                            if(DIR!=ERR) {
                                GLOBAL_LAST_FIRED_DIR=DIR;
                                HANDLE_PLAYER_COMBAT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR],DIR);
                            }
                            
                        }
                        else {
                            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';
                            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"No Ammo!");
                        }

                        break;
                    }
                }
            }

            break;
        }
        
        case 'a' : {

            if(GLOBAL_LAST_FIRED_DIR!=0) {

                switch(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON) {

                    case 'w' :{

                        if(GLOBAL_INVENTORY_AND_COORDINATES.WAND>0) {
                            
                            HANDLE_PLAYER_COMBAT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR],GLOBAL_LAST_FIRED_DIR);
                        }
                        else {
                            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';
                            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"No Ammo!");
                        }
                        
                        break;
                    }
                    case 'd' :{

                        if(GLOBAL_INVENTORY_AND_COORDINATES.DAGGER>0) {

                            HANDLE_PLAYER_COMBAT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR],GLOBAL_LAST_FIRED_DIR);
                            
                        }
                        else {
                            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';
                            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"No Ammo!");
                        }

                        break;
                    }
                    case 'a' :{

                        if(GLOBAL_INVENTORY_AND_COORDINATES.ARROW>0) {
                            
                            HANDLE_PLAYER_COMBAT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR],GLOBAL_LAST_FIRED_DIR);
                            
                        }
                        else {
                            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';
                            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"No Ammo!");
                        }

                        break;
                    }
                
                }
            }

            else {
                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';
                strcpy(GLOBAL_MOST_RECENT_MESSAGE,"No Firing Direction Used Yet.");   
            }

            break;
        }
        
        case 'A' : {

            if(GLOBAL_LAST_FIRED_DIR!=0) {

                switch(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON) {

                    case 'w' :{

                        if(GLOBAL_INVENTORY_AND_COORDINATES.WAND>0) {
                            
                            HANDLE_PLAYER_COMBAT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR],GLOBAL_LAST_FIRED_DIR);
                        }
                        else {
                            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';
                            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"No Ammo!");
                        }
                        
                        break;
                    }
                    case 'd' :{

                        if(GLOBAL_INVENTORY_AND_COORDINATES.DAGGER>0) {

                            HANDLE_PLAYER_COMBAT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR],GLOBAL_LAST_FIRED_DIR);
                            
                        }
                        else {
                            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';
                            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"No Ammo!");
                        }

                        break;
                    }
                    case 'a' :{

                        if(GLOBAL_INVENTORY_AND_COORDINATES.ARROW>0) {
                            
                            HANDLE_PLAYER_COMBAT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR],GLOBAL_LAST_FIRED_DIR);
                            
                        }
                        else {
                            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';
                            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"No Ammo!");
                        }

                        break;
                    }
                
                }
            }

            else {
                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';
                strcpy(GLOBAL_MOST_RECENT_MESSAGE,"No Firing Direction Used Yet.");   
            }

            break;
            
        }

    }

    if(GLOBAL_EFFECTS_STORAGE.S>0 && (USER_INPUT>='1') && (USER_INPUT<='9') && USER_INPUT!='5') {

        int SECTOR=GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1;
        
        if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='+') {
            GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].MOVES_LEFT=GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].MAX_MOVE_TILES;
        }

        switch(USER_INPUT) {
        
        case '8': {//up

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='U'

            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.y--;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            else if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=='='
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='#'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='+') 
            {

                REVEAL_ENTIRE_SECTOR(MAP,GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-3);

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='?';

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='@'
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].PASSWORD_DOOR_TYPE!='l'

            ) {

                OPEN_PASSKEY_GUI(MAP);

            }


            break;
        }

        case '6': {//right

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='U'

            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.x++;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            else if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL=='='
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='#'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='+')
            {

                REVEAL_ENTIRE_SECTOR(MAP,GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)+1);

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL='?';

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS=='@'
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].PASSWORD_DOOR_TYPE!='l'

            ) {

                OPEN_PASSKEY_GUI(MAP);

            }

            break;
        }

        case '4': {//left

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='U'
            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.x--;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            else if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL=='='
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='#'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='+'
            
            )
            {

                REVEAL_ENTIRE_SECTOR(MAP,GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1);

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL='?';

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS=='@'
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].PASSWORD_DOOR_TYPE!='l'

            ) {

                OPEN_PASSKEY_GUI(MAP);

            }

            break;
        }

        case '2': {//down

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='U'

            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.y++;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            else if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=='='
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='#'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='+' 
            ) {

                REVEAL_ENTIRE_SECTOR(MAP,GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)+3);

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='?') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='+';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='?';

            }

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='@'
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].PASSWORD_DOOR_TYPE!='l'

            ) {

                OPEN_PASSKEY_GUI(MAP);

            }

            break;
        }

        case '9' : {// up right

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='U'
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='U'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='U'

            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.x++;    GLOBAL_INVENTORY_AND_COORDINATES.y--;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            break;
        }

        case '7' : {//up left

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='U'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='U'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y-1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='U'

            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.x--;    GLOBAL_INVENTORY_AND_COORDINATES.y--;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }
        
            break;
        }

        case '3' : {//down right

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='U'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='U'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x+1].SYMBOL!='U'

            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.x++;    GLOBAL_INVENTORY_AND_COORDINATES.y++;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            break;
        }

        case '1' : {//down left

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL!='U'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='U'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='=' 
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].REAL_CONTENTS!='@' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!=' '
            
            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='O'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='_' 

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='|'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='D'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='F'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='G'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='S'

            && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y+1][GLOBAL_INVENTORY_AND_COORDINATES.x-1].SYMBOL!='U'

            ) {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL=*TEMP_PTR;

                GLOBAL_INVENTORY_AND_COORDINATES.y++; GLOBAL_INVENTORY_AND_COORDINATES.x--;

                *TEMP_PTR=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL;

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].SYMBOL='H';

            }

            break;
        }
        
        }
    }

}

void PRINT_MAP_ON_SCREEN(POINT MAP[4][38][144]) {

    clear();
    
    TURN_ON_COLOR_FOR_MAP_PRINT(GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE);

    mvprintw(0,0,"%s",GLOBAL_MOST_RECENT_MESSAGE);

    TURN_OFF_COLOR_FOR_MAP_PRINT(GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE);

    move(0,0);

    attrset(WHITE_COLORED_CELL);

    for(int i=1 ; i<37 ; i++) {

        for(int j=0 ; j<144 ; j++) {

            if((GLOBAL_SHOW_ALL==FALSE 
            
            && GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1]!='r')
            
            || (MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='#' && GLOBAL_SHOW_ALL==FALSE)
            
            ) {

                if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].IS_DISCOVERED==1) {

                    if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL=='H') {//print hero color

                        TURN_ON_COLOR_FOR_MAP_PRINT(GLOBAL_SETTINGS.HERO_COLOR);

                        mvprintw(i,j,"%c",MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL);

                        TURN_OFF_COLOR_FOR_MAP_PRINT(GLOBAL_SETTINGS.HERO_COLOR);

                    }
                    else {

                        TURN_ON_COLOR_FOR_MAP_PRINT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR);

                        if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL>0) {

                            mvprintw(i,j,"%c",MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL);

                        }

                        else {// special symbols////////more added later

                            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL==-1) {

                                mvprintw(i,j,"Δ");

                            }
                            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL==-2) {//wand

                                mvprintw(i,j,"ζ");

                            }
                            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL==-3) {//sword

                                mvprintw(i,j,"τ");

                            }
                            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL==-4) {//dagger

                                mvprintw(i,j,"ι");
 
                            }


                        }

                        TURN_OFF_COLOR_FOR_MAP_PRINT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR);

                    }
                }
                else
                    mvprintw(i,j," ");
            }

            else if((GLOBAL_SHOW_ALL==TRUE 
            
            && GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1]!='r')
            
            || (MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='#' && GLOBAL_SHOW_ALL==TRUE)

            ) {

                if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL=='H') {//print hero color

                    TURN_ON_COLOR_FOR_MAP_PRINT(GLOBAL_SETTINGS.HERO_COLOR);

                    mvprintw(i,j,"%c",MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL);

                    TURN_OFF_COLOR_FOR_MAP_PRINT(GLOBAL_SETTINGS.HERO_COLOR);

                }
                else {

                    TURN_ON_COLOR_FOR_MAP_PRINT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR);

                    if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL>0) {

                        mvprintw(i,j,"%c",MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL);

                    }

                    else {// special symbols////////more added later

                        if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL==-1) {

                            mvprintw(i,j,"Δ");

                        }

                        if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL==-2) {//wand

                            mvprintw(i,j,"ζ");

                        }
                        if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL==-3) {//sword

                            mvprintw(i,j,"τ");

                        }
                        if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL==-4) {//dagger

                            mvprintw(i,j,"ι");
 
                        }

                    }

                    TURN_OFF_COLOR_FOR_MAP_PRINT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR);
                }

            }

            else {//nightmare vision

                if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].IS_DISCOVERED==1 
                
                && i>=GLOBAL_INVENTORY_AND_COORDINATES.y-2 && i<= GLOBAL_INVENTORY_AND_COORDINATES.y+2 &&

                j>=GLOBAL_INVENTORY_AND_COORDINATES.x-2 && j<= GLOBAL_INVENTORY_AND_COORDINATES.x+2

                ) {

                    if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL=='H') {//print hero color

                        TURN_ON_COLOR_FOR_MAP_PRINT(GLOBAL_SETTINGS.HERO_COLOR);

                        mvprintw(i,j,"%c",MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL);

                        TURN_OFF_COLOR_FOR_MAP_PRINT(GLOBAL_SETTINGS.HERO_COLOR);

                    }
                    else {

                        TURN_ON_COLOR_FOR_MAP_PRINT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR);

                        if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL>0) {

                            mvprintw(i,j,"%c",MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL);

                        }

                        else {// special symbols////////more added later

                            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL==-1) {

                                mvprintw(i,j,"Δ");

                            }
                            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL==-2) {//wand

                                mvprintw(i,j,"ζ");

                            }
                            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL==-3) {//sword

                                mvprintw(i,j,"τ");

                            }
                            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL==-4) {//dagger

                                mvprintw(i,j,"ι");
 
                            }


                        }

                        TURN_OFF_COLOR_FOR_MAP_PRINT(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR);

                    }
                }
                else
                    mvprintw(i,j," ");


            }
        }

    }

    attroff(WHITE_COLORED_CELL);

    mvprintw(ROW-2,0,"Keys: %d | Broken Keys: %d",GLOBAL_INVENTORY_AND_COORDINATES.KEYS,GLOBAL_INVENTORY_AND_COORDINATES.BROKEN_KEYS);

    mvprintw(ROW-1,0,"Floor : %d |",GLOBAL_INVENTORY_AND_COORDINATES.FLOOR+1);

    char STRING[20];

    switch(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON) {
        case 'm' : 
            strcpy(STRING,"Mace");
            break;
        case 'w' :
            strcpy(STRING,"Magic Wand");
            break;
        case 'a' : 
            strcpy(STRING,"Arrows");
            break;
        case 's' : 
            strcpy(STRING,"Sword");
            break;
        case 'd' :
            strcpy(STRING,"Daggers");
            break;
        case 0 :
            strcpy(STRING,"Unequipped");
            break;
    }

    mvprintw(ROW-1,13,"HP : %d/%d | Saturation : %d/100 | Gold : %d | Score : %d | Equipped Weapon : %s" 
    
    ,GLOBAL_INVENTORY_AND_COORDINATES.HP,GLOBAL_MAX_HP,GLOBAL_INVENTORY_AND_COORDINATES.HUNGER
    
    ,GLOBAL_INVENTORY_AND_COORDINATES.GOLD,GLOBAL_INVENTORY_AND_COORDINATES.SCORE,STRING);

    move(0,0);

    refresh();

    strcpy(GLOBAL_MOST_RECENT_MESSAGE,"\0");

}

void UPDATE_EXPLORATION_AND_HANDLE_INTERACTIVE_OBJECTS(POINT MAP[4][38][144]) {

    if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='+' 
    
    || MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='<'
    
    || MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='.'

    ) {//reveal entire room

        REVEAL_ENTIRE_SECTOR(MAP,GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y));

    }

    if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='+' 

    ||  MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='#')

    {//start revealing corridors

        REVEAL_HALLWAYS(MAP,0,6,GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y);
    
    }

    if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='&' 
    
    && (MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR=='y'

    || MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR=='o'
    
    || MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR=='w'))

    {

        HANDLE_DOOR_PASSKEY_GENERATION(MAP);

    }

    if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='^') {

        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Stepped On a Trap!");

        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

        PRINT_MESSAGE("You Stepped On a Trap!");

        HANDLE_TRAP_ACTIVATION();

    }

    if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='x'
    
    && GLOBAL_BOSSES_IN_LAST_ROOM[0].HP<=0 && GLOBAL_BOSSES_IN_LAST_ROOM[1].HP<=0 && GLOBAL_BOSSES_IN_LAST_ROOM[2].HP<=0 && GLOBAL_BOSSES_IN_LAST_ROOM[3].HP<=0) {

        GLOBAL_INVENTORY_AND_COORDINATES.SCORE+=5000;

        OPEN_VICTORY_MENU();

    }

}

void REVEAL_ENTIRE_SECTOR(POINT MAP[4][38][144],int SECTOR) {

    SECTOR--;

    for(int i=(SECTOR/3)*19; i<19+(SECTOR/3)*19 ; i++) {

        for(int j=(SECTOR%3)*48 ; j<(SECTOR%3)*48+48 ; j++) {

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL!='#') {

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].IS_DISCOVERED=1;

            }
        }
    }
}

void REVEAL_HALLWAYS(POINT MAP[4][38][144], char DONT_CHECK_DIRECTION,int MOVES_LEFT , int CURSOR_X , int CURSOR_Y) {

    if(MOVES_LEFT!=0) {

        if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][CURSOR_Y][CURSOR_X].REAL_CONTENTS=='+' 
    
        || MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][CURSOR_Y][CURSOR_X].REAL_CONTENTS=='#') 
    
        {

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][CURSOR_Y][CURSOR_X].IS_DISCOVERED=1;

        }



        if((MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][CURSOR_Y][CURSOR_X+1].REAL_CONTENTS=='#'
    
        || MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][CURSOR_Y][CURSOR_X+1].REAL_CONTENTS=='+'
    
        )
    
        && DONT_CHECK_DIRECTION!='r'
    
        ) {

            REVEAL_HALLWAYS(MAP,'l',MOVES_LEFT-1,CURSOR_X+1,CURSOR_Y);

        }

        if((MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][CURSOR_Y][CURSOR_X-1].REAL_CONTENTS=='#'
    
        || MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][CURSOR_Y][CURSOR_X-1].REAL_CONTENTS=='+'
    
        )
    
        && DONT_CHECK_DIRECTION!='l'
    
        ) {

            REVEAL_HALLWAYS(MAP,'r',MOVES_LEFT-1,CURSOR_X-1,CURSOR_Y);

        }

        if((MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][CURSOR_Y+1][CURSOR_X].REAL_CONTENTS=='#'
    
        || MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][CURSOR_Y+1][CURSOR_X].REAL_CONTENTS=='+'
    
        )
    
        && DONT_CHECK_DIRECTION!='d'
    
        ) {

            REVEAL_HALLWAYS(MAP,'u',MOVES_LEFT-1,CURSOR_X,CURSOR_Y+1);

        }

        if((MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][CURSOR_Y-1][CURSOR_X].REAL_CONTENTS=='#'
    
        || MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][CURSOR_Y-1][CURSOR_X].REAL_CONTENTS=='+'
    
        )
    
        && DONT_CHECK_DIRECTION!='u'
    
        ) {

            REVEAL_HALLWAYS(MAP,'d',MOVES_LEFT-1,CURSOR_X,CURSOR_Y-1);

        }


    }

}

void TURN_ON_COLOR_FOR_MAP_PRINT(char COLOR_TO_BE_PRINTED) {

    switch(COLOR_TO_BE_PRINTED) {

        case 'r' :

            attron(RED_COLORED_CELL);

            break;
        case 'b' :

            attron(BLUE_COLORED_CELL);

            break;
        case 'y' : 

            attron(GOLD_COLORED_CELL);

            break;
        case 'w' :

            attron(WHITE_COLORED_CELL);

            break;
        case 'g' :

            attron(GREEN_COLORED_CELL);

            break;
        case 'o':

            attron(ORANGE_COLORED_CELL);

            break;
    }

}

void TURN_OFF_COLOR_FOR_MAP_PRINT(char COLOR_TO_BE_OFFED) {

    switch(COLOR_TO_BE_OFFED) {

        case 'r' :

            attroff(RED_COLORED_CELL);

            break;
        case 'b' :

            attroff(BLUE_COLORED_CELL);

            break;
        case 'y' : 

            attroff(GOLD_COLORED_CELL);

            break;
        case 'w' :

            attroff(WHITE_COLORED_CELL);

            break;
        case 'g' :

            attroff(GREEN_COLORED_CELL);

            break;
        case 'o':

            attroff(ORANGE_COLORED_CELL);

            break;
    }

}

void PRINT_MESSAGE(char MESSAGE[]) {

    TURN_ON_COLOR_FOR_MAP_PRINT(GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE);

    mvprintw(0,0,"%s",MESSAGE);

    TURN_OFF_COLOR_FOR_MAP_PRINT(GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE);

}

void CLEAR_MESSAGE_BAR() {

    mvprintw(0,0,"                                                                                       ");

}

void PASSWORD_BACKGROUND_CHECK() {

    unsigned long long int CURRENT_TIME_QUERRY=time(NULL);

    if(CURRENT_TIME_QUERRY-GLOBAL_MOST_RECENT_PASSWORD_REQUEST_TIME>=30) {

        GLOBAL_PASSWORD_DOOR_BACKGROUND_CHECK=FALSE;

        if(GLOBAL_IS_PASSWORD_DYNAMIC==TRUE) {

            GLOBAL_DOOR_PASSWORD=-1;

            GLOBAL_IS_PASSWORD_DYNAMIC=FALSE;

        }

    }

    else {

        attron(GOLD_COLORED_CELL | A_BLINK);

        mvprintw(1,COLUMN/2 - 11,"Door Passkey is : %.4d",GLOBAL_DOOR_PASSWORD);

        attroff(GOLD_COLORED_CELL); attroff(A_BLINK);

        refresh();

    }

}

void HANDLE_DOOR_PASSKEY_GENERATION(POINT MAP[4][38][144]) {

    GLOBAL_MOST_RECENT_PASSWORD_REQUEST_TIME=time(NULL);

    int IS_DYNAMIC=FALSE;

    int BREAK=0;

    for(int i=0 ; i<38 ; i++) {

        for(int j=0 ; j<144 ; j++) {

            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL=='@') {

                if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].PASSWORD_DOOR_TYPE=='t') {

                    GLOBAL_IS_PASSWORD_DYNAMIC=TRUE;

                }

                BREAK++;

                break;

            }

        }

        if(BREAK==1) {
            break;
        }

    }

    GLOBAL_PASSWORD_DOOR_BACKGROUND_CHECK=TRUE;

    GLOBAL_DOOR_PASSWORD=rand()%10000;

}

void OPEN_PASSKEY_GUI(POINT MAP[4][38][144]) {

    clear();

    attron(GOLD_COLORED_CELL);

    cbreak();

    mvprintw(0,COLUMN/2 -30,"Input 4 Digit Passkey. Enter 0 to Use a Key If You Have One");

    mvprintw(ROW/2 , COLUMN/2 -2,"####");

    echo(); curs_set(1); move(ROW/2 -1,COLUMN/2 -2); refresh();

    attroff(GOLD_COLORED_CELL);

    int INPUTTED_PASSKEY; 

    int CORRECT_PASSWORD; int DOOR_X,DOOR_Y;

    for(int i=0 ; i<38 ; i++) {//reverse entering passkey and finding door x,y
        int BREAK=0;
        for(int j=0 ; j<144 ; j++) {
            if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL=='@') {

                DOOR_X=j; DOOR_Y=i;

                if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].PASSWORD_DOOR_TYPE=='r') {

                    int X,Y,Z,T;

                    T=GLOBAL_DOOR_PASSWORD%10; Z=(GLOBAL_DOOR_PASSWORD%100-T)/10 ; Y=(GLOBAL_DOOR_PASSWORD%1000-Z*10-T)/100;

                    X=(GLOBAL_DOOR_PASSWORD%10000-100*Y-10*Z-T)/1000;

                    CORRECT_PASSWORD=1000*T+100*Z+10*Y+X;

                }

                BREAK++;
                break;
            }
        }
        if(BREAK==1) {
            break;
        }
    }

    if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][DOOR_Y][DOOR_X].PASSWORD_DOOR_TYPE!='r') {

        CORRECT_PASSWORD=GLOBAL_DOOR_PASSWORD;

    }

    scanw("%d",&INPUTTED_PASSKEY);

    noecho(); curs_set(0);

    if(INPUTTED_PASSKEY==0) {//ancient key usage

        int ANCIENT_KEY_USAGE_QUERRY=HANDLE_ANCIENT_KEY_USAGE(); //returns 1 if used successfuly. 0 if none in player inventory.
                                                                 // -1 if key broke in the proccess. 
        if(ANCIENT_KEY_USAGE_QUERRY==1) {

            clear(); attron(GREEN_COLORED_CELL);

            mvprintw(ROW/2,COLUMN/2 -22,"Key Used Successfully! Press a Key to Exit.");

            attroff(GREEN_COLORED_CELL); refresh(); getch();

            GLOBAL_INVENTORY_AND_COORDINATES.KEYS--;

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][DOOR_Y][DOOR_X].COLOR='g';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][DOOR_Y][DOOR_X].REAL_CONTENTS='+';

            for(int i=0 ; i<38 ; i++) {

                for(int j=0 ; j<144 ; j++) {

                    if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL=='&') {

                        MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR='g';

                    }
                }
            }

        }

        else if(ANCIENT_KEY_USAGE_QUERRY==-1) {

            GLOBAL_INVENTORY_AND_COORDINATES.KEYS--; GLOBAL_INVENTORY_AND_COORDINATES.BROKEN_KEYS++;

            clear(); attron(GOLD_COLORED_CELL);

            mvprintw(ROW/2,COLUMN/2 -21,"Oops. The Key Broke! Press a Key to Exit.");

            if(GLOBAL_INVENTORY_AND_COORDINATES.BROKEN_KEYS==2) {

                mvprintw(ROW/2+1, COLUMN/2 -23,"You Combined 2 Broken Keys to Make a New Key!");

                GLOBAL_INVENTORY_AND_COORDINATES.BROKEN_KEYS-=2;

                GLOBAL_INVENTORY_AND_COORDINATES.KEYS++;

            }

            attroff(GREEN_COLORED_CELL); refresh(); getch();

        }

        else {

            clear(); attron(ORANGE_COLORED_CELL);

            mvprintw(ROW/2 ,COLUMN/2 -23,"You Don't Have Any Keys! Press a key to Exit.");

            attroff(ORANGE_COLORED_CELL); refresh(); getch();

        }

    }

    else if(INPUTTED_PASSKEY==CORRECT_PASSWORD) {

        GLOBAL_PASSWORD_DOOR_BACKGROUND_CHECK=FALSE;

        GLOBAL_DOOR_PASSWORD=-1;

        clear(); attron(GREEN_COLORED_CELL);

        mvprintw(ROW/2 ,COLUMN/2 -20,"Correct Passkey! Press a Key to Continue");

        refresh(); getch();

        attroff(GREEN_COLORED_CELL);

        for(int i=0 ; i<38 ; i++) {
            int BREAK=0;
            for(int j=0 ; j<144 ; j++) {
                if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL=='&' && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR!='g') {
                    MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR='g';
                    BREAK++;
                    break;
                }
            }
            if(BREAK==1) {
                break;
            }
        }

        if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][DOOR_Y][DOOR_X].PASSWORD_DOOR_TYPE=='2') {

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][DOOR_Y][DOOR_X].PASSWORD_DOOR_TYPE='1';

        }

        else {

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][DOOR_Y][DOOR_X].COLOR='g';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][DOOR_Y][DOOR_X].REAL_CONTENTS='+';

        }
                    
    
    }

    else {

        GLOBAL_PASSWORD_DOOR_BACKGROUND_CHECK=FALSE;

        if(GLOBAL_IS_PASSWORD_DYNAMIC==TRUE) {
            GLOBAL_DOOR_PASSWORD=-1;
        }

        GLOBAL_IS_PASSWORD_DYNAMIC=FALSE;
        
        //determine warning level
        if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][DOOR_Y][DOOR_X].COLOR=='r') {

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][DOOR_Y][DOOR_X].COLOR='y';

            for(int i=0 ; i<38 ; i++) {
                for (int j=0 ; j<144 ; j++) {
                    if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL=='&' && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR!='g') {

                        MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR='y';

                    }
                }
            }

            attron(GOLD_COLORED_CELL); clear();
            mvprintw(ROW/2, COLUMN/2 - 29,"Wrong Passkey! 1st Warning Issued. Press a Key to Continue"); 
            attroff(GOLD_COLORED_CELL); refresh(); getch();

        }
        else if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][DOOR_Y][DOOR_X].COLOR=='y') {

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][DOOR_Y][DOOR_X].COLOR='o';

            for(int i=0 ; i<38 ; i++) {
                for (int j=0 ; j<144 ; j++) {
                    if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL=='&' && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR!='g') {

                        MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR='o';

                    }
                }
            }
            clear(); attron(ORANGE_COLORED_CELL);
            mvprintw(ROW/2 , COLUMN/2 -27,"Wrong Passkey! Last Warning! Press a Key to Continue."); 
            refresh(); getch();
            attroff(ORANGE_COLORED_CELL);
        }
        else if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][DOOR_Y][DOOR_X].COLOR=='o') {

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][DOOR_Y][DOOR_X].COLOR='r';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][DOOR_Y][DOOR_X].PASSWORD_DOOR_TYPE='l';

            for(int i=0 ; i<38 ; i++) {
                for (int j=0 ; j<144 ; j++) {
                    if(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].SYMBOL=='&' && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR!='g') {

                        MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][i][j].COLOR='r';

                    }
                }
            }
            clear(); attron(RED_COLORED_CELL);
            mvprintw(ROW/2 , COLUMN/2 -30,"Wrong Passkey! Security Activated! Press a Key to Continue."); 
            refresh(); getch();
            attroff(RED_COLORED_CELL);
        }

    }

    halfdelay(20);

    PRINT_MAP_ON_SCREEN(MAP);

}

int HANDLE_ANCIENT_KEY_USAGE() {

    if(GLOBAL_INVENTORY_AND_COORDINATES.KEYS>0) {

        int RANDOM_TRIAL=rand()%100+1;

        if(RANDOM_TRIAL<=10) {

            return -1;

        }

        else {

            return 1;

        }

    }

    else {

        return 0;

    }

}

void HANDLE_ITEM_PICKUPS(POINT MAP[4][38][144],char *TEMP_PTR) {
    //change picked up items' color to theme default
    switch(MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS) {

        case -1 :{//key

            *TEMP_PTR='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

            GLOBAL_INVENTORY_AND_COORDINATES.KEYS++;

            attron(GOLD_COLORED_CELL);

            PRINT_MESSAGE("Picked Up an Ancient Key!");

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"Picked Up an Ancient Key!");

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
            =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
            .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

            attroff(GOLD_COLORED_CELL);

            refresh();

            break;
        }
        case '$' : {//normal gold

            *TEMP_PTR='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

            int RANDOM_TRIAL_1=rand()%5; //1st and 2nd digit of gold amount

            int RANDOM_TRIAL_2=rand()%9+1;

            GLOBAL_INVENTORY_AND_COORDINATES.GOLD+=RANDOM_TRIAL_1*10+RANDOM_TRIAL_2;

            GLOBAL_INVENTORY_AND_COORDINATES.SCORE+=10*(RANDOM_TRIAL_1*10+RANDOM_TRIAL_2);

            char STRING[100]="You Picked Up ";

            char TEMP[3]; TEMP[0]=48+RANDOM_TRIAL_1; TEMP[1]=48+RANDOM_TRIAL_2; TEMP[2]='\0';

            strcat(STRING,TEMP);

            strcat(STRING," Gold");

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,STRING);

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
            =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
            .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

            PRINT_MESSAGE(STRING);

            break;
        }
        case '~' : {//food

            if(GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR+GLOBAL_INVENTORY_AND_COORDINATES.FOOD_ELITE
            
            +GLOBAL_INVENTORY_AND_COORDINATES.FOOD_MAGIC+GLOBAL_INVENTORY_AND_COORDINATES.FOOD_SPOILED<5) {

                char COLOR_OF_FOOD=MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR;
                
                *TEMP_PTR='.';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

                MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
                =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
                .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];
                
                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

                if(COLOR_OF_FOOD=='r') {
                    strcpy(GLOBAL_MOST_RECENT_MESSAGE,"Picked Up 1 Regular Ration.");

                    PRINT_MESSAGE("Picked Up 1 Regular Ration.");

                    GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR++;
                }
                if(COLOR_OF_FOOD=='y') {
                    strcpy(GLOBAL_MOST_RECENT_MESSAGE,"Picked Up 1 Elite Ration.");

                    PRINT_MESSAGE("Picked Up 1 Elite Ration.");

                    GLOBAL_INVENTORY_AND_COORDINATES.FOOD_ELITE++;

                }
                if(COLOR_OF_FOOD=='b') {
                    strcpy(GLOBAL_MOST_RECENT_MESSAGE,"Picked Up 1 Magical Ration.");

                    PRINT_MESSAGE("Picked Up 1 Magical Ration.");

                    GLOBAL_INVENTORY_AND_COORDINATES.FOOD_MAGIC++;
                }

            }

            else {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Can't Hold More Than 5 Rations!");

                PRINT_MESSAGE("You Can't Hold More Than 5 Rations!");

            }



            break;
        }
        case '*' : {//black gold

            *TEMP_PTR='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
            =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
            .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

            int RANDOM_1=1; int RANDOM_2=rand()%10; int RANDOM_3=rand()%10;

            GLOBAL_INVENTORY_AND_COORDINATES.GOLD+=100*RANDOM_1+10*RANDOM_2+RANDOM_3;

            GLOBAL_INVENTORY_AND_COORDINATES.SCORE+=10*(100*RANDOM_1+10*RANDOM_2+RANDOM_3);

            char STRING[100]="You Picked Up Black Gold : ";

            char TEMPORARY[4]; TEMPORARY[0]=48+RANDOM_1; TEMPORARY[1]=48+RANDOM_2; TEMPORARY[2]=48+RANDOM_3; TEMPORARY[3]='\0';

            strcat(STRING,TEMPORARY);

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,STRING);

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

            break;
        }
        case 's' : {//speed spell

            *TEMP_PTR='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
            =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
            .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

            GLOBAL_INVENTORY_AND_COORDINATES.S_SPELL++;

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Picked Up a Speed Spell");

            PRINT_MESSAGE("You Picked Up a Speed Spell");

            break;
        }
        case 'h' : {//health spell

            *TEMP_PTR='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
            =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
            .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

            GLOBAL_INVENTORY_AND_COORDINATES.H_SPELL++;

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Picked Up a Health Spell");

            PRINT_MESSAGE("You Picked Up a Health Spell");

            break;
        }
        case 'd' : {//damage spell

            *TEMP_PTR='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
            =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
            .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

            GLOBAL_INVENTORY_AND_COORDINATES.D_SPELL++;

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Picked Up a Damage Spell");

            PRINT_MESSAGE("You Picked Up a Damage Spell");

            break;
        }
        case -3 : {//sword

            if(GLOBAL_INVENTORY_AND_COORDINATES.SWORD==0) {

            *TEMP_PTR='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
            =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
            .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

            GLOBAL_INVENTORY_AND_COORDINATES.SWORD++;

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Picked Up a Sword");

            PRINT_MESSAGE("You Picked Up a Sword");

            }

            else {
                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Already Have a Sword!");

                PRINT_MESSAGE("You Already Have a Sword!");
            }


            break;
        }
        case 'M' : {//mace
            *TEMP_PTR='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
            =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
            .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

            GLOBAL_INVENTORY_AND_COORDINATES.MACE++;

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Picked Up a Mace");

            PRINT_MESSAGE("You Picked Up a Mace");

            break;
        }
        case -2 : {//magic wand
            *TEMP_PTR='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
            =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
            .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

            GLOBAL_INVENTORY_AND_COORDINATES.WAND+=8;

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Picked Up a Magic Wand Bundle(8)");

            PRINT_MESSAGE("You Picked Up a Magic Wand Bundle(8)");

            break;
        }
        case 'A' : {//arrow
            *TEMP_PTR='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
            =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
            .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

            GLOBAL_INVENTORY_AND_COORDINATES.ARROW+=20;

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Picked Up a Normal Arrow Bundle(20)");

            PRINT_MESSAGE("You Picked Up a Normal Arrow Bundle(20)");

            break;
        }
        case -4 : {//dagger
            *TEMP_PTR='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
            =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
            .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

            GLOBAL_INVENTORY_AND_COORDINATES.DAGGER+=10;

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Picked Up a Dagger Bundle(10)");

            PRINT_MESSAGE("You Picked Up a Dagger Bundle(10)");


            break;
        }
    
        //add throwables' fragments here.
        case 'i' : {//one dagger
            *TEMP_PTR='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
            =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
            .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

            GLOBAL_INVENTORY_AND_COORDINATES.DAGGER+=1;

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Picked Up 1 Dagger");

            PRINT_MESSAGE("You Picked Up 1 Dagger");

            break;
        }
        case 'a' : {// one arrow
            *TEMP_PTR='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
            =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
            .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

            GLOBAL_INVENTORY_AND_COORDINATES.ARROW+=1;

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Picked Up 1 Arrow");

            PRINT_MESSAGE("You Picked Up 1 Arrow");

            break;
        }
        case 'z' : {//one wand
            *TEMP_PTR='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS='.';

            MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].COLOR
            
            =GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES
            
            .x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1];

            GLOBAL_INVENTORY_AND_COORDINATES.WAND+=1;

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Picked Up 1 Wand");

            PRINT_MESSAGE("You Picked Up 1 Wand");

            break;
        }
    
    
    }

}

void OPEN_PAUSE_MENU() {

    PRINT_PAUSE_MENU();

    while(TRUE) {

        int x,y,INPUT; getyx(stdscr,y,x); INPUT=getch();

        if(y==2*ROW/5) {

            if(INPUT==KEY_DOWN) {

                attron(GOLD_COLORED_CELL); mvprintw(2*ROW/5 , COLUMN/2 -2,"Quit"); attroff(GOLD_COLORED_CELL);

                attron(GOLD_HIGHLIGHT |A_BLINK); mvprintw(3*ROW/5 ,COLUMN/2 -7,"Save and Quit"); attroff(GOLD_HIGHLIGHT); attroff(A_BLINK);

            }
            else if(INPUT=='e' || INPUT=='E') {//unsaved

                GLOBAL_EXIT_CODE=1;

                break;
            }

        }
        else if(y==3*ROW/5) {

            if(INPUT==KEY_UP) {

                attron(GOLD_COLORED_CELL); mvprintw(3*ROW/5 , COLUMN/2 -7,"Save and Quit"); attroff(GOLD_COLORED_CELL);

                attron(GOLD_HIGHLIGHT |A_BLINK); mvprintw(2*ROW/5 ,COLUMN/2 -2,"Quit"); attroff(GOLD_HIGHLIGHT); attroff(A_BLINK);

            }
            else if(INPUT==KEY_DOWN) {

                attron(GOLD_COLORED_CELL); mvprintw(3*ROW/5 , COLUMN/2 -7,"Save and Quit"); attroff(GOLD_COLORED_CELL);

                attron(GOLD_HIGHLIGHT |A_BLINK); mvprintw(4*ROW/5 ,COLUMN/2 -2,"Back"); attroff(GOLD_HIGHLIGHT); attroff(A_BLINK);

            }
            else if(INPUT=='e' ||INPUT=='E') {//save and quit

                GLOBAL_EXIT_CODE=3;

                break;

            }

        }
        else {

            if(INPUT==KEY_UP) {

                attron(GOLD_COLORED_CELL); mvprintw(4*ROW/5 , COLUMN/2 -2,"Back"); attroff(GOLD_COLORED_CELL);

                attron(GOLD_HIGHLIGHT |A_BLINK); mvprintw(3*ROW/5 ,COLUMN/2 -7,"Save and Quit"); attroff(GOLD_HIGHLIGHT); attroff(A_BLINK);  

            }

            else if(INPUT=='e' ||INPUT=='E') {//back

                break;
                
            }

        }

        refresh();

    }

}

void PRINT_PAUSE_MENU() {

    clear();

    char pause_icon[][20]={
        "  ,---,  ,---,", 
        ",---.'|,---.'|", 
        "|   | :|   | :", 
        "'   : ''   : '", 
        ":   | |:   | |", 
        "|   ' :|   ' :", 
        ";   ; |;   ; |", 
        "'   | ''   | '", 
        "|   | :|   | :", 
        "'   : ''   : '", 
        "|   | ||   | |", 
        ";   : ;;   : ;", 
        "|   ,/ |   ,/",  
        "'---'  '---'",
    };

    char swords[][80]={
        "           /\\                                                 /\\",
        " _         )( ______________________   ______________________ )(         _",
        "(_)///////(**)______________________> <______________________(**)\\\\\\\\\\\\\\(_)",
        "           )(                                                 )(",
        "           \\/                                                 \\/"
    };

    attrset(BLUE_COLORED_CELL);

    for(int i=0 ; i<14 ; i++) {
        mvprintw(ROW/3+i,5,"%s",pause_icon[i]);
        mvprintw(ROW/3+i, 5*COLUMN/6, "%s", pause_icon[i]);
    }

    for(int i=0 ; i<5 ; i++) {
        mvprintw(4*ROW/5 +1+i,COLUMN/2- strlen(swords[2])/2,"%s",swords[i]);
    }

    attroff(BLUE_COLORED_CELL);

    attron(GOLD_COLORED_CELL | A_ITALIC);

    mvprintw(ROW/5,COLUMN/2 -5,"Pause Menu");

    attroff(A_ITALIC);

    mvprintw(2*ROW/5 , COLUMN/2 -2, "Quit");

    mvprintw(3*ROW/5 , COLUMN/2 -7 ,"Save and Quit");

    attroff(GOLD_COLORED_CELL);

    attron(GOLD_HIGHLIGHT | A_BLINK);

    mvprintw(4*ROW/5,COLUMN/2 -2,"Back");

    attroff(GOLD_HIGHLIGHT); attroff(A_BLINK);

    refresh();

}

void START_GAME(int* OK_LAUNCH) {

    GLOBAL_INVENTORY_AND_COORDINATES.FLOOR=0; GLOBAL_INVENTORY_AND_COORDINATES.KEYS=0; GLOBAL_INVENTORY_AND_COORDINATES.BROKEN_KEYS=0;

    GLOBAL_INVENTORY_AND_COORDINATES.H_SPELL=0; GLOBAL_INVENTORY_AND_COORDINATES.D_SPELL=0 ; GLOBAL_INVENTORY_AND_COORDINATES.S_SPELL=0;

    GLOBAL_INVENTORY_AND_COORDINATES.SCORE=0; GLOBAL_INVENTORY_AND_COORDINATES.GOLD=0; GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR=0;

    GLOBAL_INVENTORY_AND_COORDINATES.FOOD_ELITE=0; GLOBAL_INVENTORY_AND_COORDINATES.FOOD_MAGIC=0; GLOBAL_INVENTORY_AND_COORDINATES.FOOD_SPOILED=0;

    GLOBAL_INVENTORY_AND_COORDINATES.HUNGER=100; GLOBAL_INVENTORY_AND_COORDINATES.HP=0;

    GLOBAL_INVENTORY_AND_COORDINATES.ARROW=0; GLOBAL_INVENTORY_AND_COORDINATES.DAGGER=0; GLOBAL_INVENTORY_AND_COORDINATES.MACE=1; 

    GLOBAL_INVENTORY_AND_COORDINATES.SWORD=0; GLOBAL_INVENTORY_AND_COORDINATES.WAND=0; GLOBAL_INVENTORY_AND_COORDINATES.TIME_PLAYED=0;

    GLOBAL_EFFECTS_STORAGE.D=0; GLOBAL_EFFECTS_STORAGE.H=0; GLOBAL_EFFECTS_STORAGE.S=0; GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON='m';

    //setlocale(LC_ALL, "");  
    
    srand(time(NULL)); 

    //initscr();  
    
    noecho();   curs_set(0);    keypad(stdscr,TRUE);

    getmaxyx(stdscr,ROW,COLUMN);

    if(has_colors()==TRUE) {

        start_color();

        init_pair(1,COLOR_YELLOW,COLOR_BLACK); init_pair(2,COLOR_WHITE,COLOR_YELLOW);

        init_pair(3,COLOR_RED,COLOR_BLACK); init_pair(8,COLOR_WHITE,COLOR_RED);

        init_pair(4,COLOR_GREEN,COLOR_BLACK); init_pair(9,COLOR_WHITE,COLOR_GREEN);

        init_pair(5,COLOR_BLUE,COLOR_BLACK); init_pair(10,COLOR_WHITE,COLOR_BLUE);

        init_pair(6,COLOR_WHITE,COLOR_BLACK); init_pair(11,COLOR_BLACK,COLOR_WHITE);

        init_color(COLOR_ORANGE,690,310,0);

        init_pair(7,COLOR_ORANGE,COLOR_BLACK);

        init_pair(12,COLOR_WHITE,COLOR_BLUE);

        init_pair(13,COLOR_MAGENTA,COLOR_BLACK);

        init_pair(14,COLOR_GREEN,COLOR_BLUE);

        init_pair(15,COLOR_RED,COLOR_BLUE);

        //init_pair(14,COLOR_RED,COLOR_BLUE);

        //add colors later
    }

    OPEN_GAME_LAUNCHER(OK_LAUNCH);

}

void SHUTDOWN_GAME(Mix_Music *music) {

    cbreak();   clear();    attrset(MAGENTA_COLORED_CELL);  curs_set(0);

    char goodbye[][75]={
        " _______  _______  _______  ______   ______            _______    _ ",
        "(  ____ \\(  ___  )(  ___  )(  __  \\ (  ___ \\ |\\     /|(  ____ \\  ( )",
        "| (    \\/| (   ) || (   ) || (  \\  )| (   ) )( \\   / )| (    \\/  | |",
        "| |      | |   | || |   | || |   ) || (__/ /  \\ (_) / | (__      | |",
        "| | ____ | |   | || |   | || |   | ||  __ (    \\   /  |  __)     | |",
        "| | \\_  )| |   | || |   | || |   ) || (  \\ \\    ) (   | (        (_)",
        "| (___) || (___) || (___) || (__/  )| )___) )   | |   | (____/\\   _ ",
        "(_______)(_______)(_______)(______/ |/ \\___/    \\_/   (_______/  (_)"
    };

    char roses[][60]={
        "                            o",
        "                            M   o     oM\"\"\"\"\"\"\"\"ooo",
        "                            M   M   MM\"           M",
        "                           M\"   M   MM  o\"\"\"\"\"M   M",
        "                          M\"    M   MM  Mo    M   M",
        "                      oM\"\"      \"M  MM    \"\"  M   M",
        "                  ooM\"\"          \"M   \"\"Moooo\"    M",
        "                 M\"\"              \"Moooooo     oMM\"",
        "                 M                       \"\"\"\"\"\"\"",
        "                 M",
        "                 M                           oooooooo",
        "                 Moo                   oM\"\"\"\"\"",
        "                 oMMo               MM\"\"",
        "                oM  \"\"Mo        oooM\"\"",
        "               oM       \"\"\"\"\"\"\"\"\"",
        "              M\"",
        "            MM\"",
        "          oM\"\"",
        "         o\"",
        "     ooo\"\"",
        "    \"\""
    };

    for(int i=0 ; i<8 ; i++) {
        mvprintw(1+i,COLUMN/2 - strlen(goodbye[0])/2,"%s",goodbye[i]);
    }

    attroff(MAGENTA_COLORED_CELL);

    attron(GREEN_COLORED_CELL);

    mvprintw(4*ROW/5,COLUMN/2 -19,"Hope You Had Fun! Press a Key to Exit");

    for(int i=0 ; i<21 ; i++) {
        mvprintw(ROW/4+i,1,"%s",roses[i]);
        mvprintw(ROW/4+i,80,"%s",roses[i]);
    }

    refresh();  getch();   refresh(); clear();  
    
    //endwin();

    Mix_CloseAudio();   Mix_FreeMusic(music);   SDL_Quit();

}

void FIND_MAX_HP() {

    if(GLOBAL_SETTINGS.DIFFICULTY=='h') {
        GLOBAL_MAX_HP=50;
    }
    else if(GLOBAL_SETTINGS.DIFFICULTY=='n') {
        GLOBAL_MAX_HP=100;
    }
    else {
        GLOBAL_MAX_HP=150;
    }

    if(GLOBAL_INVENTORY_AND_COORDINATES.HP==0) {
        GLOBAL_INVENTORY_AND_COORDINATES.HP=GLOBAL_MAX_HP;
    }
    if(GLOBAL_INVENTORY_AND_COORDINATES.HP>GLOBAL_MAX_HP) {
        GLOBAL_INVENTORY_AND_COORDINATES.HP=GLOBAL_MAX_HP;
    }


}

void SAVE_GAME(POINT MAP[4][38][144],int DELTA_T_PLAYED) {

    if(GLOBAL_IS_GUEST==FALSE) {

        char FREE_SPACE[100];

        clear(); cbreak(); attron(GOLD_COLORED_CELL); echo(); curs_set(1);

        mvprintw(5,COLUMN/2 -8,"Name Your Save.");

        mvprintw(ROW/2-1,COLUMN/2 - 9,">");

        mvprintw(ROW/2, COLUMN/2 -8 , "###############");

        move(ROW/2 -1 , COLUMN/2 -8); refresh(); attroff(GOLD_COLORED_CELL);

        getstr(FREE_SPACE); curs_set(0); noecho();

        char STRING[100]="saves_";

        strcat(STRING,GLOBAL_LOGGED_IN_USER);

        strcat(STRING,".txt");

        FILE *SAVE_LOCATION=fopen(STRING,"w+");

        fprintf(SAVE_LOCATION,"%s ",GLOBAL_LOGGED_IN_USER);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.H_SPELL);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.S_SPELL);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.D_SPELL);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.MACE);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.DAGGER);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.WAND);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.ARROW);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.SWORD);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.GOLD);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.SCORE);
////////////////////////////////////////////////////////////////////////////////////////////
        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.FOOD_MAGIC);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.FOOD_ELITE);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.FOOD_SPOILED);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_EFFECTS_STORAGE.D);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_EFFECTS_STORAGE.H);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_EFFECTS_STORAGE.S);
////////////////////////////////////////////////////////////////////////////////////////////////
        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.HP);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.HUNGER);

        fprintf(SAVE_LOCATION,"%d ",DELTA_T_PLAYED);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.x);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.y);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.FLOOR);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.KEYS);

        fprintf(SAVE_LOCATION,"%d ",GLOBAL_INVENTORY_AND_COORDINATES.BROKEN_KEYS);

        for(int i=0 ; i<4 ; i++) {
            for(int j=0 ; j<38 ; j++) {
                for(int k=0 ; k<144 ; k++) {

                    fprintf(SAVE_LOCATION,"%c",MAP[i][j][k].COLOR);

                    fprintf(SAVE_LOCATION,"%c",MAP[i][j][k].IS_DISCOVERED);

                    fprintf(SAVE_LOCATION,"%c",MAP[i][j][k].IS_START);

                    fprintf(SAVE_LOCATION,"%c",MAP[i][j][k].PASSWORD_DOOR_TYPE);

                    fprintf(SAVE_LOCATION,"%c",MAP[i][j][k].REAL_CONTENTS);

                    fprintf(SAVE_LOCATION,"%c",MAP[i][j][k].SYMBOL);
                }
            }
        }

        for(int i=0 ; i<4 ; i++) {
            for(int j=0 ; j<6 ; j++) {
                fprintf(SAVE_LOCATION,"%c",GLOBAL_ALL_THEMES_COLOR[i][j]);
            }
        }
        
        for(int i=0 ; i<4 ; i++) {
            for(int j=0 ; j<6 ; j++) {
                fprintf(SAVE_LOCATION," %d %d %d %d %d %d %d %d",GLOBAL_ALL_ENEMIES[i][j].DMG,GLOBAL_ALL_ENEMIES[i][j].HP
                
                ,GLOBAL_ALL_ENEMIES[i][j].MAX_HP,GLOBAL_ALL_ENEMIES[i][j].MAX_MOVE_TILES,GLOBAL_ALL_ENEMIES[i][j].MOVES_LEFT,
                
                GLOBAL_ALL_ENEMIES[i][j].SYMBOL,GLOBAL_ALL_ENEMIES[i][j].x,GLOBAL_ALL_ENEMIES[i][j].y);
            }
        }

        for(int i=0 ; i<4 ; i++) { 
            fprintf(SAVE_LOCATION," %d %d %d %d %d %d %d %d",GLOBAL_BOSSES_IN_LAST_ROOM[i].DMG,GLOBAL_BOSSES_IN_LAST_ROOM[i].HP
                
            ,GLOBAL_BOSSES_IN_LAST_ROOM[i].MAX_HP,GLOBAL_BOSSES_IN_LAST_ROOM[i].MAX_MOVE_TILES,GLOBAL_BOSSES_IN_LAST_ROOM[i].MOVES_LEFT,
                
            GLOBAL_BOSSES_IN_LAST_ROOM[i].SYMBOL,GLOBAL_BOSSES_IN_LAST_ROOM[i].x,GLOBAL_BOSSES_IN_LAST_ROOM[i].y);
        }

        fclose(SAVE_LOCATION);

    }

    else {

        clear(); attron(RED_COLORED_CELL); cbreak();

        mvprintw(ROW/2 ,COLUMN/2 -24 ,"As a Guest, You Can't Save! Press a Key to Exit.");

        attroff(RED_COLORED_CELL); refresh(); getch();

    }
}

void PERFORM_DEATH_CHECK() {

    if(GLOBAL_INVENTORY_AND_COORDINATES.HP<=0) {

        OPEN_DEATH_MENU();

    }

}

void OPEN_DEATH_MENU() {

    GLOBAL_EXIT_CODE=4;

    clear(); attron(RED_COLORED_CELL); cbreak();

    char death[][75]={
        "          _______                 ______  _________ _______  ______",  
        "|\\     /|(  ___  )|\\     /|      (  __  \\ \\__   __/(  ____ \\(  __  \\", 
        "( \\   / )| (   ) || )   ( |      | (  \\  )   ) (   | (    \\/| (  \\  )",
        " \\ (_) / | |   | || |   | |      | |   ) |   | |   | (__    | |   ) |",
        "  \\   /  | |   | || |   | |      | |   | |   | |   |  __)   | |   | |",
        "   ) (   | |   | || |   | |      | |   ) |   | |   | (      | |   ) |",
        "   | |   | (___) || (___) |      | (__/  )___) (___| (____/\\| (__/  )",
        "   \\_/   (_______)(_______)      (______/ \\_______/(_______/(______/", 
    };

    char skull[][40]={
        "                            ,--.",
        "                           {    }",
        "                           K,   }",
        "                          /  ~Y`",
        "                     ,   /   /",
        "                    {_'-K.__/",
        "                      `/-.__L._",
        "                      /  ' /`\\_}",
        "                     /  ' /",
        "             ____   /  ' /",
        "      ,-'~~~~    ~~/  ' /_",
        "    ,'             ``~~~  ',",
        "   (                        Y",
        "  {                         I",
        " {      -                    `,",
        " |       ',                   )",
        " |        |   ,..__      __. Y",
        " |    .,_./  Y ' / ^Y   J   )|",
        " \\           |' /   |   |   ||",
        "  \\          L_/    . _ (_,.'(",
        "   \\,   ,      ^^""' / |      )",
        "     \\_  \\          /,L]     /",
        "       '-_~-,       ` `   ./`",
        "          `'{_            )",
        "              ^^\\..___,.--`"
    };

    for(int i=0 ; i<8 ; i++) {
        mvprintw(1+i,COLUMN/2 - strlen(death[0])/2 , "%s",death[i]);
    }

    for(int i=0 ; i<25 ; i++) {
        mvprintw(5+i,1,"%s",skull[i]);
        mvprintw(5+i,3*COLUMN/4,"%s",skull[i]);
    }

    //mvprintw(ROW/2, COLUMN/2 -17 ,"You Died! Press a Key to Continue.");

    mvprintw(ROW/2 +1,COLUMN/2 -8,"Your Score : %d",GLOBAL_INVENTORY_AND_COORDINATES.SCORE);

    //wipe out last save if not guest.

    if(GLOBAL_IS_GUEST==FALSE) {

        char STRING[100]="saves_";

        strcat(STRING,GLOBAL_LOGGED_IN_USER);

        strcat(STRING,".txt");

        FILE *SAVE_LOCATION=fopen(STRING,"w+");

        fclose(SAVE_LOCATION);
    }

    refresh();  attroff(RED_COLORED_CELL); getch();

}

void REDUCE_HUNGER() {

    unsigned long long int NEW_QUERRY=time(NULL);

    if(GLOBAL_INVENTORY_AND_COORDINATES.HUNGER==0) {

        if(NEW_QUERRY-GLOBAL_LAST_HUNGER_TIME_QUERRY>=10) {

            GLOBAL_INVENTORY_AND_COORDINATES.HP--; attron(RED_COLORED_CELL);

            PRINT_MESSAGE("You Are Starving!"); attroff(RED_COLORED_CELL); refresh();

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Are Starving!");

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

            GLOBAL_LAST_HUNGER_TIME_QUERRY=NEW_QUERRY;

        }

    }

    else {

        if(NEW_QUERRY-GLOBAL_LAST_HUNGER_TIME_QUERRY>=5) {

            GLOBAL_INVENTORY_AND_COORDINATES.HUNGER--;

            GLOBAL_LAST_HUNGER_TIME_QUERRY=NEW_QUERRY;

        }

    }

}

void OPEN_FOOD_MENU() {

    cbreak(); 

    char cake[][35]={
        "                   .",
        "                  / `.",
        "                .'... `-.",
        "              .'.. .   ..\\",
        "             /. . . .   ..`.",
        "            /...  ... .    .\\",
        "           /.. . ........   .\\",
        "         .'.   ...   ......  .|",
        "       .' ... . ..... . ..--'.|",
        "     .' ...  ...   ._.--'    .|",
        "   .'... . ...  _.-'O   OO O .|",
        "  /... .___.---'O OO .O. OO O.|",
        " /__.--' OO O  .OO O  OO O ...|",
        " | OO OO O OO . .O. OO O  ..O.|",
        " (O. OO. .O O O O  OO  ..OO O.|",
        " ( OO .O. O  O  OO............|",
        " (OOO........O_______.-------'",
        " |_____.-----'"
    };

    attrset(BLUE_COLORED_CELL);

    for(int i=0 ; i<18 ; i++) {
        mvprintw(ROW/3+i,4,"%s",cake[i]);
        mvprintw(ROW/3+i,2*COLUMN/3,"%s",cake[i]);
    }

    attroff(BLUE_COLORED_CELL);

    while(TRUE) {

        clear(); attron(GOLD_COLORED_CELL);

        attrset(BLUE_COLORED_CELL);

        for(int i=0 ; i<18 ; i++) {
            mvprintw(ROW/3+i,4,"%s",cake[i]);
            mvprintw(ROW/3+i,2*COLUMN/3,"%s",cake[i]);
        }

        attrset(GOLD_COLORED_CELL);

        move(0,60);

        printw("Saturation Bar : |");

        attrset(GREEN_COLORED_CELL);

        for(int i=1 ; i<=GLOBAL_INVENTORY_AND_COORDINATES.HUNGER/10 ; i++) {
            printw("#");
        }

        attrset(GOLD_COLORED_CELL);

        mvprintw(0,88,"| ");

        move(2,60); printw("Health Bar : |"); 

        attrset(GREEN_COLORED_CELL);

        for(int i=1 ; i<=10 *GLOBAL_INVENTORY_AND_COORDINATES.HP/GLOBAL_MAX_HP ; i++) {
            printw("#");
        }

        attrset(GOLD_COLORED_CELL);

        mvprintw(2,84,"| ");

        attrset(BLUE_COLORED_CELL);

        mvprintw(4,COLUMN/2 -30 ,"Select a Food Item to Use(r, m, e). Press Backspace to Exit."); attroff(GOLD_COLORED_CELL);

        attrset(RED_COLORED_CELL);   
        
        mvprintw(ROW/4,COLUMN/2 - 10,"Regular Rations :%d",GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR+GLOBAL_INVENTORY_AND_COORDINATES.FOOD_SPOILED);
        attrset(MAGENTA_COLORED_CELL);
        mvprintw(ROW/2, COLUMN/2 - 10,"Magical Rations :%d",GLOBAL_INVENTORY_AND_COORDINATES.FOOD_MAGIC);
        attrset(GOLD_COLORED_CELL);
        mvprintw(3*ROW/4 , COLUMN/2 -9,"Elite Rations :%d",GLOBAL_INVENTORY_AND_COORDINATES.FOOD_ELITE); 
        
        attroff(GOLD_COLORED_CELL);

        int INPUT=getch();

        if(INPUT==KEY_BACKSPACE) {

            break;
        }

        if(INPUT=='e' || INPUT=='E') {

            if(GLOBAL_INVENTORY_AND_COORDINATES.FOOD_ELITE>0) {

                GLOBAL_INVENTORY_AND_COORDINATES.FOOD_ELITE--;

                GLOBAL_INVENTORY_AND_COORDINATES.HP+=40;

                if(GLOBAL_INVENTORY_AND_COORDINATES.HP>GLOBAL_MAX_HP) {

                    GLOBAL_INVENTORY_AND_COORDINATES.HP=GLOBAL_MAX_HP;

                }

                GLOBAL_INVENTORY_AND_COORDINATES.HUNGER+=50;

                if(GLOBAL_INVENTORY_AND_COORDINATES.HUNGER>100) {

                    GLOBAL_INVENTORY_AND_COORDINATES.HUNGER=100;

                }

                GLOBAL_EFFECTS_STORAGE.D=10;

            }

            else {

                clear(); attron(RED_COLORED_CELL); mvprintw(ROW/2,COLUMN/2 -23,"You Have Nothing to Eat! Press a Key to Exit.");

                attroff(RED_COLORED_CELL); getch();

            }
        }

        else if(INPUT=='r' || INPUT=='R') {
            
            if(GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR+GLOBAL_INVENTORY_AND_COORDINATES.FOOD_SPOILED>0) {

                if(GLOBAL_INVENTORY_AND_COORDINATES.FOOD_SPOILED==0) {
                    GLOBAL_INVENTORY_AND_COORDINATES.HP+=20;
                    GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR--;

                    if(GLOBAL_INVENTORY_AND_COORDINATES.HP>GLOBAL_MAX_HP) {

                        GLOBAL_INVENTORY_AND_COORDINATES.HP=GLOBAL_MAX_HP;

                    }

                    GLOBAL_INVENTORY_AND_COORDINATES.HUNGER+=25;

                    if(GLOBAL_INVENTORY_AND_COORDINATES.HUNGER>100) {

                        GLOBAL_INVENTORY_AND_COORDINATES.HUNGER=100;

                    }
                }
                else if(GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR==0) {
                    
                    GLOBAL_INVENTORY_AND_COORDINATES.HP-=10;

                    GLOBAL_INVENTORY_AND_COORDINATES.FOOD_SPOILED--;

                }
                else {

                    int TOTAL_FOOD=GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR+GLOBAL_INVENTORY_AND_COORDINATES.FOOD_SPOILED;
                    int RANDOM=rand()%TOTAL_FOOD+1;
                    if(RANDOM<=GLOBAL_INVENTORY_AND_COORDINATES.FOOD_SPOILED) {
                        GLOBAL_INVENTORY_AND_COORDINATES.HP-=10;

                        GLOBAL_INVENTORY_AND_COORDINATES.FOOD_SPOILED--;
                    }
                    else {
                        GLOBAL_INVENTORY_AND_COORDINATES.HP+=20;
                        GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR--;

                        if(GLOBAL_INVENTORY_AND_COORDINATES.HP>GLOBAL_MAX_HP) {

                            GLOBAL_INVENTORY_AND_COORDINATES.HP=GLOBAL_MAX_HP;

                        }

                        GLOBAL_INVENTORY_AND_COORDINATES.HUNGER+=25;

                        if(GLOBAL_INVENTORY_AND_COORDINATES.HUNGER>100) {

                            GLOBAL_INVENTORY_AND_COORDINATES.HUNGER=100;

                        }

                    }

                }
            
            }

            else {

                clear(); attron(RED_COLORED_CELL); mvprintw(ROW/2,COLUMN/2 -23,"You Have Nothing to Eat! Press a Key to Exit.");

                attroff(RED_COLORED_CELL); getch();

            }
        }
        else if(INPUT=='m' || INPUT=='M') {

            if(GLOBAL_INVENTORY_AND_COORDINATES.FOOD_MAGIC>0) {

                GLOBAL_INVENTORY_AND_COORDINATES.FOOD_MAGIC--;

                GLOBAL_INVENTORY_AND_COORDINATES.HP+=40;

                if(GLOBAL_INVENTORY_AND_COORDINATES.HP>GLOBAL_MAX_HP) {

                    GLOBAL_INVENTORY_AND_COORDINATES.HP=GLOBAL_MAX_HP;

                }

                GLOBAL_INVENTORY_AND_COORDINATES.HUNGER+=50;

                if(GLOBAL_INVENTORY_AND_COORDINATES.HUNGER>100) {

                    GLOBAL_INVENTORY_AND_COORDINATES.HUNGER=100;

                }

                GLOBAL_EFFECTS_STORAGE.S=10;

            }

            else {

                clear(); attron(RED_COLORED_CELL); mvprintw(ROW/2,COLUMN/2 -23,"You Have Nothing to Eat! Press a Key to Exit.");

                attroff(RED_COLORED_CELL); getch();

            }


        }
    }

    halfdelay(20); 

}

void HANDLE_TRAP_ACTIVATION() {

    GLOBAL_INVENTORY_AND_COORDINATES.HP-=5;

}

void PRINT_WEAPONS_MENU() {
    
    char STRING[20];

    char weapons[][70]={
        "          _______  _______  _______  _______  _        _______", 
        "|\\     /|(  ____ \\(  ___  )(  ____ )(  ___  )( (    /|(  ____ \\",
        "| )   ( || (    \\/| (   ) || (    )|| (   ) ||  \\  ( || (    \\/",
        "| | _ | || (__    | (___) || (____)|| |   | ||   \\ | || (_____ ",
        "| |( )| ||  __)   |  ___  ||  _____)| |   | || (\\ \\) |(_____  )",
        "| || || || (      | (   ) || (      | |   | || | \\   |      ) |",
        "| () () || (____/\\| )   ( || )      | (___) || )  \\  |/\\____) |",
        "(_______)(_______/|/     \\||/       (_______)|/    )_)\\_______)"
    };

    char swords[][80]={
        "           /\\                                                 /\\",
        " _         )( ______________________   ______________________ )(         _",
        "(_)///////(**)______________________> <______________________(**)\\\\\\\\\\\\\\(_)",
        "           )(                                                 )(",
        "           \\/                                                 \\/"
    };

    char shield_axe[][35]={
        "   |\\                     /)",
        " /\\_\\\\__               (_//",
        "|   `>\\-`     _._       //`)",
        " \\ /` \\\\  _.-`:::`-._  //",
        "  `    \\|`    :::    `|/",
        "        |     :::     |",
        "        |.....:::.....|",
        "        |:::::::::::::|",
        "        |     :::     |",
        "        \\     :::     /",
        "         \\    :::    /",
        "          `-. ::: .-'",
        "           //`:::`\\\\",
        "          //   '   \\\\",
        "         |/         \\\\"
    };

    switch(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON) {
        case 'm' : 
            strcpy(STRING,"Mace");
            break;
        case 'w' :
            strcpy(STRING,"Magic Wand");
            break;
        case 'a' : 
            strcpy(STRING,"Arrows");
            break;
        case 's' : 
            strcpy(STRING,"Sword");
            break;
        case 'd' :
            strcpy(STRING,"Daggers");
            break;
        case 0 : 
            strcpy(STRING,"Unequipped");
            break;
    }

    attrset(RED_COLORED_CELL);

    mvprintw(0,COLUMN/2 -20,"Weapons Inventory | Current Weapon is : %s",STRING);
    mvprintw(1,COLUMN/2 -48, "Press w to Unequip Your Current Weapon. Press The Appropriate Key to Equip a Weapon Afterwards.");

    attrset(MAGENTA_COLORED_CELL);
    mvprintw(ROW/3+3 ,  40,"Key   Melee   Amount  DMG     Key  Ranged   Amonut   DMG  Range");
    mvprintw(ROW/3+5 ,40," m    Mace       1     5       d   Dagger     %d     12     5",GLOBAL_INVENTORY_AND_COORDINATES.DAGGER);
    mvprintw(ROW/3+7, 40," s    Sword      %d     10      g   Wand      %d     15     10",GLOBAL_INVENTORY_AND_COORDINATES.SWORD,GLOBAL_INVENTORY_AND_COORDINATES.WAND);
    mvprintw(ROW/3+9, 40,"                               a   Arrow      %d     5      5",GLOBAL_INVENTORY_AND_COORDINATES.ARROW);
    attrset(GREEN_COLORED_CELL);
    for(int i = 0 ; i<8 ; i++ ) {
        mvprintw(4+i,COLUMN/2 - strlen(weapons[0])/2,"%s",weapons[i]);
    }
    attroff(GREEN_COLORED_CELL);

    attron(RED_COLORED_CELL);

    for(int i=0 ; i<5 ; i++) {
        mvprintw(2*ROW/3 +i,COLUMN/2- strlen(swords[2])/2,"%s",swords[i]);
    }

    for(int i=0 ; i<15 ; i++) {
        mvprintw(ROW/3+i,1,"%s",shield_axe[i]);
        mvprintw(ROW/3+i,3*COLUMN/4,"%s",shield_axe[i]);
    }


    attroff(RED_COLORED_CELL);
}

void OPEN_WEAPONS_MENU() {

    cbreak(); attron(GOLD_COLORED_CELL);

    int INPUT; int BREAK=0;
    
    while(TRUE) {

        clear();

        PRINT_WEAPONS_MENU();

        INPUT=getch();

        switch(INPUT) {

            case 'w' :
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON!=0) {
                    GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=0;
                }

                break;
            case 'm' :
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON==0) {
                    mvprintw(2,COLUMN/2 -23,"Equipped Weapon Changed. Press a Key to Exit.");
                    GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON='m';
                    getch();
                    BREAK++;
                }
                else {
                    attrset(RED_COLORED_CELL);
                    mvprintw(2,COLUMN/2 -37,"a Weapon is Already Equipped. Unequip that first. Press a Key to Continue.");
                    attrset(GOLD_COLORED_CELL);
                    getch();
                }
                break;
            case 's' :
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON==0 && GLOBAL_INVENTORY_AND_COORDINATES.SWORD>0) {
                    mvprintw(2,COLUMN/2 -23,"Equipped Weapon Changed. Press a Key to Exit.");
                    GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON='s';
                    getch();
                    BREAK++;
                }
                else if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON!=0){
                    attrset(RED_COLORED_CELL);
                    mvprintw(2,COLUMN/2 -37,"a Weapon is Already Equipped. Unequip that first. Press a Key to Continue.");
                    attrset(GOLD_COLORED_CELL);
                    getch();
                }
                else {
                    attrset(RED_COLORED_CELL);
                    mvprintw(2,COLUMN/2 -30, "You Don't Have Any Of This Weapon! Press a Key to Continue.");
                    attrset(GOLD_COLORED_CELL);
                    getch();
                }
                break;
            case 'd' :
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON==0 && GLOBAL_INVENTORY_AND_COORDINATES.DAGGER>0) {
                    mvprintw(2,COLUMN/2 -23,"Equipped Weapon Changed. Press a Key to Exit.");
                    GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON='d';
                    getch();
                    BREAK++;
                }
                else if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON!=0){
                    attrset(RED_COLORED_CELL);
                    mvprintw(2,COLUMN/2 -37,"a Weapon is Already Equipped. Unequip that first. Press a Key to Continue.");
                    attrset(GOLD_COLORED_CELL);
                    getch();
                }
                else {
                    attrset(RED_COLORED_CELL);
                    mvprintw(2,COLUMN/2 -30, "You Don't Have Any Of This Weapon! Press a Key to Continue.");
                    attrset(GOLD_COLORED_CELL);
                    getch();
                }
                break;
            case 'a' :
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON==0 && GLOBAL_INVENTORY_AND_COORDINATES.ARROW>0) {
                    mvprintw(2,COLUMN/2 -23,"Equipped Weapon Changed. Press a Key to Exit.");
                    GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON='a';
                    getch();
                    BREAK++;
                }
                else if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON!=0){
                    attrset(RED_COLORED_CELL);
                    mvprintw(2,COLUMN/2 -37,"a Weapon is Already Equipped. Unequip that first. Press a Key to Continue.");
                    attrset(GOLD_COLORED_CELL);
                    getch();
                }
                else {
                    attrset(RED_COLORED_CELL);
                    mvprintw(2,COLUMN/2 -30, "You Don't Have Any Of This Weapon! Press a Key to Continue.");
                    attrset(GOLD_COLORED_CELL);
                    getch();
                }
                break;
            case 'g' :
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON==0 && GLOBAL_INVENTORY_AND_COORDINATES.WAND>0) {
                    mvprintw(2,COLUMN/2 -23,"Equipped Weapon Changed. Press a Key to Exit.");
                    GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON='w';
                    getch();
                    BREAK++;
                }
                else if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON!=0){
                    attrset(RED_COLORED_CELL);
                    mvprintw(2,COLUMN/2 -37,"a Weapon is Already Equipped. Unequip that first. Press a Key to Continue.");
                    attrset(GOLD_COLORED_CELL);
                    getch();
                }
                else {
                    attrset(RED_COLORED_CELL);
                    mvprintw(2,COLUMN/2 -30, "You Don't Have Any Of This Weapon! Press a Key to Continue.");
                    attrset(GOLD_COLORED_CELL);
                    getch();
                }
                break;
            case KEY_BACKSPACE :
                BREAK++;
                break;
            default :
                attrset(RED_COLORED_CELL);
                mvprintw(2,COLUMN/2 -23,"Invalid Key Pressed. Press a Key to Continue.");
                attrset(GOLD_COLORED_CELL);
                getch();
                break;
        }

        if(BREAK){
            break;
        }

    }

    attroff(GOLD_COLORED_CELL); refresh(); 

    halfdelay(20);

}

void OPEN_SPELLS_MENU() {

    clear(); cbreak(); attrset(GOLD_COLORED_CELL);

    char bottles[][65]={
        "       ___",
        "       )_(                                            _",
        "       | |                                           [_ ]",
        "     .-'-'-.       _                               .-'. '-.",
        "    /-::_..-\\    _[_]_                            /:;/ _.-'\\",
        "    )_     _(   /_   _\\      [-]                  |:._   .-|",
        "    |;::    |   )_``'_(    .-'-'-.       (-)      |:._     |",
        "    |;::    |   |;:   |    :-...-:     .-'-'-.    |:._     |",
        "    |;::    |   |;:   |    |;:   |     |-...-|    |:._     |",
        "    |;::-.._|   |;:.._|    |;:.._|     |;:.._|    |:._     |",
        "    `-.._..-'   `-...-'    `-...-'     `-...-'    `-.____.-'"
    };

    char spells[][60]={
        " _______  _______  _______  _        _        _______", 
        "(  ____ \\(  ____ )(  ____ \\( \\      ( \\      (  ____ \\",
        "| (    \\/| (    )|| (    \\/| (      | (      | (    \\/",
        "| (_____ | (____)|| (__    | |      | |      | (_____ ",
        "(_____  )|  _____)|  __)   | |      | |      (_____  )",
        "      ) || (      | (      | |      | |            ) |",
        "/\\____) || )      | (____/\\| (____/\\| (____/\\/\\____) |",
        "\\_______)|/       (_______/(_______/(_______/\\_______)"
    };

    mvprintw(0,COLUMN/2 - 31,"Press a Key to Use a Spell: H, S, D. Press Backspace to Exit.");

    attrset(BLUE_COLORED_CELL);

    mvprintw(ROW/2,0,"Speed Spells : %d",GLOBAL_INVENTORY_AND_COORDINATES.S_SPELL);

    attrset(RED_COLORED_CELL);

    mvprintw(ROW/2+2,0,"Damage Spells : %d",GLOBAL_INVENTORY_AND_COORDINATES.D_SPELL);

    attrset(GREEN_COLORED_CELL);

    mvprintw(ROW/2+4,0,"Health Spells : %d",GLOBAL_INVENTORY_AND_COORDINATES.H_SPELL);

    attrset(MAGENTA_COLORED_CELL);

    int INPUT;

    do
    {
        clear();

        attrset(MAGENTA_COLORED_CELL);

        mvprintw(0,COLUMN/2 - 31,"Press a Key to Use a Spell: H, S, D. Press Backspace to Exit.");

        for(int i=0 ; i<8 ; i++) {
            mvprintw(2+i,COLUMN/2 - strlen(spells[0])/2,"%s",spells[i]);
        }

        attrset(BLUE_COLORED_CELL);

        mvprintw(ROW/2,0,"Speed Spells : %d",GLOBAL_INVENTORY_AND_COORDINATES.S_SPELL);

        attrset(RED_COLORED_CELL);

        mvprintw(ROW/2+2,0,"Damage Spells : %d",GLOBAL_INVENTORY_AND_COORDINATES.D_SPELL);

        attrset(GREEN_COLORED_CELL);

        mvprintw(ROW/2+4,0,"Health Spells : %d",GLOBAL_INVENTORY_AND_COORDINATES.H_SPELL);

        attrset(MAGENTA_COLORED_CELL);

        for(int i=0 ; i<11 ; i++) {
            mvprintw(ROW/2+i,COLUMN/2 - strlen(bottles[5])/2,"%s",bottles[i]);
        }

        refresh(); INPUT=getch();

        if(INPUT=='h' || INPUT=='H') {

            if(GLOBAL_INVENTORY_AND_COORDINATES.H_SPELL>0) {
                GLOBAL_INVENTORY_AND_COORDINATES.H_SPELL--;
                mvprintw(1,COLUMN/2 -24, "Spell Used Successfully, Press a Key to Confirm.");
                GLOBAL_EFFECTS_STORAGE.H=10;
                getch();
            }
            else {

                mvprintw(1,COLUMN/2 -25,"You Don't Have Any to Use! Press a Key to Confirm.");
                getch();

            }

        }
        if(INPUT=='s' || INPUT=='S') {

            if(GLOBAL_INVENTORY_AND_COORDINATES.S_SPELL>0) {
                GLOBAL_INVENTORY_AND_COORDINATES.S_SPELL--;
                mvprintw(1,COLUMN/2 -24, "Spell Used Successfully. Press a Key to Confirm.");
                GLOBAL_EFFECTS_STORAGE.S=10;
                getch();
            }
            else {
                mvprintw(1,COLUMN/2 -25,"You Don't Have Any to Use! Press a Key to Confirm.");
                getch();
            }

        }
        if(INPUT=='d' || INPUT=='D') {

            if(GLOBAL_INVENTORY_AND_COORDINATES.D_SPELL>0) {
                GLOBAL_INVENTORY_AND_COORDINATES.D_SPELL--;
                mvprintw(1,COLUMN/2 -24, "Spell Used Successfully. Press a Key to Confirm.");
                GLOBAL_EFFECTS_STORAGE.D=10;
                getch();
            }
            else {
                mvprintw(1,COLUMN/2 -25,"You Don't Have Any to Use! Press a Key to Confirm.");
                getch();
            }
        }


    } while (INPUT!=KEY_BACKSPACE);
    

    attroff(GOLD_COLORED_CELL); refresh();

    halfdelay(20);

}

void OPEN_VICTORY_MENU() {

    cbreak(); clear(); attron(GOLD_COLORED_CELL);

    GLOBAL_EXIT_CODE=2;

    char statue[][40]={
        "              {}",
        "             {{}}",
        "             {{}}",
        "              {}",
        "            .-''-.",
        "           /  __  \\",
        "          /.-'  '-.\\",
        "          \\::.  .::/",
        "           \\'    '/",
        "      __ ___)    (___ __",
        "    .'   \\\\        //   `.",
        "   /     | '-.__.-' |     \\",
        "   |     |  '::::'  |     |",
        "   |    /    '::'    \\    |",
        "   |_.-;\\     __     /;-._|",
        "   \\.'^`\\\\    \\/    //`^'./",
        "   /   _.-._ _||_ _.-._   \\",
        "  `\\___\\    '-..-'    /___/`",
        "       /'---.  `\\.---'\\",
        "      ||    |`\\\\\\|    ||",
        "      ||    | || |    ||",
        "      |;.__.' || '.__.;|",
        "      |       ||       |",
        "      {{{{{{{{||}}}}}}}}",
        "       |      ||      |",
        "       |.-==-.||.-==-.|",
        "       <.    .||.    .>",
        "        \\'=='/||\\'=='/",
        "        |   / || \\   |",
        "        |   | || |   |",
        "        |   | || |   |",
        "        /^^\\| || |/^^\\",
        "       /   .' || '.   \\",
        "      /   /   ||   \\   \\",
        "     (__.'    \\/    '.__)"
    };

    for(int i=0 ; i<35 ; i++) {
        mvprintw(i,1,"%s",statue[i]);
        mvprintw(i,3*COLUMN/4,"%s",statue[i]);
    }

    mvprintw(ROW/2 , COLUMN/2-19,"Congratulations! You Reached The Exit!");

    mvprintw(ROW/2+1 , COLUMN/2 -20 ,"Your Score :%d | Gold Collected :%d",GLOBAL_INVENTORY_AND_COORDINATES.SCORE
    
    ,GLOBAL_INVENTORY_AND_COORDINATES.GOLD);

    mvprintw(ROW/2+2,COLUMN/2 -20 ,"Press a Key To Save Your Score and Exit.");

    mvprintw(ROW/2 +3 , COLUMN/2 -23, "A Bonus Score of 5000 Has Been Awarded to You!");
    
    attroff(GOLD_COLORED_CELL); refresh(); getch();

}

void SAVE_ONTO_SCOREBOARD(int DELTA_T_PLAYED) {

    FILE *SCORES=fopen("user_scores.txt","r+");

    char DATA[10000];

    fgets(DATA,9999,SCORES);

    rewind(SCORES);

    int PREVIOUS_SCORE; int PREVIOUS_GOLD; int PREVIOUS_NUMBER_OF_GAMES; int PREVIOUS_TIME_PLAYED;

    char TEMP[20];

    do {

        strcpy(TEMP,"\0");

        fscanf(SCORES," %s",TEMP);

    }   while(strcmp(TEMP,GLOBAL_LOGGED_IN_USER)!=0);

    //make file pointer reach desired numbers.

    fscanf(SCORES,"%d %d %d %d",&PREVIOUS_SCORE,&PREVIOUS_GOLD,&PREVIOUS_NUMBER_OF_GAMES
    
    ,&PREVIOUS_TIME_PLAYED);

    fclose(SCORES);

    PREVIOUS_SCORE+=GLOBAL_INVENTORY_AND_COORDINATES.SCORE;

    PREVIOUS_GOLD+=GLOBAL_INVENTORY_AND_COORDINATES.GOLD;

    PREVIOUS_NUMBER_OF_GAMES++;

    PREVIOUS_TIME_PLAYED+=DELTA_T_PLAYED;

    FILE* WRITE_TO_SCORES=fopen("user_scores.txt","w+");

    char *FIND_USER=strstr(DATA,GLOBAL_LOGGED_IN_USER);

    FIND_USER[0]='\0'; //terminate data string at selected user.

    FIND_USER+=strlen(GLOBAL_LOGGED_IN_USER)+1; //points to first digit.

    while(FIND_USER[0]==' ' || (FIND_USER[0]>='0' && FIND_USER[0]<='9')) {

        FIND_USER++;

    }//now pointer arrives at the next username or null character.

    fprintf(WRITE_TO_SCORES,"%s",DATA); fprintf(WRITE_TO_SCORES,"%s %d %d %d %d ",GLOBAL_LOGGED_IN_USER,PREVIOUS_SCORE,
    
    
    PREVIOUS_GOLD,PREVIOUS_NUMBER_OF_GAMES,PREVIOUS_TIME_PLAYED); fprintf(WRITE_TO_SCORES,"%s",FIND_USER);


    fclose(WRITE_TO_SCORES);

}

void SPAWN_FOOD(int MAX_NUMBER, int CHANCE,int SECTOR ,POINT FLOOR[38][144]) {

    int RANDOM;

    for(int i=((SECTOR-1)/3)*19 ; i<19+((SECTOR-1)/3)*19 ; i++) {

        for(int j=((SECTOR-1)%3)*48 ; j<48+((SECTOR-1)%3)*48 ; j++) {

            if(FLOOR[i][j].SYMBOL=='.' && MAX_NUMBER>0 && FLOOR[i][j].REAL_CONTENTS!='^') {

                RANDOM=rand()%100+1;

                if(RANDOM<=CHANCE) {

                    RANDOM=rand()%3; //determine food type. gold/ regular / magical.
                    
                    if(RANDOM==0) {//regular
                        FLOOR[i][j].COLOR='r';
                    }
                    else if(RANDOM==1) {//gold
                        FLOOR[i][j].COLOR='y';
                    }
                    else {
                        FLOOR[i][j].COLOR='b';
                    }

                    FLOOR[i][j].REAL_CONTENTS='~';

                    FLOOR[i][j].SYMBOL='~';

                    MAX_NUMBER--;

                }

            }

        }
    }

}

void SPAWN_GOLD(int MAX_NUMBER, int CHANCE,int SECTOR ,POINT FLOOR[38][144]) {

    int RANDOM;

    for(int i=((SECTOR-1)/3)*19 ; i<19+((SECTOR-1)/3)*19 ; i++) {

        for(int j=((SECTOR-1)%3)*48 ; j<48+((SECTOR-1)%3)*48 ; j++) {

            if(FLOOR[i][j].SYMBOL=='.' && MAX_NUMBER>0 && FLOOR[i][j].REAL_CONTENTS!='^') {

                RANDOM=rand()%100+1;

                if(RANDOM<=CHANCE) {

                    FLOOR[i][j].COLOR='y';

                    FLOOR[i][j].SYMBOL='$';

                    FLOOR[i][j].REAL_CONTENTS='$';

                    MAX_NUMBER--;

                }

            }

        }
    }

}

void SPAWN_BLACK_GOLD(int MAX_NUMBER, int CHANCE,int SECTOR ,POINT FLOOR[38][144]) {

    int RANDOM;

    for(int i=((SECTOR-1)/3)*19 ; i<19+((SECTOR-1)/3)*19 ; i++) {

        for(int j=((SECTOR-1)%3)*48 ; j<48+((SECTOR-1)%3)*48 ; j++) {

            if(FLOOR[i][j].SYMBOL=='.' && MAX_NUMBER>0 && FLOOR[i][j].REAL_CONTENTS!='^') {

                RANDOM=rand()%100+1;

                if(RANDOM<=CHANCE) {

                    FLOOR[i][j].COLOR='o';

                    FLOOR[i][j].REAL_CONTENTS='*';

                    FLOOR[i][j].SYMBOL='*';

                    MAX_NUMBER--;

                }

            }

        }
    }

}

void SPAWN_TRAPS(int MAX_NUMBER, int CHANCE,int SECTOR ,POINT FLOOR[38][144]) {

    int RANDOM;

    for(int i=((SECTOR-1)/3)*19 ; i<19+((SECTOR-1)/3)*19 ; i++) {

        for(int j=((SECTOR-1)%3)*48 ; j<48+((SECTOR-1)%3)*48 ; j++) {

            if(FLOOR[i][j].SYMBOL=='.' && MAX_NUMBER>0) {

                RANDOM=rand()%100+1;

                if(RANDOM<=CHANCE) {

                    FLOOR[i][j].REAL_CONTENTS='^';

                    MAX_NUMBER--;

                }

            }

        }
    }

}

void SPAWN_WEAPONS(int MAX_NUMBER, int CHANCE,int SECTOR ,POINT FLOOR[38][144]) {

    int RANDOM;

    for(int i=((SECTOR-1)/3)*19 ; i<19+((SECTOR-1)/3)*19 ; i++) {

        for(int j=((SECTOR-1)%3)*48 ; j<48+((SECTOR-1)%3)*48 ; j++) {

            if(FLOOR[i][j].SYMBOL=='.' && MAX_NUMBER>0 && FLOOR[i][j].REAL_CONTENTS!='^') {

                RANDOM=rand()%100+1;

                if(RANDOM<=CHANCE) {

                    RANDOM=rand()%4+1;

                    switch(RANDOM) {

                        /*case 0 :

                            FLOOR[i][j].SYMBOL='M';

                            FLOOR[i][j].REAL_CONTENTS='M';

                            break;*/
                        case 1 :

                            FLOOR[i][j].REAL_CONTENTS='A';

                            FLOOR[i][j].SYMBOL='A';

                            break; 
                        case 2 :

                            FLOOR[i][j].REAL_CONTENTS=-2;

                            FLOOR[i][j].SYMBOL=-2; //wand

                            break;
                        case 3 :

                            FLOOR[i][j].REAL_CONTENTS=-3;

                            FLOOR[i][j].SYMBOL=-3; //sword

                            break;
                        case 4 :

                            FLOOR[i][j].REAL_CONTENTS=-4;

                            FLOOR[i][j].SYMBOL=-4; //dagger

                            break;
                    }

                    MAX_NUMBER--;

                }

            }

        }
    }

}

void SPAWN_SPELLS(int MAX_NUMBER, int CHANCE,int SECTOR ,POINT FLOOR[38][144]) {

    int RANDOM;

    for(int i=((SECTOR-1)/3)*19 ; i<19+((SECTOR-1)/3)*19 ; i++) {

        for(int j=((SECTOR-1)%3)*48 ; j<48+((SECTOR-1)%3)*48 ; j++) {

            if(FLOOR[i][j].SYMBOL=='.' && MAX_NUMBER>0 && FLOOR[i][j].REAL_CONTENTS!='^') {

                RANDOM=rand()%100+1;

                if(RANDOM<=CHANCE) {

                    FLOOR[i][j].COLOR='b';

                    RANDOM=rand()%3;

                    switch(RANDOM) {

                        case 0 :

                            FLOOR[i][j].REAL_CONTENTS='s';

                            FLOOR[i][j].SYMBOL='s'; //speed

                            break;
                        case 1 :

                            FLOOR[i][j].REAL_CONTENTS='h';

                            FLOOR[i][j].SYMBOL='h';//health

                            break; 
                        case 2 :

                            FLOOR[i][j].REAL_CONTENTS='d';

                            FLOOR[i][j].SYMBOL='d'; //damage

                            break;
                    }

                    MAX_NUMBER--;

                }

            }

        }
    }

}

void PERFORM_ENCHANT_THEME_EFFECT_CHECK(POINT MAP[4][38][144]) {

    unsigned long long int TIME_NOW=time(NULL);

    if(GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1]=='b'
    
    && MAP[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='#'
    ) {

        if (TIME_NOW-GLOBAL_LAST_ENCHANT_QUERRY>=10) {

            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='b';

            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"Cough! Cough! I Can't Breathe in Here!");

            PRINT_MESSAGE("Cough! Cough! I Can't Breathe in Here!");

            GLOBAL_INVENTORY_AND_COORDINATES.HP-=5;

            GLOBAL_LAST_ENCHANT_QUERRY=time(NULL);

        }

    }

    else {

        GLOBAL_LAST_ENCHANT_QUERRY=TIME_NOW;

    }

}

void HANDLE_THEME_CHANGE_MUSIC_CHANGE(POINT MAP[4][38][144], Mix_Music * music, Mix_Music * THEME_MUSIC) {

    if(GLOBAL_SETTINGS.PLAY_MUSIC=='t') {

        if(GLOBAL_LAST_THEME_IN!=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1])

        {// theme change initiated.

            switch(GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1]) {

                case 'w' : {// back to regular music

                    Mix_HaltMusic();

                    Mix_FreeMusic(THEME_MUSIC);

                    Mix_PlayMusic(music,100); 

                    break;
                }

                case 'y' : {//celebrate

                    Mix_HaltMusic();

                    Mix_FreeMusic(THEME_MUSIC);

                    THEME_MUSIC=Mix_LoadMUS("Celebrate.mp3");

                    Mix_PlayMusic(THEME_MUSIC,100);

                    break;
                }

                case 'b' : {//running in the 90s

                    Mix_HaltMusic();

                    Mix_FreeMusic(THEME_MUSIC);

                    THEME_MUSIC=Mix_LoadMUS("Running_in_the_90s.mp3");

                    Mix_PlayMusic(THEME_MUSIC,100);

                    break;
                }

                case 'r' : {//physical

                    Mix_HaltMusic();

                    Mix_FreeMusic(THEME_MUSIC);

                    THEME_MUSIC=Mix_LoadMUS("Dua_Lipa_-_Physical.mp3");

                    Mix_PlayMusic(THEME_MUSIC,100);


                    break;
                }

            }
        }
    }

}

void HANDLE_HP_REGEN() {

    unsigned long long TIME_NOW=time(NULL);

    if(TIME_NOW-GLOBAL_LAST_HP_REGEN_TIME_QUERRY>=5) {

        GLOBAL_LAST_HP_REGEN_TIME_QUERRY=TIME_NOW;

        if(GLOBAL_LAST_HP<=GLOBAL_INVENTORY_AND_COORDINATES.HP 
        
        && GLOBAL_INVENTORY_AND_COORDINATES.HP <GLOBAL_MAX_HP 
        
        && GLOBAL_INVENTORY_AND_COORDINATES.HUNGER>0) {

            GLOBAL_INVENTORY_AND_COORDINATES.HP+=2;

            if(GLOBAL_EFFECTS_STORAGE.H>0) {
                GLOBAL_INVENTORY_AND_COORDINATES.HP+=2;
                GLOBAL_EFFECTS_STORAGE.H--;
            }

            if(GLOBAL_INVENTORY_AND_COORDINATES.HP>GLOBAL_MAX_HP) {
                GLOBAL_INVENTORY_AND_COORDINATES.HP=GLOBAL_MAX_HP;
            }

        }   

        GLOBAL_LAST_HP=GLOBAL_INVENTORY_AND_COORDINATES.HP;

    }

}

void HANDLE_EFFECTS_USAGE() {

    if(GLOBAL_EFFECTS_STORAGE.D>0) {
        GLOBAL_EFFECTS_STORAGE.D--;
    }
    /*if(GLOBAL_EFFECTS_STORAGE.H>0) {
        GLOBAL_EFFECTS_STORAGE.H--;
    }*/
    if(GLOBAL_EFFECTS_STORAGE.S>0) {
        GLOBAL_EFFECTS_STORAGE.S--;
    }

}

void HANDLE_FOOD_SPOILAGE() {

    unsigned long long int TIME_QUERRY=time(NULL);

    if(TIME_QUERRY-GLOBAL_LAST_SPOILAGE_TIME_QUERRY>=120) {

        GLOBAL_LAST_SPOILAGE_TIME_QUERRY=TIME_QUERRY;

        if(GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR>0) {
            GLOBAL_INVENTORY_AND_COORDINATES.FOOD_SPOILED+=GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR;
            GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR=0;
        }
        if(GLOBAL_INVENTORY_AND_COORDINATES.FOOD_MAGIC>0) {
            GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR+=GLOBAL_INVENTORY_AND_COORDINATES.FOOD_MAGIC;
            GLOBAL_INVENTORY_AND_COORDINATES.FOOD_MAGIC=0;
        }
        if(GLOBAL_INVENTORY_AND_COORDINATES.FOOD_ELITE>0) {
            GLOBAL_INVENTORY_AND_COORDINATES.FOOD_REGULAR+=GLOBAL_INVENTORY_AND_COORDINATES.FOOD_ELITE;
            GLOBAL_INVENTORY_AND_COORDINATES.FOOD_ELITE=0;
        }



    }


}

void GENERATE_ENEMIES(POINT FLOOR[38][144], int FLOOR_NUMBER) {

    for(int i=0 ; i<6 ; i++) {
        if(GLOBAL_ALL_THEMES_COLOR[FLOOR_NUMBER-1][i]=='w') {
            
            int X_RNG,Y_RNG;

            while(TRUE) {

                X_RNG=rand()%144; Y_RNG=rand()%38;

                if(FLOOR[Y_RNG][X_RNG].REAL_CONTENTS=='.' && X_RNG>=48*(i%3) && X_RNG<48*(i%3+1) && Y_RNG>=19*(i/3) && Y_RNG<19*(i/3+1))
                {

                    int RNG=rand()%5;

                    switch(RNG) {

                        case 0:
                            {
                            FLOOR[Y_RNG][X_RNG].REAL_CONTENTS='D';
                            FLOOR[Y_RNG][X_RNG].SYMBOL='D';
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].DMG=2;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].HP=5;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MAX_HP=5;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MAX_MOVE_TILES=0;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MOVES_LEFT=0;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].SYMBOL='D';
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].x=X_RNG;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].y=Y_RNG;
                            }
                            break;
                        case 1:
                            {
                            FLOOR[Y_RNG][X_RNG].REAL_CONTENTS='F';
                            FLOOR[Y_RNG][X_RNG].SYMBOL='F';
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].DMG=4;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].HP=10;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MAX_HP=10;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MAX_MOVE_TILES=0;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MOVES_LEFT=0;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].SYMBOL='F';
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].x=X_RNG;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].y=Y_RNG;
                            }
                            break;
                        case 2:
                            {
                            FLOOR[Y_RNG][X_RNG].REAL_CONTENTS='G';
                            FLOOR[Y_RNG][X_RNG].SYMBOL='G';
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].DMG=6;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].HP=15;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MAX_HP=15;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MAX_MOVE_TILES=5;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MOVES_LEFT=5;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].SYMBOL='G';
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].x=X_RNG;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].y=Y_RNG;
                            }
                            break;
                        case 3:
                            {
                            FLOOR[Y_RNG][X_RNG].REAL_CONTENTS='S';
                            FLOOR[Y_RNG][X_RNG].SYMBOL='S';
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].DMG=8;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].HP=20;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MAX_HP=20;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MAX_MOVE_TILES=-1;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MOVES_LEFT=-1;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].SYMBOL='S';
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].x=X_RNG;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].y=Y_RNG;
                            }
                            break;
                        case 4:
                            {
                            FLOOR[Y_RNG][X_RNG].REAL_CONTENTS='U';
                            FLOOR[Y_RNG][X_RNG].SYMBOL='U';
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].DMG=12;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].HP=30;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MAX_HP=30;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MAX_MOVE_TILES=5;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MOVES_LEFT=5;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].SYMBOL='U';
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].x=X_RNG;
                            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].y=Y_RNG;
                            }
                            break;
                    }


                    break;
                }
            }
        }
        
        else if(GLOBAL_ALL_THEMES_COLOR[FLOOR_NUMBER-1][i]=='y') {

            for(int k=0 ; k<4 ; k++) {
                
                int X_RNG,Y_RNG;

                while(TRUE) {

                    X_RNG=rand()%144; Y_RNG=rand()%38;

                    if(FLOOR[Y_RNG][X_RNG].REAL_CONTENTS=='.' && X_RNG>=48*(i%3) && X_RNG<48*(i%3+1) && Y_RNG>=19*(i/3) && Y_RNG<19*(i/3+1))
                    {
                        FLOOR[Y_RNG][X_RNG].REAL_CONTENTS='S';
                        FLOOR[Y_RNG][X_RNG].SYMBOL='S';
                        GLOBAL_BOSSES_IN_LAST_ROOM[k].DMG=8;
                        GLOBAL_BOSSES_IN_LAST_ROOM[k].HP=20;
                        GLOBAL_BOSSES_IN_LAST_ROOM[k].MAX_HP=20;
                        GLOBAL_BOSSES_IN_LAST_ROOM[k].MAX_MOVE_TILES=-1;
                        GLOBAL_BOSSES_IN_LAST_ROOM[k].MOVES_LEFT=-1;
                        GLOBAL_BOSSES_IN_LAST_ROOM[k].SYMBOL='S';
                        GLOBAL_BOSSES_IN_LAST_ROOM[k].x=X_RNG;
                        GLOBAL_BOSSES_IN_LAST_ROOM[k].y=Y_RNG;

                        break;
                    }
                }
            }

        }
        
        else {
            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].DMG=0;
            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].HP=0;
            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MAX_HP=0;
            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MAX_MOVE_TILES=0;
            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].MOVES_LEFT=0;
            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].SYMBOL=0;
            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].x=0;
            GLOBAL_ALL_ENEMIES[FLOOR_NUMBER-1][i].y=0;
        }
    }

}

void MOVE_ENEMIES(POINT FLOOR[38][144]) {

    int SECTOR=GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1;

    if(GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR]=='y' 
    
    && FLOOR[GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='#') {
        
        for(int k=0 ; k<4 ; k++) {

            if(GLOBAL_BOSSES_IN_LAST_ROOM[k].HP>0) {

                int past_x=GLOBAL_BOSSES_IN_LAST_ROOM[k].x;
        
                int past_y=GLOBAL_BOSSES_IN_LAST_ROOM[k].y;

                if(GLOBAL_INVENTORY_AND_COORDINATES.x-GLOBAL_BOSSES_IN_LAST_ROOM[k].x>0 
            
                && FLOOR[past_y][past_x+1].REAL_CONTENTS=='.' && FLOOR[past_y][past_x+1].SYMBOL=='.') {

                    FLOOR[past_y][past_x].SYMBOL='.'; FLOOR[past_y][past_x].REAL_CONTENTS='.';

                    GLOBAL_BOSSES_IN_LAST_ROOM[k].x++;

                    FLOOR[past_y][past_x+1].SYMBOL=GLOBAL_BOSSES_IN_LAST_ROOM[k].SYMBOL; 
                
                    FLOOR[past_y][past_x+1].REAL_CONTENTS=GLOBAL_BOSSES_IN_LAST_ROOM[k].SYMBOL;

                }
                else if(GLOBAL_INVENTORY_AND_COORDINATES.x-GLOBAL_BOSSES_IN_LAST_ROOM[k].x<0 
                
                && FLOOR[past_y][past_x-1].REAL_CONTENTS=='.' && FLOOR[past_y][past_x-1].SYMBOL=='.') {
                    
                    FLOOR[past_y][past_x].SYMBOL='.'; FLOOR[past_y][past_x].REAL_CONTENTS='.';

                    GLOBAL_BOSSES_IN_LAST_ROOM[k].x--;

                    FLOOR[past_y][past_x-1].SYMBOL=GLOBAL_BOSSES_IN_LAST_ROOM[k].SYMBOL; 
                    
                    FLOOR[past_y][past_x-1].REAL_CONTENTS=GLOBAL_BOSSES_IN_LAST_ROOM[k].SYMBOL;

                    
                }
                else if(GLOBAL_INVENTORY_AND_COORDINATES.y-GLOBAL_BOSSES_IN_LAST_ROOM[k].y>0
                
                && FLOOR[past_y+1][past_x].REAL_CONTENTS=='.' && FLOOR[past_y+1][past_x].SYMBOL=='.') {

                    FLOOR[past_y][past_x].SYMBOL='.'; FLOOR[past_y][past_x].REAL_CONTENTS='.';

                    GLOBAL_BOSSES_IN_LAST_ROOM[k].y++;

                    FLOOR[past_y+1][past_x].SYMBOL=GLOBAL_BOSSES_IN_LAST_ROOM[k].SYMBOL; 
                    
                    FLOOR[past_y+1][past_x].REAL_CONTENTS=GLOBAL_BOSSES_IN_LAST_ROOM[k].SYMBOL;
                    
                }
                else if(GLOBAL_INVENTORY_AND_COORDINATES.y-GLOBAL_BOSSES_IN_LAST_ROOM[k].y<0
                
                && FLOOR[past_y-1][past_x].REAL_CONTENTS=='.' && FLOOR[past_y-1][past_x].SYMBOL=='.') {

                    FLOOR[past_y][past_x].SYMBOL='.'; FLOOR[past_y][past_x].REAL_CONTENTS='.';

                    GLOBAL_BOSSES_IN_LAST_ROOM[k].y--;

                    FLOOR[past_y-1][past_x].SYMBOL=GLOBAL_BOSSES_IN_LAST_ROOM[k].SYMBOL; 
                    
                    FLOOR[past_y-1][past_x].REAL_CONTENTS=GLOBAL_BOSSES_IN_LAST_ROOM[k].SYMBOL;

                }

            }

        }

    }

    else {

        if(FLOOR[GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='#' 
    
        && GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP>0 && GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].MOVES_LEFT!=0) {

        int MOVE_SUCCESS=FALSE;

        int past_x=GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].x;
        
        int past_y=GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].y;

        if(GLOBAL_INVENTORY_AND_COORDINATES.x-GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].x>0 
        
        && FLOOR[past_y][past_x+1].REAL_CONTENTS=='.' && FLOOR[past_y][past_x+1].SYMBOL=='.') {

            FLOOR[past_y][past_x].SYMBOL='.'; FLOOR[past_y][past_x].REAL_CONTENTS='.';

            GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].x++;

            FLOOR[past_y][past_x+1].SYMBOL=GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].SYMBOL; 
            
            FLOOR[past_y][past_x+1].REAL_CONTENTS=GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].SYMBOL;

            MOVE_SUCCESS++;
        }
        else if(GLOBAL_INVENTORY_AND_COORDINATES.x-GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].x<0 
        
        && FLOOR[past_y][past_x-1].REAL_CONTENTS=='.' && FLOOR[past_y][past_x-1].SYMBOL=='.') {
            
            FLOOR[past_y][past_x].SYMBOL='.'; FLOOR[past_y][past_x].REAL_CONTENTS='.';

            GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].x--;

            FLOOR[past_y][past_x-1].SYMBOL=GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].SYMBOL; 
            
            FLOOR[past_y][past_x-1].REAL_CONTENTS=GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].SYMBOL;

            MOVE_SUCCESS++;
        }
        else if(GLOBAL_INVENTORY_AND_COORDINATES.y-GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].y>0
        
        && FLOOR[past_y+1][past_x].REAL_CONTENTS=='.' && FLOOR[past_y+1][past_x].SYMBOL=='.') {

            FLOOR[past_y][past_x].SYMBOL='.'; FLOOR[past_y][past_x].REAL_CONTENTS='.';

            GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].y++;

            FLOOR[past_y+1][past_x].SYMBOL=GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].SYMBOL; 
            
            FLOOR[past_y+1][past_x].REAL_CONTENTS=GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].SYMBOL;
            
            MOVE_SUCCESS++;
        }
        else if(GLOBAL_INVENTORY_AND_COORDINATES.y-GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].y<0
        
        && FLOOR[past_y-1][past_x].REAL_CONTENTS=='.' && FLOOR[past_y-1][past_x].SYMBOL=='.') {

            FLOOR[past_y][past_x].SYMBOL='.'; FLOOR[past_y][past_x].REAL_CONTENTS='.';

            GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].y--;

            FLOOR[past_y-1][past_x].SYMBOL=GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].SYMBOL; 
            
            FLOOR[past_y-1][past_x].REAL_CONTENTS=GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].SYMBOL;

            MOVE_SUCCESS++;
        }


        if(MOVE_SUCCESS && GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].MAX_MOVE_TILES>0) {

            GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].MOVES_LEFT--;
        
        }



    }

        if(FLOOR[GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS=='+') {
            GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].MOVES_LEFT=GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].MAX_MOVE_TILES;
        }
    }

}

void HANDLE_ENEMIES_COMBAT(POINT FLOOR[38][144]) {

    int x=GLOBAL_INVENTORY_AND_COORDINATES.x;

    int y=GLOBAL_INVENTORY_AND_COORDINATES.y;

    if(FLOOR[y][x+1].REAL_CONTENTS=='D' || FLOOR[y][x+1].REAL_CONTENTS=='F' || FLOOR[y][x+1].REAL_CONTENTS=='G' || FLOOR[y][x+1].REAL_CONTENTS=='S' || FLOOR[y][x+1].REAL_CONTENTS=='U') {
        switch(FLOOR[y][x+1].REAL_CONTENTS) {
            case 'D' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Demon Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=2;

                break;
            }
            case 'F' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Fire Monster Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=4;

                break;
            }
            case 'G' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Giant Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=6;

                break;
            }
            case 'S' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Snake Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=8;

                break;
            }
            case 'U' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Undead Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=12;

                break;
            }
        }
    }
    if(FLOOR[y+1][x+1].REAL_CONTENTS=='D' || FLOOR[y+1][x+1].REAL_CONTENTS=='F' || FLOOR[y+1][x+1].REAL_CONTENTS=='G' || FLOOR[y+1][x+1].REAL_CONTENTS=='S' || FLOOR[y+1][x+1].REAL_CONTENTS=='U') {
        switch(FLOOR[y+1][x+1].REAL_CONTENTS) {
            case 'D' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Demon Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=2;

                break;
            }
            case 'F' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Fire Monster Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=4;

                break;
            }
            case 'G' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Giant Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=6;

                break;
            }
            case 'S' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Snake Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=8;

                break;
            }
            case 'U' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Undead Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=12;

                break;
            }
        }
    }
    if(FLOOR[y-1][x+1].REAL_CONTENTS=='D' || FLOOR[y-1][x+1].REAL_CONTENTS=='F' || FLOOR[y-1][x+1].REAL_CONTENTS=='G' || FLOOR[y-1][x+1].REAL_CONTENTS=='S' || FLOOR[y-1][x+1].REAL_CONTENTS=='U') {
       switch(FLOOR[y-1][x+1].REAL_CONTENTS) {
            case 'D' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Demon Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=2;

                break;
            }
            case 'F' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Fire Monster Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=4;

                break;
            }
            case 'G' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Giant Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=6;

                break;
            }
            case 'S' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Snake Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=8;

                break;
            }
            case 'U' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Undead Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=12;

                break;
            }
        } 
    }
    if(FLOOR[y][x-1].REAL_CONTENTS=='D' || FLOOR[y][x-1].REAL_CONTENTS=='F' || FLOOR[y][x-1].REAL_CONTENTS=='G' || FLOOR[y][x-1].REAL_CONTENTS=='S' || FLOOR[y][x-1].REAL_CONTENTS=='U') {
        switch(FLOOR[y][x-1].REAL_CONTENTS) {
            case 'D' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Demon Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=2;

                break;
            }
            case 'F' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Fire Monster Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=4;

                break;
            }
            case 'G' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Giant Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=6;

                break;
            }
            case 'S' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Snake Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=8;

                break;
            }
            case 'U' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Undead Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=12;

                break;
            }
        }
    }
    if(FLOOR[y+1][x-1].REAL_CONTENTS=='D' || FLOOR[y+1][x-1].REAL_CONTENTS=='F' || FLOOR[y+1][x-1].REAL_CONTENTS=='G' || FLOOR[y+1][x-1].REAL_CONTENTS=='S' || FLOOR[y+1][x-1].REAL_CONTENTS=='U') {
        switch(FLOOR[y+1][x-1].REAL_CONTENTS) {
            case 'D' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Demon Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=2;

                break;
            }
            case 'F' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Fire Monster Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=4;

                break;
            }
            case 'G' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Giant Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=6;

                break;
            }
            case 'S' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Snake Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=8;

                break;
            }
            case 'U' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Undead Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=12;

                break;
            }
        }
    }
    if(FLOOR[y-1][x-1].REAL_CONTENTS=='D' || FLOOR[y-1][x-1].REAL_CONTENTS=='F' || FLOOR[y-1][x-1].REAL_CONTENTS=='G' || FLOOR[y-1][x-1].REAL_CONTENTS=='S' || FLOOR[y-1][x-1].REAL_CONTENTS=='U') {
        switch(FLOOR[y-1][x-1].REAL_CONTENTS) {
            case 'D' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Demon Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=2;

                break;
            }
            case 'F' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Fire Monster Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=4;

                break;
            }
            case 'G' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Giant Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=6;

                break;
            }
            case 'S' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Snake Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=8;

                break;
            }
            case 'U' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Undead Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=12;

                break;
            }
        }
    }
    if(FLOOR[y+1][x].REAL_CONTENTS=='D' || FLOOR[y+1][x].REAL_CONTENTS=='F' || FLOOR[y+1][x].REAL_CONTENTS=='G' || FLOOR[y+1][x].REAL_CONTENTS=='S' || FLOOR[y+1][x].REAL_CONTENTS=='U') {
        switch(FLOOR[y+1][x].REAL_CONTENTS) {
            case 'D' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Demon Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=2;

                break;
            }
            case 'F' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Fire Monster Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=4;

                break;
            }
            case 'G' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Giant Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=6;

                break;
            }
            case 'S' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Snake Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=8;

                break;
            }
            case 'U' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Undead Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=12;

                break;
            }
        }
    }
    if(FLOOR[y-1][x].REAL_CONTENTS=='D' || FLOOR[y-1][x].REAL_CONTENTS=='F' || FLOOR[y-1][x].REAL_CONTENTS=='G' || FLOOR[y-1][x].REAL_CONTENTS=='S' || FLOOR[y-1][x].REAL_CONTENTS=='U') {
        switch(FLOOR[y-1][x].REAL_CONTENTS) {
            case 'D' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Demon Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=2;

                break;
            }
            case 'F' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Fire Monster Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=4;

                break;
            }
            case 'G' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Giant Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=6;

                break;
            }
            case 'S' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Snake Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=8;

                break;
            }
            case 'U' : {

                GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='r';

                PRINT_MESSAGE("The Undead Scored a Hit on You!");

                GLOBAL_INVENTORY_AND_COORDINATES.HP-=12;

                break;
            }
        }
    }

}

void HANDLE_PLAYER_COMBAT(POINT FLOOR[38][144], int DIRECTION) {

    int SECTOR=GIVE_SECTOR_NUMBER(GLOBAL_INVENTORY_AND_COORDINATES.x,GLOBAL_INVENTORY_AND_COORDINATES.y)-1;


    if(GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR]=='y') {// Boss room

        if(DIRECTION==0) {//melee
            
            for(int k=0 ; k<4 ; k++) { 

                int enemy_x=GLOBAL_BOSSES_IN_LAST_ROOM[k].x;

                int enemy_y=GLOBAL_BOSSES_IN_LAST_ROOM[k].y;
                
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='s'&& GLOBAL_BOSSES_IN_LAST_ROOM[k].HP>0) {//sword

                    int ENEMY_IN_RANGE=FALSE;

                    if(FLOOR[enemy_y][enemy_x+1].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }
                    if(FLOOR[enemy_y][enemy_x-1].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }
                    if(FLOOR[enemy_y+1][enemy_x+1].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }
                    if(FLOOR[enemy_y-1][enemy_x+1].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }
                    if(FLOOR[enemy_y+1][enemy_x-1].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }
                    if(FLOOR[enemy_y-1][enemy_x-1].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }
                    if(FLOOR[enemy_y+1][enemy_x].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }
                    if(FLOOR[enemy_y-1][enemy_x].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }

                    if(ENEMY_IN_RANGE) {
                        if(GLOBAL_EFFECTS_STORAGE.D>0) {
                            GLOBAL_BOSSES_IN_LAST_ROOM[k].HP-=20;
                            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Enemy For 20 HP!");
                        }
                        else {
                            GLOBAL_BOSSES_IN_LAST_ROOM[k].HP-=10;
                            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Enemy For 10 HP!");
                        }
                    }

                    if(GLOBAL_BOSSES_IN_LAST_ROOM[k].HP<=0 && ENEMY_IN_RANGE) {
                        FLOOR[ GLOBAL_BOSSES_IN_LAST_ROOM[k].y][ GLOBAL_BOSSES_IN_LAST_ROOM[k].x].REAL_CONTENTS='.';
                        FLOOR[ GLOBAL_BOSSES_IN_LAST_ROOM[k].y][ GLOBAL_BOSSES_IN_LAST_ROOM[k].x].SYMBOL='.';
                        GLOBAL_BOSSES_IN_LAST_ROOM[k].y=1;
                        GLOBAL_BOSSES_IN_LAST_ROOM[k].x=1;
                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Defeated The Enemy!");
                    }



                }
            
                else if(GLOBAL_BOSSES_IN_LAST_ROOM[k].HP>0 && GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='m') {//mace
                    
                    int ENEMY_IN_RANGE=FALSE;

                    if(FLOOR[enemy_y][enemy_x+1].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }
                    if(FLOOR[enemy_y][enemy_x-1].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }
                    if(FLOOR[enemy_y+1][enemy_x+1].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }
                    if(FLOOR[enemy_y-1][enemy_x+1].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }
                    if(FLOOR[enemy_y+1][enemy_x-1].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }
                    if(FLOOR[enemy_y-1][enemy_x-1].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }
                    if(FLOOR[enemy_y+1][enemy_x].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }
                    if(FLOOR[enemy_y-1][enemy_x].SYMBOL=='H') {
                        ENEMY_IN_RANGE++;
                    }

                    if(ENEMY_IN_RANGE) {
                        if(GLOBAL_EFFECTS_STORAGE.D>0) {
                            GLOBAL_BOSSES_IN_LAST_ROOM[k].HP-=10;
                            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Enemy For 10 HP!");
                        }
                        else {
                            GLOBAL_BOSSES_IN_LAST_ROOM[k].HP-=5;
                            GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                            strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Enemy For 5 HP!");
                        }
                    }

                    if(GLOBAL_BOSSES_IN_LAST_ROOM[k].HP<=0 && ENEMY_IN_RANGE) {
                        FLOOR[ GLOBAL_BOSSES_IN_LAST_ROOM[k].y][ GLOBAL_BOSSES_IN_LAST_ROOM[k].x].REAL_CONTENTS='.';
                        FLOOR[ GLOBAL_BOSSES_IN_LAST_ROOM[k].y][ GLOBAL_BOSSES_IN_LAST_ROOM[k].x].SYMBOL='.';
                        GLOBAL_BOSSES_IN_LAST_ROOM[k].y=1;
                        GLOBAL_BOSSES_IN_LAST_ROOM[k].x=1;
                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Defeated The Enemy!");
                    }

                }
                
            }
            
        }

        else if((DIRECTION=='2' || DIRECTION=='4' || DIRECTION=='6' || DIRECTION=='8') && FLOOR[GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='#') {//ranged

            int MAX_RANGE=0; 
            
            int x_bullet=GLOBAL_INVENTORY_AND_COORDINATES.x;

            int y_bullet=GLOBAL_INVENTORY_AND_COORDINATES.y;

            int ENEMY_WAS_HIT=FALSE;

            int OBSTACLE_WAS_HIT=FALSE;

            if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='d') {

                MAX_RANGE=5;

                GLOBAL_INVENTORY_AND_COORDINATES.DAGGER--;

            }
            else if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='a') {

                MAX_RANGE=5;

                GLOBAL_INVENTORY_AND_COORDINATES.ARROW--;

            }
            else if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='w') {
                
                MAX_RANGE=10;

                GLOBAL_INVENTORY_AND_COORDINATES.WAND--;

            }

            for(int i=1 ; i<=MAX_RANGE ; i++) {

                if(DIRECTION=='8') {//up(neg y)

                    y_bullet--;

                    if(FLOOR[y_bullet][x_bullet].SYMBOL=='|' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='O' 
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='_' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='+'
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='?') {//bullet will not exit room.
                        y_bullet++;
                        OBSTACLE_WAS_HIT=TRUE;
                        break;
                    }

                }
                if(DIRECTION=='6') {// right (pos x)

                    x_bullet++;

                    if(FLOOR[y_bullet][x_bullet].SYMBOL=='|' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='O' 
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='_' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='+'
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='?') {//bullet will not exit room.
                        x_bullet--;
                        OBSTACLE_WAS_HIT=TRUE;
                        break;
                    }

                }
                if(DIRECTION=='4') {//left (neg x)

                    x_bullet--;

                    if(FLOOR[y_bullet][x_bullet].SYMBOL=='|' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='O' 
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='_' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='+'
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='?') {//bullet will not exit room.
                        x_bullet++;
                        OBSTACLE_WAS_HIT=TRUE;
                        break;
                    }

                }
                if(DIRECTION=='2') {//down (pos y)

                    y_bullet++;

                    if(FLOOR[y_bullet][x_bullet].SYMBOL=='|' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='O' 
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='_' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='+'
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='?') {//bullet will not exit room.
                        y_bullet--;
                        OBSTACLE_WAS_HIT=TRUE;
                        break;
                    }

                }

                if(FLOOR[y_bullet][x_bullet].SYMBOL=='D' || FLOOR[y_bullet][x_bullet].SYMBOL=='F' 
                || FLOOR[y_bullet][x_bullet].SYMBOL=='G' || FLOOR[y_bullet][x_bullet].SYMBOL=='S'
                || FLOOR[y_bullet][x_bullet].SYMBOL=='U') {
                    ENEMY_WAS_HIT=TRUE;
                    break;
                }

            }

            if(ENEMY_WAS_HIT) {

                int SECTOR=GIVE_SECTOR_NUMBER(x_bullet,y_bullet)-1;

                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='a') {

                    if(GLOBAL_EFFECTS_STORAGE.D>0) { 

                        GLOBAL_BOSSES_IN_LAST_ROOM[FIND_THAT_SNAKE(x_bullet,y_bullet)].HP-=10;

                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Target For 10 HP!");
                    }
                    else {
                        GLOBAL_BOSSES_IN_LAST_ROOM[FIND_THAT_SNAKE(x_bullet,y_bullet)].HP-=5;

                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Target For 5 HP!");
                    }

                }
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='w') {

                    if(GLOBAL_EFFECTS_STORAGE.D>0) {
                        GLOBAL_BOSSES_IN_LAST_ROOM[FIND_THAT_SNAKE(x_bullet,y_bullet)].HP-=30;

                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Target For 30 HP!");
                    }

                    else {
                        GLOBAL_BOSSES_IN_LAST_ROOM[FIND_THAT_SNAKE(x_bullet,y_bullet)].HP-=15;

                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Target For 15 HP!");
                    }

                    GLOBAL_BOSSES_IN_LAST_ROOM[FIND_THAT_SNAKE(x_bullet,y_bullet)].MAX_MOVE_TILES=0;
                    GLOBAL_BOSSES_IN_LAST_ROOM[FIND_THAT_SNAKE(x_bullet,y_bullet)].MOVES_LEFT=0;

                }
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='d') {
                    
                    if(GLOBAL_EFFECTS_STORAGE.D>0) {
                        GLOBAL_BOSSES_IN_LAST_ROOM[FIND_THAT_SNAKE(x_bullet,y_bullet)].HP-=24;

                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Target For 24 HP!");
                    }
                    else {
                        GLOBAL_BOSSES_IN_LAST_ROOM[FIND_THAT_SNAKE(x_bullet,y_bullet)].HP-=12;

                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Target For 12 HP!");
                    }

                }

                //check for enemy death

                if(GLOBAL_BOSSES_IN_LAST_ROOM[FIND_THAT_SNAKE(x_bullet,y_bullet)].HP<=0) {
                    GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                    strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Defeated The Enemy!");
                    FLOOR[y_bullet][x_bullet].SYMBOL='.';
                    FLOOR[y_bullet][x_bullet].REAL_CONTENTS='.';
                    GLOBAL_BOSSES_IN_LAST_ROOM[FIND_THAT_SNAKE(x_bullet,y_bullet)].x=1;
                    GLOBAL_BOSSES_IN_LAST_ROOM[FIND_THAT_SNAKE(x_bullet,y_bullet)].y=1;
                }

            }
            
            else if(OBSTACLE_WAS_HIT) {

                if(x_bullet==GLOBAL_INVENTORY_AND_COORDINATES.x && y_bullet==GLOBAL_INVENTORY_AND_COORDINATES.y) {

                    if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='a') {
                        GLOBAL_INVENTORY_AND_COORDINATES.ARROW++;
                    }
                    if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='d') {
                        GLOBAL_INVENTORY_AND_COORDINATES.DAGGER++;
                    }
                    if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='w') {
                        GLOBAL_INVENTORY_AND_COORDINATES.WAND++;
                    }

                }

                else {

                    if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='a') {
                        FLOOR[y_bullet][x_bullet].REAL_CONTENTS='a';
                        FLOOR[y_bullet][x_bullet].SYMBOL='a';
                        FLOOR[y_bullet][x_bullet].COLOR=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(x_bullet,y_bullet)-1];
                    }
                    if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='w') {
                        FLOOR[y_bullet][x_bullet].REAL_CONTENTS='z';
                        FLOOR[y_bullet][x_bullet].SYMBOL='z';
                        FLOOR[y_bullet][x_bullet].COLOR=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(x_bullet,y_bullet)-1];
                    }
                    if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='d') {
                        FLOOR[y_bullet][x_bullet].REAL_CONTENTS='i';
                        FLOOR[y_bullet][x_bullet].SYMBOL='i';
                        FLOOR[y_bullet][x_bullet].COLOR=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(x_bullet,y_bullet)-1];
                    }
                }

            }
            
            else {//ran outa juice

                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='a') {
                    FLOOR[y_bullet][x_bullet].REAL_CONTENTS='a';
                    FLOOR[y_bullet][x_bullet].SYMBOL='a';
                    FLOOR[y_bullet][x_bullet].COLOR=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(x_bullet,y_bullet)-1];
                }
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='w') {
                    FLOOR[y_bullet][x_bullet].REAL_CONTENTS='z';
                    FLOOR[y_bullet][x_bullet].SYMBOL='z';
                    FLOOR[y_bullet][x_bullet].COLOR=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(x_bullet,y_bullet)-1];
                }
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='d') {
                    FLOOR[y_bullet][x_bullet].REAL_CONTENTS='i';
                    FLOOR[y_bullet][x_bullet].SYMBOL='i';
                    FLOOR[y_bullet][x_bullet].COLOR=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(x_bullet,y_bullet)-1];
                }

            }



        }
    
    }

    else {//regular rooms

        if(DIRECTION==0) {//melee

            int enemy_x=GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].x;

            int enemy_y=GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].y;
            
            if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='s' && GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP>0) {//sword

                int ENEMY_IN_RANGE=FALSE;

                if(FLOOR[enemy_y][enemy_x+1].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }
                if(FLOOR[enemy_y][enemy_x-1].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }
                if(FLOOR[enemy_y+1][enemy_x+1].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }
                if(FLOOR[enemy_y-1][enemy_x+1].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }
                if(FLOOR[enemy_y+1][enemy_x-1].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }
                if(FLOOR[enemy_y-1][enemy_x-1].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }
                if(FLOOR[enemy_y+1][enemy_x].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }
                if(FLOOR[enemy_y-1][enemy_x].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }

                if(ENEMY_IN_RANGE) {
                    if(GLOBAL_EFFECTS_STORAGE.D>0) {
                        GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP-=20;
                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Enemy For 20 HP!");
                    }
                    else {
                        GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP-=10;
                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Enemy For 10 HP!");
                    }
                }

                if(GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP<=0 && ENEMY_IN_RANGE) {
                    FLOOR[ GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].y][ GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].x].REAL_CONTENTS='.';
                    FLOOR[ GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].y][ GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].x].SYMBOL='.';
                    GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].y=1;
                    GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].x=1;
                    GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                    strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Defeated The Enemy!");
                }



            }
        
            else if(GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP>0 && GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='m') {//mace
                
                int ENEMY_IN_RANGE=FALSE;

                if(FLOOR[enemy_y][enemy_x+1].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }
                if(FLOOR[enemy_y][enemy_x-1].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }
                if(FLOOR[enemy_y+1][enemy_x+1].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }
                if(FLOOR[enemy_y-1][enemy_x+1].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }
                if(FLOOR[enemy_y+1][enemy_x-1].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }
                if(FLOOR[enemy_y-1][enemy_x-1].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }
                if(FLOOR[enemy_y+1][enemy_x].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }
                if(FLOOR[enemy_y-1][enemy_x].SYMBOL=='H') {
                    ENEMY_IN_RANGE++;
                }

                if(ENEMY_IN_RANGE) {
                    if(GLOBAL_EFFECTS_STORAGE.D>0) {
                        GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP-=10;
                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Enemy For 10 HP!");
                    }
                    else {
                        GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP-=5;
                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Enemy For 5 HP!");
                    }
                }

                if(GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP<=0 && ENEMY_IN_RANGE) {
                    FLOOR[ GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].y][ GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].x].REAL_CONTENTS='.';
                    FLOOR[ GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].y][ GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].x].SYMBOL='.';
                    GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].y=1;
                    GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].x=1;
                    GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                    strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Defeated The Enemy!");
                }

            }
            
        }
        
        else if((DIRECTION=='2' || DIRECTION=='4' || DIRECTION=='6' || DIRECTION=='8') && FLOOR[GLOBAL_INVENTORY_AND_COORDINATES.y][GLOBAL_INVENTORY_AND_COORDINATES.x].REAL_CONTENTS!='#') {//ranged

            int MAX_RANGE=0; 
            
            int x_bullet=GLOBAL_INVENTORY_AND_COORDINATES.x;

            int y_bullet=GLOBAL_INVENTORY_AND_COORDINATES.y;

            int ENEMY_WAS_HIT=FALSE;

            int OBSTACLE_WAS_HIT=FALSE;

            if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='d') {

                MAX_RANGE=5;

                GLOBAL_INVENTORY_AND_COORDINATES.DAGGER--;

            }
            else if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='a') {

                MAX_RANGE=5;

                GLOBAL_INVENTORY_AND_COORDINATES.ARROW--;

            }
            else if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='w') {
                
                MAX_RANGE=10;

                GLOBAL_INVENTORY_AND_COORDINATES.WAND--;

            }

            for(int i=1 ; i<=MAX_RANGE ; i++) {

                if(DIRECTION=='8') {//up(neg y)

                    y_bullet--;

                    if(FLOOR[y_bullet][x_bullet].SYMBOL=='|' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='O' 
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='_' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='+'
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='?') {//bullet will not exit room.
                        y_bullet++;
                        OBSTACLE_WAS_HIT=TRUE;
                        break;
                    }

                }
                if(DIRECTION=='6') {// right (pos x)

                    x_bullet++;

                    if(FLOOR[y_bullet][x_bullet].SYMBOL=='|' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='O' 
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='_' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='+'
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='?') {//bullet will not exit room.
                        x_bullet--;
                        OBSTACLE_WAS_HIT=TRUE;
                        break;
                    }

                }
                if(DIRECTION=='4') {//left (neg x)

                    x_bullet--;

                    if(FLOOR[y_bullet][x_bullet].SYMBOL=='|' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='O' 
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='_' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='+'
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='?') {//bullet will not exit room.
                        x_bullet++;
                        OBSTACLE_WAS_HIT=TRUE;
                        break;
                    }

                }
                if(DIRECTION=='2') {//down (pos y)

                    y_bullet++;

                    if(FLOOR[y_bullet][x_bullet].SYMBOL=='|' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='O' 
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='_' || FLOOR[y_bullet][x_bullet].REAL_CONTENTS=='+'
                    || FLOOR[y_bullet][x_bullet].SYMBOL=='?') {//bullet will not exit room.
                        y_bullet--;
                        OBSTACLE_WAS_HIT=TRUE;
                        break;
                    }

                }

                if(FLOOR[y_bullet][x_bullet].SYMBOL=='D' || FLOOR[y_bullet][x_bullet].SYMBOL=='F' 
                || FLOOR[y_bullet][x_bullet].SYMBOL=='G' || FLOOR[y_bullet][x_bullet].SYMBOL=='S'
                || FLOOR[y_bullet][x_bullet].SYMBOL=='U') {
                    ENEMY_WAS_HIT=TRUE;
                    break;
                }

            }

            if(ENEMY_WAS_HIT) {

                int SECTOR=GIVE_SECTOR_NUMBER(x_bullet,y_bullet)-1;

                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='a') {

                    if(GLOBAL_EFFECTS_STORAGE.D>0) {
                        GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP-=10;
                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Target For 10 HP!");
                    }
                    else {
                        GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP-=5;
                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Target For 5 HP!");
                    }

                }
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='w') {

                    if(GLOBAL_EFFECTS_STORAGE.D>0) {
                        GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP-=30;
                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Target For 30 HP!");
                    }

                    else {
                        GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP-=15;
                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Target For 15 HP!");
                    }

                    GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].MAX_MOVE_TILES=0;
                    GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].MOVES_LEFT=0;

                }
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='d') {
                    
                    if(GLOBAL_EFFECTS_STORAGE.D>0) {
                        GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP-=24;
                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Target For 24 HP!");
                    }
                    else {
                        GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP-=12;
                        GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                        strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Hit The Target For 12 HP!");
                    }

                }

                //check for enemy death

                if(GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].HP<=0) {
                    GLOBAL_MOST_RECENT_COLOR_FOR_MESSAGE='y';
                    strcpy(GLOBAL_MOST_RECENT_MESSAGE,"You Defeated The Enemy!");
                    FLOOR[y_bullet][x_bullet].SYMBOL='.';
                    FLOOR[y_bullet][x_bullet].REAL_CONTENTS='.';
                    GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].x=1;
                    GLOBAL_ALL_ENEMIES[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][SECTOR].y=1;
                }

            }
            
            else if(OBSTACLE_WAS_HIT) {

                if(x_bullet==GLOBAL_INVENTORY_AND_COORDINATES.x && y_bullet==GLOBAL_INVENTORY_AND_COORDINATES.y) {

                    if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='a') {
                        GLOBAL_INVENTORY_AND_COORDINATES.ARROW++;
                    }
                    if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='d') {
                        GLOBAL_INVENTORY_AND_COORDINATES.DAGGER++;
                    }
                    if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='w') {
                        GLOBAL_INVENTORY_AND_COORDINATES.WAND++;
                    }

                }

                else {

                    if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='a') {
                        FLOOR[y_bullet][x_bullet].REAL_CONTENTS='a';
                        FLOOR[y_bullet][x_bullet].SYMBOL='a';
                        FLOOR[y_bullet][x_bullet].COLOR=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(x_bullet,y_bullet)-1];
                    }
                    if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='w') {
                        FLOOR[y_bullet][x_bullet].REAL_CONTENTS='z';
                        FLOOR[y_bullet][x_bullet].SYMBOL='z';
                        FLOOR[y_bullet][x_bullet].COLOR=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(x_bullet,y_bullet)-1];
                    }
                    if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='d') {
                        FLOOR[y_bullet][x_bullet].REAL_CONTENTS='i';
                        FLOOR[y_bullet][x_bullet].SYMBOL='i';
                        FLOOR[y_bullet][x_bullet].COLOR=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(x_bullet,y_bullet)-1];
                    }
                }

            }
            
            else {//ran outa juice

                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='a') {
                    FLOOR[y_bullet][x_bullet].REAL_CONTENTS='a';
                    FLOOR[y_bullet][x_bullet].SYMBOL='a';
                    FLOOR[y_bullet][x_bullet].COLOR=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(x_bullet,y_bullet)-1];
                }
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='w') {
                    FLOOR[y_bullet][x_bullet].REAL_CONTENTS='z';
                    FLOOR[y_bullet][x_bullet].SYMBOL='z';
                    FLOOR[y_bullet][x_bullet].COLOR=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(x_bullet,y_bullet)-1];
                }
                if(GLOBAL_INVENTORY_AND_COORDINATES.EQUIPPED_WEAPON=='d') {
                    FLOOR[y_bullet][x_bullet].REAL_CONTENTS='i';
                    FLOOR[y_bullet][x_bullet].SYMBOL='i';
                    FLOOR[y_bullet][x_bullet].COLOR=GLOBAL_ALL_THEMES_COLOR[GLOBAL_INVENTORY_AND_COORDINATES.FLOOR][GIVE_SECTOR_NUMBER(x_bullet,y_bullet)-1];
                }

            }


        }

    }
        
}

int FIND_THAT_SNAKE(int x, int y) {

    for(int k=0 ; k<4 ; k++) {

        if(GLOBAL_BOSSES_IN_LAST_ROOM[k].x==x && GLOBAL_BOSSES_IN_LAST_ROOM[k].y==y) {
            return k;
        }

    }

    return -1;
}





//------------------------------------------------------------End----------------------------------------------------------------------//